import React from "react";

interface AgentEmbedIframeProps {
  agentId: string;
}

const AgentEmbedIframe: React.FC<AgentEmbedIframeProps> = ({ agentId }) => {
  return (
    <iframe
      src={`https://app.agent.ai/agent/${agentId}`}
      width="100%"
      height="800px"
      frameBorder="0"
      title="Agent"
      allow="clipboard-write"
      style={{ borderRadius: "4px" }}
    />
  );
};

export default AgentEmbedIframe;