import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface AgentEmbedCodeProps {
  agentId: string;
  title: string;
  description?: string;
}

const AgentEmbedCode: React.FC<AgentEmbedCodeProps> = ({
  agentId,
  title,
  description
}) => {
  const [copied, setCopied] = useState(false);
  
  // Generate the embed code
  const embedCode = `<iframe 
  src="https://agent.ai/embed/${agentId}"
  width="100%" 
  height="800px" 
  frameborder="0"
  title="${title.replace(/"/g, '&quot;')}"
  allow="clipboard-write"
></iframe>`;

  const handleCopy = () => {
    navigator.clipboard.writeText(embedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card className="mb-8">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <p className="text-gray-600 mt-2">{description}</p>}
      </CardHeader>
      <CardContent>
        <div className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          <pre className="text-sm"><code>{embedCode}</code></pre>
        </div>
        <Button onClick={handleCopy} className="mt-4">
          {copied ? "Copied!" : "Copy Embed Code"}
        </Button>
        
        <div className="mt-8 border-t pt-4">
          <h3 className="font-medium mb-2">Preview</h3>
          <iframe 
            src={`https://agent.ai/embed/${agentId}`}
            width="100%" 
            height="400px" 
            frameBorder="0"
            title={title}
            className="rounded-lg border"
            allow="clipboard-write"
          ></iframe>
        </div>
      </CardContent>
    </Card>
  );
};

export default AgentEmbedCode;