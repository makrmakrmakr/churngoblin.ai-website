import React from "react";

interface AgentEmbedProps {
  agentId: string;
  title: string;
  description?: string;
  height?: string;
}

const AgentEmbed: React.FC<AgentEmbedProps> = ({
  agentId,
  title,
  description,
  height = "800px"
}) => {
  return (
    <div className="mt-8 mb-12">
      <h2 className="text-2xl font-bold mb-3">{title}</h2>
      {description && (
        <p className="text-gray-600 mb-4 max-w-3xl">
          {description}
        </p>
      )}
      <div className="mt-4">
        <iframe 
          src={`https://agent.ai/embed/${agentId}`}
          width="100%" 
          height={height}
          frameBorder="0"
          title={title}
          className="rounded-lg shadow-md"
          allow="clipboard-write"
        ></iframe>
      </div>
    </div>
  );
};

export default AgentEmbed;