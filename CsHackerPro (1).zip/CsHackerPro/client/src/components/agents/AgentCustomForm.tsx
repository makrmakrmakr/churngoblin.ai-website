import React, { useEffect, useRef } from "react";

interface AgentCustomFormProps {
  agentId: string;
}

const AgentCustomForm: React.FC<AgentCustomFormProps> = ({ agentId }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Clear container first
    containerRef.current.innerHTML = "";

    // Create the form container
    const formContainer = document.createElement("div");
    formContainer.id = "agent-form-container";
    formContainer.style.fontFamily = "sans-serif";
    formContainer.style.maxWidth = "600px";
    formContainer.style.margin = "0 auto";

    // Create the form HTML
    formContainer.innerHTML = `
      <form id="agentForm" style="display: flex; flex-direction: column; gap: 10px;">
        <input
          id="basicPromptInput"
          name="basic_prompt"
          type="text"
          placeholder="Sample prompt for the agent"
          required
          style="padding: 10px; border: 1px solid #ccc;"
        />
        <button
          type="submit"
          style="padding: 10px; background: #008080; color: white; border: none; cursor: pointer;"
        >
          Run Agent
        </button>
        <div id="agentStatus" style="min-height: 1.5em; font-size: 0.9em;"></div>
      </form>
      <div id="agentResponseOutput" style="margin-top: 16px; padding: 16px; background: #F9F9F9; border: 1px solid #eee; display: none;">
        <strong>Response:</strong>
        <div id="agentResponseText" style="margin-top: 8px;"></div>
      </div>
    `;

    // Add to container
    containerRef.current.appendChild(formContainer);

    // Add the event listener for form submission
    const form = document.getElementById("agentForm");
    if (form) {
      form.addEventListener("submit", async function (e) {
        e.preventDefault();
        const inputEl = document.getElementById("basicPromptInput") as HTMLInputElement;
        const input = inputEl?.value || "";
        const statusEl = document.getElementById("agentStatus");
        const outputBox = document.getElementById("agentResponseOutput");
        const outputText = document.getElementById("agentResponseText");

        if (!statusEl || !outputBox || !outputText) return;

        statusEl.style.color = "#333";
        statusEl.textContent = "Submitting...";
        outputBox.style.display = "none";

        try {
          const res = await fetch("https://api-lr.agent.ai/v1/action/invoke_agent", {
            method: "POST",
            headers: {
              "Authorization": "Bearer d06f0ecf55a87fceac4fdcb58a8b69c773d4716e96e78a62b9f60c36d3218498",
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ 
              basic_prompt: input,
              id: agentId  // Add the agent ID from props
            })
          });

          const data = await res.json();
          console.log(":mag: Full agent response:", data);
          let raw = data?.output || data?.message || data?.response;
          if (!raw) raw = "No usable content returned.";
          
          outputText.innerHTML = raw;
          statusEl.style.color = "green";
          statusEl.textContent = "Success!";
          outputBox.style.display = "block";
        } catch (err) {
          console.error(":x: Fetch error:", err);
          if (statusEl) {
            statusEl.style.color = "red";
            statusEl.textContent = "An error occurred while processing your request.";
          }
        }
      });
    }

    // Clean up on component unmount
    return () => {
      const form = document.getElementById("agentForm");
      if (form) {
        form.removeEventListener("submit", () => {});
      }
    };
  }, [agentId]);

  return <div ref={containerRef} className="mx-auto my-6"></div>;
};

export default AgentCustomForm;