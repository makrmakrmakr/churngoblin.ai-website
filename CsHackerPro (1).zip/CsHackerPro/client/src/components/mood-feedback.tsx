import React, { useState } from "react";
import { 
  Smile, 
  Frown, 
  ThumbsUp, 
  ThumbsDown,
  MessageCircle 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { Mood } from "./mood-emoji";

interface MoodFeedbackProps {
  onSelectMood: (mood: Mood) => void;
  className?: string;
}

const MoodFeedback: React.FC<MoodFeedbackProps> = ({ 
  onSelectMood, 
  className = "" 
}) => {
  const [selected, setSelected] = useState<Mood | null>(null);

  const handleSelectMood = (mood: Mood) => {
    setSelected(mood);
    onSelectMood(mood);
  };

  return (
    <div className={`flex items-center gap-1 ${className}`}>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="ghost" 
            size="icon" 
            className={`h-6 w-6 rounded-full ${selected === "happy" ? "bg-green-100" : ""}`}
            onClick={() => handleSelectMood("happy")}
          >
            <ThumbsUp className="h-3 w-3 text-green-500" />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="top">
          <p className="text-xs">Helpful</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="ghost" 
            size="icon" 
            className={`h-6 w-6 rounded-full ${selected === "thinking" ? "bg-blue-100" : ""}`}
            onClick={() => handleSelectMood("thinking")}
          >
            <MessageCircle className="h-3 w-3 text-blue-500" />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="top">
          <p className="text-xs">Interesting</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="ghost" 
            size="icon" 
            className={`h-6 w-6 rounded-full ${selected === "confused" ? "bg-orange-100" : ""}`}
            onClick={() => handleSelectMood("confused")}
          >
            <Frown className="h-3 w-3 text-orange-500" />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="top">
          <p className="text-xs">Confused</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="ghost" 
            size="icon" 
            className={`h-6 w-6 rounded-full ${selected === "sad" ? "bg-red-100" : ""}`}
            onClick={() => handleSelectMood("sad")}
          >
            <ThumbsDown className="h-3 w-3 text-red-500" />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="top">
          <p className="text-xs">Not helpful</p>
        </TooltipContent>
      </Tooltip>
    </div>
  );
};

export default MoodFeedback;