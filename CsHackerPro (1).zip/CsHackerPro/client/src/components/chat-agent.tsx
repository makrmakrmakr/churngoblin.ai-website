import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, RefreshCw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import MoodEmoji from "./mood-emoji";
import MoodFeedback from "./mood-feedback";

type Mood = "neutral" | "happy" | "excited" | "thinking" | "confused" | "sad";

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  mood?: Mood; // Mood attribute for emoji display
};

// Define the response type that matches the admin panel
type AgentResponse = {
  key: string;
  name: string;
  content: string;
  keywords: string[];
};

// Default responses if none are found in localStorage
const defaultResponses: AgentResponse[] = [
  {
    key: "default",
    name: "Default Response",
    content: "I hear you. Many CS leaders are dealing with similar challenges. Want to share more about your specific situation?",
    keywords: []
  },
  {
    key: "greeting",
    name: "Greeting",
    content: "Hey! I'm here to help CS teams figure out if AI can make their lives easier. What brings you by today?",
    keywords: ["hi", "hello", "hey"]
  },
  {
    key: "agents",
    name: "AI Agents Overview",
    content: "We focus on three main areas where AI can help CS teams: onboarding new customers, securing renewals, and growing accounts. Each agent acts like a team member that handles repetitive tasks so your human CSMs can focus on relationships. Is one of those areas a particular pain point for you?",
    keywords: ["agent", "types", "offerings", "what agents"]
  },
  {
    key: "onboarding",
    name: "Onboarding Agent",
    content: "Our onboarding agent is super popular! It automates all those check-in emails and training coordination tasks that eat up so much time. Most teams see a 30-40% faster time-to-value for their customers. Is your team spending too much time on repetitive onboarding tasks?",
    keywords: ["onboard"]
  },
  {
    key: "renewal",
    name: "Renewal Agent",
    content: "Our renewal agent is like having an early warning system for at-risk accounts. It spots the warning signs weeks before a human would notice, giving your team time to step in and save the relationship. Have you had any surprise non-renewals lately?",
    keywords: ["renew"]
  },
  {
    key: "expansion",
    name: "Expansion Agent",
    content: "The expansion agent is my personal favorite. It analyzes how customers use your product and flags expansion opportunities your team might miss. Some clients have seen a 30% bump in expansion revenue. Is your team expected to drive upsell conversations?",
    keywords: ["expan", "upsell", "cross-sell"]
  },
  {
    key: "custom",
    name: "Custom Solutions",
    content: "Every CS team has unique processes and workflows. That's why Kate works directly with teams to create custom AI agents tailored to their specific needs. The process starts with understanding your unique CS motion, identifying automation opportunities, and building agents that integrate with your existing tech stack. Would you like to hear about some custom solutions we've built?",
    keywords: ["custom", "tailor", "specific"]
  },
  {
    key: "pricing",
    name: "Pricing Information",
    content: "We offer both free educational resources and tailored AI agent solutions to fit teams of all sizes. For specific pricing on our agents or custom development, Kate would be happy to discuss your unique needs. The investment typically pays for itself within the first quarter through increased efficiency and revenue. Would you like to book a call to discuss pricing options?",
    keywords: ["price", "cost", "how much", "expensive", "budget"]
  },
  {
    key: "contact",
    name: "Contact Information",
    content: "You can connect with Kate directly by booking a 30-minute consultation through her calendar or by emailing kate@cshacker.ai. She typically responds within 24 hours and loves talking with CS leaders about their challenges. What's the best way for her to reach you?",
    keywords: ["contact", "email", "call", "schedule", "talk to"]
  },
  {
    key: "about",
    name: "About Kate",
    content: "Kate has over 10 years of experience leading CS teams at B2B SaaS companies. After seeing firsthand how CS teams are expected to handle more accounts with fewer resources, she founded CSHacker to help professionals use AI as a force multiplier. Her passion is creating AI agents that handle repetitive tasks while preserving the human relationship at the core of CS. Would you like to hear more about her approach?",
    keywords: ["kate", "founder", "about you", "who"]
  },
  {
    key: "right_for_team",
    name: "Is AI Right For Team",
    content: "Certainly! CSHacker specializes in AI agents for three critical customer lifecycle phases: onboarding, renewal, and expansion. Each agent works alongside your human team to make them more effective. Which phase is most challenging for your team right now?",
    keywords: ["right for", "good fit", "should", "if my team", "need ai", "ready for ai", "using ai", "don't know"]
  },
  {
    key: "use_cases",
    name: "Use Cases",
    content: "Great question! Here are some real use cases we've implemented:\n\n• Automating 75% of onboarding check-ins while improving customer satisfaction\n• Identifying at-risk accounts 45 days earlier than manual processes\n• Increasing CSM capacity by 40% through intelligent task automation\n• Generating expansion opportunities worth 15-20% of existing contract value\n\nDoes any of these align with challenges your team is facing?",
    keywords: ["use case", "example", "what can", "how does"]
  },
  {
    key: "implementation",
    name: "Implementation Process",
    content: "Implementation is designed to be straightforward and typically takes 2-4 weeks. We start with a discovery phase to understand your processes, then configure the AI agents to fit your workflow, integrate with your tools, and train your team. The most successful implementations have a clear champion and specific success metrics. Would having a timeline for your specific situation be helpful?",
    keywords: ["implement", "deploy", "setup", "start"]
  },
  {
    key: "results",
    name: "Results & Metrics",
    content: "Our clients typically see results within the first 30 days. On average, teams report:\n\n• 30-40% reduction in routine task time\n• 25% increase in accounts per CSM\n• 15-20% improvement in renewal rates\n• 2-3x ROI within the first quarter\n\nThe key is starting with a focused use case and measuring impact. Which metric would be most valuable for your team to improve?",
    keywords: ["roi", "result", "impact", "benefit"]
  },
  {
    key: "free_agents",
    name: "Free Agents",
    content: "I've got good news! We have free AI agents you can start using right away. They handle the basic stuff like sending check-in emails and collecting data. Want me to show you how to get started with one?",
    keywords: ["free", "no cost", "trial", "try out", "get started", "want the free"]
  }
];

const ChatAgent = () => {
  const [responses, setResponses] = useState<AgentResponse[]>(defaultResponses);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "",  // Will be set in useEffect after loading responses
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  // Load responses from localStorage on component mount
  useEffect(() => {
    const savedResponses = localStorage.getItem("agentResponses");
    if (savedResponses) {
      try {
        const parsed = JSON.parse(savedResponses);
        setResponses(parsed);
        
        // Update greeting message with the loaded greeting
        const greeting = parsed.find((r: AgentResponse) => r.key === "greeting");
        if (greeting) {
          setMessages([{
            id: "1",
            role: "assistant",
            content: greeting.content,
            timestamp: new Date(),
            mood: "happy" // Assistant starts happy
          }]);
        }
      } catch (e) {
        console.error("Error parsing stored responses", e);
        // If error parsing, use defaults and update the first message
        const greeting = defaultResponses.find(r => r.key === "greeting");
        if (greeting) {
          setMessages([{
            id: "1",
            role: "assistant",
            content: greeting.content,
            timestamp: new Date(),
            mood: "happy"
          }]);
        }
      }
    } else {
      // No saved responses, use defaults and update the first message
      const greeting = defaultResponses.find(r => r.key === "greeting");
      if (greeting) {
        setMessages([{
          id: "1",
          role: "assistant",
          content: greeting.content,
          timestamp: new Date(),
          mood: "happy"
        }]);
      }
    }
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Find the best response for user input with improved matching
  const findBestResponse = (input: string): AgentResponse => {
    const lowerInput = input.toLowerCase();
    
    // Handle direct requests for free agents specifically
    if (lowerInput.includes("want") && lowerInput.includes("free")) {
      const freeAgentResponse = responses.find(r => r.key === "free_agents");
      if (freeAgentResponse) return freeAgentResponse;
    }
    
    // Handle questions about if AI is right for their team
    if ((lowerInput.includes("if") || lowerInput.includes("should")) && 
        (lowerInput.includes("team") || lowerInput.includes("us") || lowerInput.includes("we")) && 
        (lowerInput.includes("ai") || lowerInput.includes("agent"))) {
      const rightForTeamResponse = responses.find(r => r.key === "right_for_team");
      if (rightForTeamResponse) return rightForTeamResponse;
    }
    
    // Handle direct "don't know" uncertainties
    if (lowerInput.includes("don't know") || lowerInput.includes("not sure") || lowerInput.includes("help me")) {
      const rightForTeamResponse = responses.find(r => r.key === "right_for_team");
      if (rightForTeamResponse) return rightForTeamResponse;
    }
    
    // Standard keyword matching with better organization by topic
    const matchingResponses = responses
      .filter(r => r.key !== "default" && r.keywords.some(keyword => lowerInput.includes(keyword)))
      .sort((a, b) => {
        // Prioritize responses with more keyword matches
        const aMatches = a.keywords.filter(keyword => lowerInput.includes(keyword)).length;
        const bMatches = b.keywords.filter(keyword => lowerInput.includes(keyword)).length;
        return bMatches - aMatches;
      });
    
    if (matchingResponses.length > 0) {
      return matchingResponses[0];
    }
    
    // If no matches found, return the default response
    return responses.find(r => r.key === "default") || responses[0];
  };

  // Function to determine mood based on message content
  const determineMood = (content: string, responseKey: string): Mood => {
    // Check for specific response types to set mood
    if (responseKey === "greeting" || responseKey === "free_agents") {
      return "excited";
    }
    
    if (responseKey === "right_for_team") {
      return "thinking";
    }
    
    // Check content for question marks to indicate "thinking" mood
    if (content.includes("?")) {
      return "thinking";
    }
    
    // Check for positive language
    if (content.toLowerCase().includes("great") || 
        content.toLowerCase().includes("good") ||
        content.toLowerCase().includes("popular") ||
        content.toLowerCase().includes("favorite")) {
      return "happy";
    }
    
    // Default mood
    return "neutral";
  };

  const handleSend = () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
      mood: "neutral", // Default mood for user messages
    };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");

    // Simulate AI response after a short delay
    setTimeout(() => {
      const bestResponse = findBestResponse(input);
      const mood = determineMood(bestResponse.content, bestResponse.key);
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: bestResponse.content,
        timestamp: new Date(),
        mood: mood,
      };
      setMessages((prev) => [...prev, assistantMessage]);
    }, 600);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSend();
    }
  };

  const resetChat = () => {
    // Find the greeting response
    const greeting = responses.find(r => r.key === "greeting");
    setMessages([
      {
        id: "reset",
        role: "assistant",
        content: greeting ? greeting.content : "Hi there! How can I help you today?",
        timestamp: new Date(),
        mood: "happy",
      },
    ]);
  };

  // Chat widget button in corner of screen
  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <div className="absolute -top-10 right-0 bg-white px-4 py-2 rounded-full shadow-md text-sm font-medium text-primary animate-bounce">
          Ask me anything!
        </div>
        <Button
          onClick={() => setIsOpen(true)}
          className="rounded-full w-14 h-14 shadow-lg flex items-center justify-center bg-accent hover:bg-accent/90 transition-all duration-300 border-2 border-white"
          aria-label="Open chat agent"
        >
          <Bot className="h-6 w-6 text-white" />
        </Button>
      </div>
    );
  }

  return (
    <Card className="fixed bottom-6 right-6 w-80 md:w-96 shadow-xl border border-gray-200 z-50">
      <CardHeader className="bg-primary text-white p-4 rounded-t-lg flex flex-row justify-between items-center">
        <CardTitle className="text-lg font-medium flex items-center">
          <Bot className="h-5 w-5 mr-2" />
          CSHacker Assistant
        </CardTitle>
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={resetChat}
            className="h-8 w-8 text-white hover:bg-primary/80"
            aria-label="Reset chat"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsOpen(false)}
            className="h-8 w-8 text-white hover:bg-primary/80"
            aria-label="Close chat"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="h-80 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.role === "assistant" ? "justify-start" : "justify-end"
              }`}
            >
              <div
                className={`max-w-[85%] rounded-lg p-3 ${
                  message.role === "assistant"
                    ? "bg-gray-100 text-gray-800 border border-gray-200"
                    : "bg-accent text-white shadow-sm"
                }`}
              >
                <div className="flex items-start gap-2">
                  {message.role === "assistant" && (
                    <Bot className="h-5 w-5 mt-0.5 flex-shrink-0 text-primary" />
                  )}
                  <div className="text-sm whitespace-pre-line">{message.content}</div>
                  {message.role === "user" && (
                    <User className="h-5 w-5 mt-0.5 flex-shrink-0" />
                  )}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </CardContent>
      <CardFooter className="p-3 border-t bg-gray-50">
        <div className="flex w-full items-center space-x-2">
          <Input
            placeholder="Ask me about CS + AI..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 border-gray-300 focus-visible:ring-primary"
          />
          <Button
            onClick={handleSend}
            size="icon"
            className="h-10 w-10 rounded-full bg-accent hover:bg-accent/90 transition-colors"
            aria-label="Send message"
          >
            <Send className="h-4 w-4 text-white" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default ChatAgent;