import React from "react";
import { 
  Smile, 
  Sun, 
  ThumbsUp, 
  ThumbsDown, 
  HelpCircle, 
  AlertCircle 
} from "lucide-react";

type Mood = "neutral" | "happy" | "excited" | "thinking" | "confused" | "sad";

interface MoodEmojiProps {
  mood: Mood;
  size?: number;
  className?: string;
}

const MoodEmoji: React.FC<MoodEmojiProps> = ({ mood, size = 16, className = "" }) => {
  const getEmoji = () => {
    switch (mood) {
      case "happy":
        return <Smile className={`text-green-500 ${className}`} size={size} />;
      case "excited":
        return <Sun className={`text-yellow-500 ${className}`} size={size} />;
      case "thinking":
        return <HelpCircle className={`text-blue-400 ${className}`} size={size} />;
      case "confused":
        return <AlertCircle className={`text-orange-400 ${className}`} size={size} />;
      case "sad":
        return <ThumbsDown className={`text-red-400 ${className}`} size={size} />;
      case "neutral":
      default:
        return <ThumbsUp className={`text-gray-400 ${className}`} size={size} />;
    }
  };

  return <span className="inline-flex items-center">{getEmoji()}</span>;
};

export default MoodEmoji;
export type { Mood };