import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Check, ArrowRight } from "lucide-react";
import { Helmet } from "react-helmet";

const AIStrategies = () => {
  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ItemList",
              "itemListElement": [
                {
                  "@type": "Product",
                  "position": 1,
                  "name": "AI-Powered Onboarding Agent",
                  "description": "Create seamless, personalized onboarding experiences that accelerate time-to-value and build strong foundations for lasting customer relationships.",
                  "url": "https://cshacker.ai/onboarding"
                },
                {
                  "@type": "Product",
                  "position": 2,
                  "name": "AI-Driven Renewal Management Agent",
                  "description": "Predict renewal risks early and deploy targeted interventions to secure renewals and strengthen customer relationships.",
                  "url": "https://cshacker.ai/renewal"
                },
                {
                  "@type": "Product",
                  "position": 3,
                  "name": "AI for Customer Expansion Agent",
                  "description": "Identify and capitalize on expansion opportunities with intelligent analysis of customer usage patterns, needs, and industry trends.",
                  "url": "https://cshacker.ai/expansion"
                },
                {
                  "@type": "Product",
                  "position": 4,
                  "name": "Managed Customer Agents",
                  "description": "Custom-built AI agents tailored to your specific customer success processes with ongoing management and optimization.",
                  "url": "https://cshacker.ai/managed-agents"
                }
              ]
            }
          `}
        </script>
      </Helmet>
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-dark">
              AI Implementation Across CS Functions
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
              Discover how to strategically deploy AI agents across multiple customer success functions and lifecycle stages for maximum impact.
            </p>
          </div>

          <div className="space-y-12">
            {/* Customer Research Strategies */}
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                  alt="AI-driven customer research strategies - Uncovering insights from customer behavior" 
                  className="rounded-xl shadow-xl w-full h-auto" 
                />
              </div>
              <div className="mt-10 lg:mt-0 lg:pl-8">
                <div className="text-accent font-semibold mb-3">CUSTOMER RESEARCH</div>
                <h3 className="text-2xl font-bold text-dark">Customer Insight Strategies</h3>
                <p className="mt-3 text-lg text-gray-600">
                  Learn how to leverage AI for analyzing user behavior, discovering hidden patterns, and turning raw data into actionable insights for your customer success team.
                </p>
                <ul className="mt-6 space-y-3">
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Uncovers insights hidden in usage patterns and data</span>
                  </li>
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Identifies friction points and optimization opportunities</span>
                  </li>
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Segments customers by behavior for targeted strategies</span>
                  </li>
                </ul>
                <div className="mt-8">
                  <Link href="/onboarding">
                    <Button
                      variant="link"
                      className="text-primary font-semibold hover:text-primary/80 flex items-center p-0"
                    >
                      Learn more about Onboarding Agent
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>

            {/* Retention Strategies */}
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="mt-10 lg:mt-0 lg:pr-8 order-2 lg:order-1">
                <div className="text-accent font-semibold mb-3">RETENTION</div>
                <h3 className="text-2xl font-bold text-dark">Predictive Renewal Optimization</h3>
                <p className="mt-3 text-lg text-gray-600">
                  Stop being blindsided by churn. Use AI to identify renewal risks 90+ days earlier than traditional methods and implement targeted intervention strategies.
                </p>
                <ul className="mt-6 space-y-3">
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Predictive analytics for identifying at-risk accounts</span>
                  </li>
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Automated health scoring and trend analysis</span>
                  </li>
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Personalized renewal playbooks based on customer data</span>
                  </li>
                </ul>
                <div className="mt-8">
                  <Link href="/renewal">
                    <Button
                      variant="link"
                      className="text-primary font-semibold hover:text-primary/80 flex items-center p-0"
                    >
                      Learn more about Renewal Agent
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="relative order-1 lg:order-2">
                <img
                  src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                  alt="AI-powered retention strategies - Predicting and preventing customer churn"
                  className="rounded-xl shadow-xl w-full h-auto"
                />
              </div>
            </div>

            {/* Growth Strategies */}
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                  alt="AI-powered growth strategies - Identifying expansion opportunities within your customer base"
                  className="rounded-xl shadow-xl w-full h-auto"
                />
              </div>
              <div className="mt-10 lg:mt-0 lg:pl-8">
                <div className="text-accent font-semibold mb-3">GROWTH</div>
                <h3 className="text-2xl font-bold text-dark">Expansion Opportunity Playbooks</h3>
                <p className="mt-3 text-lg text-gray-600">
                  Discover proven frameworks for identifying expansion signals in customer usage patterns and implementing effective upsell or cross-sell conversations at the perfect moment.
                </p>
                <ul className="mt-6 space-y-3">
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>How to detect usage patterns that signal expansion readiness</span>
                  </li>
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Frameworks for scoring and prioritizing growth opportunities</span>
                  </li>
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Templates for crafting value-focused expansion conversations</span>
                  </li>
                </ul>
                <div className="mt-8">
                  <Link href="/expansion">
                    <Button
                      variant="link"
                      className="text-primary font-semibold hover:text-primary/80 flex items-center p-0"
                    >
                      Learn more about Expansion Agent
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>

            {/* Managed Customer Agents */}
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="mt-10 lg:mt-0 lg:pr-8 order-2 lg:order-1">
                <div className="text-accent font-semibold mb-3">CUSTOM SOLUTIONS</div>
                <h3 className="text-2xl font-bold text-dark">Managed Customer Agents</h3>
                <p className="mt-3 text-lg text-gray-600">
                  Need something more specialized? We build and manage custom AI agents tailored to your specific customer success processes.
                </p>
                <ul className="mt-6 space-y-3">
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Custom-built for your unique workflows</span>
                  </li>
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Ongoing management and optimization</span>
                  </li>
                  <li className="flex">
                    <Check className="text-success h-5 w-5 mt-1 mr-2" />
                    <span>Dedicated support from CS AI experts</span>
                  </li>
                </ul>
                <div className="mt-8">
                  <Link href="/managed-agents">
                    <Button
                      variant="link"
                      className="text-primary font-semibold hover:text-primary/80 flex items-center p-0"
                    >
                      Learn more about Managed Customer Agents
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="relative order-1 lg:order-2">
                <img
                  src="https://images.unsplash.com/photo-1573164713988-8665fc963095?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                  alt="Managed Custom AI Agents for Customer Success - Tailored solutions for your team"
                  className="rounded-xl shadow-xl w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AIStrategies;