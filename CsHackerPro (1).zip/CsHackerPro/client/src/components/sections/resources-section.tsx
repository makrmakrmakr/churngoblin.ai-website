import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const ResourcesSection = () => {
  const resources = [
    {
      type: "Guide",
      title: "The Ultimate Guide to AI in Customer Success",
      description: "Learn how artificial intelligence is transforming customer success operations and how to implement it effectively.",
      image: "https://images.unsplash.com/photo-1550432163-9cb326104944?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "#",
      linkText: "Read More"
    },
    {
      type: "Webinar",
      title: "5 Proven Strategies to Reduce Churn Using AI",
      description: "Join us for this on-demand webinar to discover how leading CS teams are leveraging AI to identify and address churn risks.",
      image: "https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "#",
      linkText: "Watch Now"
    },
    {
      type: "Report",
      title: "2023 Customer Success Benchmarks Report",
      description: "Access the latest data and insights on CS metrics, team structures, and technology adoption across industries.",
      image: "https://images.unsplash.com/photo-1532622785990-d2c36a76f5a6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "#",
      linkText: "Download Report"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-dark">Latest CS Resources</h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Actionable insights and strategies to elevate your customer success practice.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {resources.map((resource, index) => (
            <div key={index} className="bg-white rounded-xl overflow-hidden shadow-md border border-gray-100">
              <div className="h-48 w-full overflow-hidden">
                <img
                  src={resource.image}
                  alt={resource.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="text-xs text-gray-500 uppercase tracking-widest mb-2">
                  {resource.type}
                </div>
                <h3 className="text-lg font-bold text-dark mb-2">{resource.title}</h3>
                <p className="text-gray-600 mb-4">{resource.description}</p>
                <a
                  href={resource.link}
                  className="text-primary font-medium hover:text-primary/80"
                >
                  {resource.linkText} →
                </a>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <Link href="/resources">
            <Button
              variant="outline"
              className="border-gray-300 text-dark bg-white hover:bg-gray-50"
            >
              View All Resources
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ResourcesSection;
