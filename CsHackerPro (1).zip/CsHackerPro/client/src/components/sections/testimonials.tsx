import { Star } from "lucide-react";

const Testimonials = () => {
  const testimonials = [
    {
      quote: "CSHacker's AI onboarding solution reduced our time-to-value by 40% while improving customer satisfaction scores. The combination of automation and human touch is exactly what we needed.",
      author: "Jane Doe",
      title: "VP of Customer Success, TechCorp",
      initials: "JD"
    },
    {
      quote: "The renewal predictions from CSHacker's AI have been incredibly accurate, allowing us to intervene early with at-risk accounts. We've seen a 25% improvement in retention since implementation.",
      author: "Michael Smith",
      title: "Director of Customer Success, GrowthSaaS",
      initials: "MS"
    },
    {
      quote: "We've increased our expansion revenue by 30% using CSHacker's AI to identify growth opportunities. The platform has paid for itself many times over in just the first quarter.",
      author: "Alex Johnson",
      title: "CS Operations Manager, Enterprise Solutions",
      initials: "AJ"
    }
  ];

  return (
    <section className="py-16 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-dark">
            Trusted by Customer Success Leaders
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Hear from CS professionals who have transformed their operations with CSHacker.
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-gray-50 rounded-xl p-8 shadow-sm border border-gray-100">
              <div className="flex items-center mb-6">
                <div className="text-amber-400 flex">
                  {Array(5).fill(0).map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-current" />
                  ))}
                </div>
              </div>
              <blockquote className="text-gray-700 mb-4">
                "{testimonial.quote}"
              </blockquote>
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center text-gray-600">
                  {testimonial.initials}
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-dark">{testimonial.author}</p>
                  <p className="text-sm text-gray-500">{testimonial.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
