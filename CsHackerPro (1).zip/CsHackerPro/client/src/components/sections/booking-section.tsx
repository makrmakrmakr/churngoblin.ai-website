import { Button } from "@/components/ui/button";
import { Calendar, Clock, Mail } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const BookingSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-dark">Get in Touch</h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Book a consultation or send me an email to discuss how AI can transform your customer success operations.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-2">
          {/* Calendar Booking Card */}
          <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
            <CardContent className="p-8 flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
                <Calendar className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-dark mb-3">Schedule a Call</h3>
              <p className="text-gray-600 mb-6">
                Book a 30-minute consultation to discuss your customer success challenges and how AI agents can help.
              </p>
              <div className="flex items-center justify-center text-gray-600 mb-6">
                <Clock className="h-5 w-5 mr-2" />
                <span>30 minutes • Virtual meeting</span>
              </div>
              <Button 
                className="w-full bg-primary hover:bg-primary/90"
                onClick={() => window.open("https://calendly.com/katereed", "_blank")}
              >
                Book a Time
              </Button>
            </CardContent>
          </Card>

          {/* Email Contact Card */}
          <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
            <CardContent className="p-8 flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mb-6">
                <Mail className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-bold text-dark mb-3">Send an Email</h3>
              <p className="text-gray-600 mb-6">
                Have questions or want to discuss a custom solution? Send me an email and I'll get back to you within 24 hours.
              </p>
              <div className="flex items-center justify-center text-gray-600 mb-6">
                <span className="font-medium">kate@cshacker.ai</span>
              </div>
              <Button 
                variant="outline"
                className="w-full border-accent text-accent hover:bg-accent/5"
                onClick={() => window.location.href = "mailto:kate@cshacker.ai"}
              >
                Send Email
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default BookingSection;