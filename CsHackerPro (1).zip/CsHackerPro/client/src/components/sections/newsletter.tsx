import NewsletterForm from "@/components/newsletter-form";

const Newsletter = () => {
  return (
    <section className="bg-gradient-to-r from-primary to-secondary py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold text-white">Stay Updated with CS Insights</h2>
            <p className="mt-4 text-lg text-white/80">
              Join 10,000+ customer success professionals receiving our weekly insights on AI-powered CS strategies.
            </p>
          </div>
          <div className="mt-8 lg:mt-0">
            <NewsletterForm />
            <p className="mt-3 text-sm text-white/70">
              We care about your data. Read our <a href="#" className="text-white underline">Privacy Policy</a>.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;
