import { Button } from "@/components/ui/button";

interface CTASectionProps {
  title?: string;
  description?: string;
  testimonialText?: string;
  testimonialAuthor?: string;
  primaryButtonText?: string;
  secondaryButtonText?: string;
  buttonLink?: string;
  hideTestimonial?: boolean;
}

const CTASection = ({
  title = "Hack Your CS Operations with AI Playbooks",
  description = "Get immediate access to proven AI implementation strategies that CS leaders are using to outperform their peers.",
  testimonialText = "By implementing these AI strategies, we now handle 2.5x more accounts with the same team size while delivering more personalized service.",
  testimonialAuthor = "VP of Customer Success, Enterprise SaaS",
  primaryButtonText = "Get Implementation Playbooks",
  secondaryButtonText = "Browse Success Stories",
  buttonLink = "#",
  hideTestimonial = false
}: CTASectionProps) => {
  return (
    <section className="bg-dark py-12 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            {title}
          </h2>
          <p className="mt-4 text-xl text-gray-300">
            {description}
          </p>
          
          {!hideTestimonial && (
            <div className="mt-6 max-w-2xl mx-auto bg-white/10 rounded-lg p-4">
              <p className="text-white text-lg">
                "{testimonialText}" <span className="block mt-1 text-accent font-semibold">- {testimonialAuthor}</span>
              </p>
            </div>
          )}
          
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="bg-accent hover:bg-accent/90 text-white"
              asChild
            >
              <a href={buttonLink}>{primaryButtonText}</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent border-white text-white hover:bg-white/10"
              asChild
            >
              <a href={buttonLink}>{secondaryButtonText}</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
