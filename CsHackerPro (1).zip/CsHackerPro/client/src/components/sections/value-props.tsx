import {
  BookOpen,
  Mail,
  Users,
  Clock,
  BarChart2,
  Bot,
} from "lucide-react";

const ValueProps = () => {
  const features = [
    {
      icon: <BookOpen className="text-[#e2ff00] text-xl" />,
      title: "2 Hours Back in Your Day",
      description: "Stop writing the same damn emails. Our templates produce personalized follow-ups in 30 seconds. One CSM saved 37 hours in a month."
    },
    {
      icon: <Clock className="text-[#9400ff] text-xl" />,
      title: "QBRs That Don't Suck (In 1/4 The Time)",
      description: "Auto-generate insights your customers actually give a shit about. No more spreadsheet hell. One team cut prep from 6 hours to 90 minutes."
    },
    {
      icon: <Mail className="text-[#00FF84] text-xl" />,
      title: "Tickets Closed While You Sleep",
      description: "See exactly which support issues AI can handle without humans (and which ones to keep far away from AI). One team closed 43% more tickets."
    },
    {
      icon: <BarChart2 className="text-[#e2ff00] text-xl" />,
      title: "Spot Churn 60 Days Earlier",
      description: "Stop getting blindsided by cancellations. Simple models that identify at-risk accounts 2 months before traditional warning signs appear."
    },
    {
      icon: <Users className="text-[#9400ff] text-xl" />,
      title: "Docs Customers Actually Read",
      description: "Generate personalized guides that focus on your customer's exact use case. One team saw self-service resolution jump by 52%."
    },
    {
      icon: <Bot className="text-[#00FF84] text-xl" />,
      title: "2-3x More Accounts Per CSM",
      description: "Handle more customers without burning out your team. One company increased CSM capacity by 240% by cutting out the low-value busywork."
    }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-dark">
            Real CS Problems AI <span className="text-[#9400ff]">Actually</span> Solves
          </h2>
          <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-600">
            Enough AI bullshit. Here's where it actually delivers time savings and better results for CS teams today.
          </p>
          <div className="mt-8 flex justify-center">
            <div className="max-w-3xl mx-auto px-6 py-4 bg-[#101735] rounded-lg">
              <p className="text-lg text-white font-medium">
                Not theoretical. Not "coming soon." These are being used by real CS teams <span className="text-[#00FF84] font-bold">right now</span> with concrete metrics and implementation timelines under 30 days.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-16">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className="relative p-6 bg-white rounded-lg shadow-md border border-gray-100 transition hover:shadow-lg"
              >
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-bold text-dark">{feature.title}</h3>
                <p className="mt-2 text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ValueProps;
