import { Button } from "@/components/ui/button";
import { BookOpen, Code, Users } from "lucide-react";

const Hero = () => {
  return (
    <section className="relative bg-[#101735] overflow-hidden">
      <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
        <div className="md:w-2/3">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            AI in CS: What Actually <span className="text-[#00FF84]">Works</span>
          </h1>
          <p className="mt-6 max-w-3xl text-xl text-white">
            No bullshit, no vendor pitches. Just <span className="font-semibold text-[#e2ff00]">concrete ways real CS teams use AI</span> to slash busywork, solve problems faster, and let humans do what they're actually good at.
          </p>
          
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4 text-white">
            <div className="flex items-start space-x-2">
              <BookOpen className="h-6 w-6 mt-1 text-[#e2ff00]" />
              <div>
                <h3 className="font-semibold text-[#e2ff00]">Real CS Teams, Real Results</h3>
                <p className="text-white/80 text-sm">Not theory. Actual metrics from teams with actual customers.</p>
              </div>
            </div>
            <div className="flex items-start space-x-2">
              <Code className="h-6 w-6 mt-1 text-[#9400ff]" />
              <div>
                <h3 className="font-semibold text-[#9400ff]">Copy-Paste Solutions</h3>
                <p className="text-white/80 text-sm">Prompts and workflows you can steal today. We tested them.</p>
              </div>
            </div>
            <div className="flex items-start space-x-2">
              <Users className="h-6 w-6 mt-1 text-[#00FF84]" />
              <div>
                <h3 className="font-semibold text-[#00FF84]">No Crap Tools</h3>
                <p className="text-white/80 text-sm">Free and paid AI tools that actually move the needle.</p>
              </div>
            </div>
          </div>
          
          <div className="mt-10 flex flex-wrap gap-4">
            <a href="/forum">
              <Button
                size="lg"
                className="bg-[#00FF84] hover:bg-[#00FF84]/90 text-[#101735] font-bold shadow-lg"
              >
                Get Started
              </Button>
            </a>
            <a href="/ai-agents">
              <Button
                size="lg"
                variant="outline"
                className="border-[#A731E8] text-[#A731E8] hover:bg-[#A731E8]/10 bg-transparent font-bold"
              >
                Try AI Tools
              </Button>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
