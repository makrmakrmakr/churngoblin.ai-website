import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Check, ArrowRight } from "lucide-react";
import { Helmet } from "react-helmet";

const AIStrategies = () => {
  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "ItemList",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Customer Onboarding AI Templates",
                  "description": "Proven AI prompts and templates that cut onboarding time by 40% while doubling customer engagement. Actual templates from real CS teams."
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "AI Churn Prediction Techniques",
                  "description": "Simple AI models that detect churn signals 60-90 days before your traditional dashboards show warning signs. No data science skills needed."
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "Account Expansion AI Frameworks",
                  "description": "Copy-paste prompts that scan customer data for expansion opportunities and generate personalized upsell proposals that actually convert."
                }
              ]
            }
          `}
        </script>
      </Helmet>
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-dark">
              AI Templates That <span className="text-[#9400ff]">Actually</span> Work
            </h2>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
              Steal these exact prompts and frameworks. No theory bullshit - these are the actual templates top CS teams use right now, with the metrics to prove they work.
            </p>
          </div>

          <div className="space-y-12">
            {/* Onboarding Templates */}
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                  alt="CS teams using AI templates to accelerate customer onboarding" 
                  className="rounded-xl shadow-xl w-full h-auto" 
                />
              </div>
              <div className="mt-10 lg:mt-0 lg:pl-8">
                <div className="text-[#e2ff00] font-bold mb-3">ONBOARDING</div>
                <h3 className="text-2xl font-bold text-dark">40% Faster Customer Setup</h3>
                <p className="mt-3 text-lg text-gray-600">
                  Cut your onboarding workload in half while making it better. These templates automate the boring stuff while keeping the human touch that actually matters.
                </p>
                <ul className="mt-6 space-y-3">
                  <li className="flex">
                    <Check className="text-[#00FF84] h-5 w-5 mt-1 mr-2" />
                    <span>28-second template: Turn sales notes into personalized onboarding plans</span>
                  </li>
                  <li className="flex">
                    <Check className="text-[#00FF84] h-5 w-5 mt-1 mr-2" />
                    <span>Custom training guides made in 5 minutes (not 3 hours)</span>
                  </li>
                  <li className="flex">
                    <Check className="text-[#00FF84] h-5 w-5 mt-1 mr-2" />
                    <span>Auto-populated success plans that customers actually follow</span>
                  </li>
                </ul>
                <div className="mt-8">
                  <Link href="/onboarding">
                    <Button
                      variant="link"
                      className="text-[#9400ff] font-bold flex items-center"
                    >
                      Steal these templates
                      <ArrowRight className="ml-1 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>

            {/* Retention Strategies */}
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="mt-10 lg:mt-0 lg:pr-8 order-2 lg:order-1">
                <div className="text-[#9400ff] font-bold mb-3">RETENTION</div>
                <h3 className="text-2xl font-bold text-dark">Spot Churn 60 Days Earlier</h3>
                <p className="mt-3 text-lg text-gray-600">
                  Dead simple AI techniques that catch at-risk accounts 2 months before they hit your dashboards. Fix problems while you still have time to save the account.
                </p>
                <ul className="mt-6 space-y-3">
                  <li className="flex">
                    <Check className="text-[#00FF84] h-5 w-5 mt-1 mr-2" />
                    <span>Email scanner that spots unhappy customers (93% accurate)</span>
                  </li>
                  <li className="flex">
                    <Check className="text-[#00FF84] h-5 w-5 mt-1 mr-2" />
                    <span>Meeting analyzer that catches "I'll think about it" bullshit</span>
                  </li>
                  <li className="flex">
                    <Check className="text-[#00FF84] h-5 w-5 mt-1 mr-2" />
                    <span>Intervention scripts that actually fix the problems</span>
                  </li>
                </ul>
                <div className="mt-8">
                  <Link href="/renewal">
                    <Button
                      variant="link"
                      className="text-[#9400ff] font-bold flex items-center"
                    >
                      Steal these templates
                      <ArrowRight className="ml-1 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="relative order-1 lg:order-2">
                <img
                  src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                  alt="CS team using AI to predict and prevent customer churn"
                  className="rounded-xl shadow-xl w-full h-auto"
                />
              </div>
            </div>

            {/* Growth Strategies */}
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                  alt="CS team using AI to identify expansion opportunities with existing customers"
                  className="rounded-xl shadow-xl w-full h-auto"
                />
              </div>
              <div className="mt-10 lg:mt-0 lg:pl-8">
                <div className="text-[#00FF84] font-bold mb-3">GROWTH</div>
                <h3 className="text-2xl font-bold text-dark">35% More Expansion Revenue</h3>
                <p className="mt-3 text-lg text-gray-600">
                  Stop leaving cash on the table. These frameworks spot perfect upsell moments and generate personalized pitches your customers actually say yes to.
                </p>
                <ul className="mt-6 space-y-3">
                  <li className="flex">
                    <Check className="text-[#00FF84] h-5 w-5 mt-1 mr-2" />
                    <span>Account analyzer that spots who's ready to upgrade right now</span>
                  </li>
                  <li className="flex">
                    <Check className="text-[#00FF84] h-5 w-5 mt-1 mr-2" />
                    <span>Custom pitch generator (converts 3x better than templates)</span>
                  </li>
                  <li className="flex">
                    <Check className="text-[#00FF84] h-5 w-5 mt-1 mr-2" />
                    <span>Objection-handling scripts that actually close deals</span>
                  </li>
                </ul>
                <div className="mt-8">
                  <Link href="/expansion">
                    <Button
                      variant="link"
                      className="text-[#9400ff] font-bold flex items-center"
                    >
                      Steal these templates
                      <ArrowRight className="ml-1 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AIStrategies;