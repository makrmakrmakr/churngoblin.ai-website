import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Check, ArrowRight } from "lucide-react";

// This component is being replaced by ai-agents.tsx
const AISolutions = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-dark">
            AI Agents for Every Stage of the Customer Journey
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Specialized AI agents designed for critical phases of your customer lifecycle.
          </p>
        </div>

        <div className="space-y-12">
          {/* Onboarding AI */}
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="AI Onboarding Solution" 
                className="rounded-xl shadow-xl w-full h-auto" 
              />
            </div>
            <div className="mt-10 lg:mt-0 lg:pl-8">
              <div className="text-accent font-semibold mb-3">ONBOARDING</div>
              <h3 className="text-2xl font-bold text-dark">AI-Powered Onboarding</h3>
              <p className="mt-3 text-lg text-gray-600">
                Create seamless, personalized onboarding experiences that accelerate time-to-value and build strong foundations for lasting customer relationships.
              </p>
              <ul className="mt-6 space-y-3">
                <li className="flex">
                  <Check className="text-success h-5 w-5 mt-1 mr-2" />
                  <span>Automated workflow setup and customer training</span>
                </li>
                <li className="flex">
                  <Check className="text-success h-5 w-5 mt-1 mr-2" />
                  <span>Intelligent resource recommendations based on customer profile</span>
                </li>
                <li className="flex">
                  <Check className="text-success h-5 w-5 mt-1 mr-2" />
                  <span>Early risk detection and proactive intervention</span>
                </li>
              </ul>
              <div className="mt-8">
                <Link href="/onboarding">
                  <Button
                    variant="link"
                    className="text-primary font-semibold hover:text-primary/80 flex items-center p-0"
                  >
                    Learn more about Onboarding AI
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* Renewal AI */}
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
            <div className="mt-10 lg:mt-0 lg:pr-8 order-2 lg:order-1">
              <div className="text-accent font-semibold mb-3">RETENTION</div>
              <h3 className="text-2xl font-bold text-dark">AI-Driven Renewal Management</h3>
              <p className="mt-3 text-lg text-gray-600">
                Predict renewal risks early and deploy targeted interventions to secure renewals and strengthen customer relationships.
              </p>
              <ul className="mt-6 space-y-3">
                <li className="flex">
                  <Check className="text-success h-5 w-5 mt-1 mr-2" />
                  <span>Predictive analytics for identifying at-risk accounts</span>
                </li>
                <li className="flex">
                  <Check className="text-success h-5 w-5 mt-1 mr-2" />
                  <span>Automated health scoring and trend analysis</span>
                </li>
                <li className="flex">
                  <Check className="text-success h-5 w-5 mt-1 mr-2" />
                  <span>Personalized renewal playbooks based on customer data</span>
                </li>
              </ul>
              <div className="mt-8">
                <Link href="/renewal">
                  <Button
                    variant="link"
                    className="text-primary font-semibold hover:text-primary/80 flex items-center p-0"
                  >
                    Learn more about Renewal AI
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </Link>
              </div>
            </div>
            <div className="relative order-1 lg:order-2">
              <img
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                alt="AI Renewal Solution"
                className="rounded-xl shadow-xl w-full h-auto"
              />
            </div>
          </div>

          {/* Expansion AI */}
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                alt="AI Expansion Solution"
                className="rounded-xl shadow-xl w-full h-auto"
              />
            </div>
            <div className="mt-10 lg:mt-0 lg:pl-8">
              <div className="text-accent font-semibold mb-3">GROWTH</div>
              <h3 className="text-2xl font-bold text-dark">AI for Customer Expansion</h3>
              <p className="mt-3 text-lg text-gray-600">
                Identify and capitalize on expansion opportunities with intelligent analysis of customer usage patterns, needs, and industry trends.
              </p>
              <ul className="mt-6 space-y-3">
                <li className="flex">
                  <Check className="text-success h-5 w-5 mt-1 mr-2" />
                  <span>AI-generated expansion recommendations</span>
                </li>
                <li className="flex">
                  <Check className="text-success h-5 w-5 mt-1 mr-2" />
                  <span>Opportunity scoring based on customer fit and readiness</span>
                </li>
                <li className="flex">
                  <Check className="text-success h-5 w-5 mt-1 mr-2" />
                  <span>Automated touchpoints to nurture growth opportunities</span>
                </li>
              </ul>
              <div className="mt-8">
                <Link href="/expansion">
                  <Button
                    variant="link"
                    className="text-primary font-semibold hover:text-primary/80 flex items-center p-0"
                  >
                    Learn more about Expansion AI
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AISolutions;
