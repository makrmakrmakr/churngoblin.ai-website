import { Check, ArrowRight, Zap, BarChart3, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const CSTransformation = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
          <div className="mb-12 lg:mb-0">
            <div className="rounded-xl shadow-xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                alt="Customer Success team working with AI tools"
                className="w-full h-auto object-cover object-center"
              />
            </div>
          </div>
          <div>
            <span className="text-accent font-semibold">AI TRANSFORMATION FRAMEWORK</span>
            <h2 className="mt-2 text-3xl font-bold text-dark">The Three-Step CS AI Transformation</h2>
            <p className="mt-4 text-lg text-gray-600">
              Leading CS teams are following a proven path to transform their operations with AI. This three-phase approach ensures you maintain the human touch while dramatically expanding your team's capabilities.
            </p>
            
            <div className="mt-8 space-y-6">
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white font-bold">1</div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold flex items-center">
                    <Zap className="text-primary mr-2 h-5 w-5" />
                    Automate the Obvious
                  </h3>
                  <p className="text-gray-600 mt-1">
                    Start with high-volume, low-complexity tasks that consume valuable CSM time. This builds immediate team capacity for higher-value activities.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white font-bold">2</div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold flex items-center">
                    <BarChart3 className="text-primary mr-2 h-5 w-5" />
                    Predict & Prevent
                  </h3>
                  <p className="text-gray-600 mt-1">
                    Deploy AI systems that identify risks and opportunities before they're obvious, turning your team from reactive to proactive.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white font-bold">3</div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold flex items-center">
                    <Users className="text-primary mr-2 h-5 w-5" />
                    Reorganize for AI + Human Synergy
                  </h3>
                  <p className="text-gray-600 mt-1">
                    Create new CS team structures where AI handles routine operations while humans focus on relationship-building and strategic guidance.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <Link href="/resources">
                <Button
                  variant="default"
                  className="bg-primary hover:bg-primary/90 flex items-center"
                >
                  Access transformation resources
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CSTransformation;
