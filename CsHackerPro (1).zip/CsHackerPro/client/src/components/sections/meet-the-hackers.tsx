import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

interface HackerCardProps {
  name: string;
  role: string;
  company: string;
  image: string;
  specialty: string;
  linkedIn?: string;
}

const HackerCard = ({ name, role, company, image, specialty, linkedIn }: HackerCardProps) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="p-6">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 rounded-full overflow-hidden">
            <img 
              src={image} 
              alt={name} 
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h3 className="font-bold text-xl text-dark">{name}</h3>
            <p className="text-gray-600">{role}, {company}</p>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center mb-2">
            <span className="text-accent font-semibold text-sm">HOW I'M USING AI</span>
          </div>
          <p className="text-gray-700">{specialty}</p>
        </div>
        {linkedIn && (
          <div className="mt-4">
            <a 
              href={linkedIn}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary text-sm hover:underline flex items-center"
            >
              Connect on LinkedIn
              <ArrowRight className="ml-1 w-3 h-3" />
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

const MeetTheHackers = () => {
  // Community hackers who contribute to the platform
  const hackers = [
    {
      name: "Alex Rivera",
      role: "CS AI Tinkerer",
      company: "CustomerScale",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80",
      specialty: "Hacked together a GPT that digs through our knowledge base. Cut ticket volume 40% without a big budget.",
      linkedIn: "#"
    },
    {
      name: "Sophia Chen",
      role: "Prediction Builder",
      company: "Dataploy",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80",
      specialty: "Built a no-code churn prediction tool with Claude API. 85% accuracy, zero data scientists needed. Happy to share how.",
      linkedIn: "#"
    },
    {
      name: "Marcus Johnson",
      role: "Workflow Hacker",
      company: "Tekflow Systems",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80",
      specialty: "Glued together onboarding automation with Zapier + GPT. Customers get value 62% faster. No coding skills required.",
      linkedIn: "#"
    },
    {
      name: "Leila Patel",
      role: "Expansion Hacker",
      company: "GrowthMasters",
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80",
      specialty: "Made a custom GPT that finds upsell opportunities in call recordings. My CSMs love it, no training required.",
      linkedIn: "#"
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-dark">
            Meet the Hackers
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Just CS folks who've figured out ways to make our jobs easier with AI. No fancy titles or corporate speak - just real results.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {hackers.map((hacker, index) => (
            <HackerCard
              key={index}
              name={hacker.name}
              role={hacker.role}
              company={hacker.company}
              image={hacker.image}
              specialty={hacker.specialty}
              linkedIn={hacker.linkedIn}
            />
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link href="/forum">
            <Button
              variant="outline"
              className="border-primary text-primary hover:bg-primary hover:text-white"
            >
              Join the hacking community
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default MeetTheHackers;