import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Download, FileText, BarChart } from "lucide-react";

const CaseStudies = () => {
  const caseStudies = [
    {
      title: "CS Team Efficiency Study 2024",
      description: "How AI agents are helping CS teams handle 2.7x more accounts without adding headcount.",
      type: "REPORT",
      icon: <FileText className="h-6 w-6 text-primary" />,
      downloadLink: "#",
    },
    {
      title: "AI Onboarding ROI Calculator",
      description: "Calculate the potential time and cost savings from implementing AI in your onboarding process.",
      type: "CALCULATOR",
      icon: <BarChart className="h-6 w-6 text-primary" />,
      downloadLink: "#",
    },
    {
      title: "B2B SaaS Renewal Case Study",
      description: "How a B2B SaaS company increased renewal rates by 24% in one quarter using AI agents.",
      type: "CASE STUDY",
      icon: <FileText className="h-6 w-6 text-primary" />,
      downloadLink: "#",
    },
    {
      title: "Enterprise CS Transformation",
      description: "Major enterprise tech company scales CS operations while improving CSAT scores.",
      type: "CASE STUDY",
      icon: <FileText className="h-6 w-6 text-primary" />,
      downloadLink: "#",
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-dark">Reports & Case Studies</h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Evidence-based insights on how AI is transforming customer success.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {caseStudies.map((study, index) => (
            <Card key={index} className="border border-gray-100 shadow-md hover:shadow-lg transition">
              <CardContent className="p-6 flex flex-col h-full">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    {study.icon}
                  </div>
                  <span className="text-xs font-semibold text-gray-500">{study.type}</span>
                </div>
                <h3 className="text-lg font-bold text-dark mb-2">{study.title}</h3>
                <p className="text-gray-600 mb-4 flex-grow">{study.description}</p>
                <Link href={study.downloadLink}>
                  <Button 
                    variant="outline" 
                    className="w-full flex items-center justify-center gap-2 mt-auto"
                  >
                    <Download className="h-4 w-4" />
                    Download
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-10">
          <Link href="/resources">
            <Button
              variant="link"
              className="text-primary flex items-center mx-auto"
            >
              View all resources
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CaseStudies;