import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Menu, Bot, BookOpen, Users, FileText } from "lucide-react";

const Navbar = () => {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/">
              <div className="text-xl font-bold cursor-pointer flex items-center bg-[#101735] py-1 px-2 rounded-md">
                <span className="font-black text-[#e2ff00] text-xl">CHURN</span>
                <span className="font-bold text-[#9400ff] text-xl">GOBLIN</span>
                <span className="font-bold text-[#00FF84] text-xl">.ai</span>
              </div>
            </Link>
          </div>
          <div className="hidden md:flex md:items-center md:space-x-4">
            <Link href="/">
              <span
                className={cn(
                  "px-3 py-2 rounded-md text-sm font-medium text-dark hover:bg-gray-100 cursor-pointer",
                  location === "/" && "bg-gray-100"
                )}
              >
                Home
              </span>
            </Link>
            <Link href="/ai-agents">
              <span
                className={cn(
                  "px-3 py-2 rounded-md text-sm font-medium text-dark hover:bg-gray-100 cursor-pointer",
                  location === "/ai-agents" && "bg-gray-100"
                )}
              >
                AI Tools
              </span>
            </Link>
            <Link href="/content">
              <span
                className={cn(
                  "px-3 py-2 rounded-md text-sm font-medium text-dark hover:bg-gray-100 cursor-pointer",
                  location === "/content" && "bg-gray-100"
                )}
              >
                Playbooks
              </span>
            </Link>
            <Link href="/forum">
              <span
                className={cn(
                  "px-3 py-2 rounded-md text-sm font-medium text-dark hover:bg-gray-100 cursor-pointer",
                  location === "/forum" && "bg-gray-100"
                )}
              >
                Community
              </span>
            </Link>
            <Link href="/about">
              <span
                className={cn(
                  "px-3 py-2 rounded-md text-sm font-medium text-dark hover:bg-gray-100 cursor-pointer",
                  location === "/about" && "bg-gray-100"
                )}
              >
                About
              </span>
            </Link>
          </div>
          <div className="hidden md:block">
            <Button className="bg-[#00FF84] hover:bg-[#00FF84]/90 text-[#101735] font-bold shadow-md">
              Try Free Tools
            </Button>
          </div>
          <div className="-mr-2 flex md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMobileMenu}
              aria-expanded="false"
              className="text-gray-400 hover:text-gray-500 hover:bg-gray-100"
            >
              <span className="sr-only">Open main menu</span>
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
        <div className={`md:hidden ${mobileMenuOpen ? "block" : "hidden"}`}>
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link href="/">
              <span className="block px-3 py-2 rounded-md text-base font-medium text-dark hover:bg-gray-100 cursor-pointer">
                Home
              </span>
            </Link>
            <div className="flex items-center px-3 py-2 font-medium text-gray-600 text-sm">
              <Bot className="h-4 w-4 mr-2" />
              AI TOOLS
            </div>
            <Link href="/ai-agents">
              <span className="block px-6 py-2 rounded-md text-base font-medium text-dark hover:bg-gray-100 cursor-pointer">
                CS AI Tools
              </span>
            </Link>
            <Link href="/custom-gpts">
              <span className="block px-6 py-2 rounded-md text-base font-medium text-dark hover:bg-gray-100 cursor-pointer">
                Custom GPTs
              </span>
            </Link>
            <div className="flex items-center px-3 py-2 font-medium text-gray-600 text-sm">
              <BookOpen className="h-4 w-4 mr-2" />
              RESOURCES
            </div>
            <Link href="/content">
              <span className="block px-6 py-2 rounded-md text-base font-medium text-dark hover:bg-gray-100 cursor-pointer">
                CS Playbooks
              </span>
            </Link>
            <Link href="/reports">
              <span className="block px-6 py-2 rounded-md text-base font-medium text-dark hover:bg-gray-100 cursor-pointer">
                Research & Reports
              </span>
            </Link>
            <div className="flex items-center px-3 py-2 font-medium text-gray-600 text-sm">
              <Users className="h-4 w-4 mr-2" />
              COMMUNITY
            </div>
            <Link href="/forum">
              <span className="block px-6 py-2 rounded-md text-base font-medium text-dark hover:bg-gray-100 cursor-pointer">
                CS Forum
              </span>
            </Link>
            <div className="flex items-center px-3 py-2 font-medium text-gray-600 text-sm">
              <FileText className="h-4 w-4 mr-2" />
              MORE
            </div>
            <Link href="/about">
              <span className="block px-6 py-2 rounded-md text-base font-medium text-dark hover:bg-gray-100 cursor-pointer">
                About Us
              </span>
            </Link>
            <Button className="w-full mt-2 bg-[#00FF84] hover:bg-[#00FF84]/90 text-[#101735] font-bold shadow-md">
              Try Free Tools
            </Button>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;