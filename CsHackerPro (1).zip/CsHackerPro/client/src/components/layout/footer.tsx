import { Link } from "wouter";
import {
  Linkedin,
  Twitter,
  Youtube,
  Mail,
} from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-dark pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="xl:grid xl:grid-cols-4 xl:gap-8">
          <div className="grid grid-cols-2 gap-8 xl:col-span-4">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-white tracking-wider uppercase">
                  AI Agents
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/onboarding">
                      <a className="text-base text-gray-300 hover:text-white">
                        Onboarding Agent
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/renewal">
                      <a className="text-base text-gray-300 hover:text-white">
                        Renewal Agent
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/expansion">
                      <a className="text-base text-gray-300 hover:text-white">
                        Expansion Agent
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/managed-agents">
                      <a className="text-base text-gray-300 hover:text-white">
                        Managed Customer Agents
                      </a>
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <h3 className="text-sm font-semibold text-white tracking-wider uppercase">
                  Resources
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/resources">
                      <a className="text-base text-gray-300 hover:text-white">
                        Blog
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources">
                      <a className="text-base text-gray-300 hover:text-white">
                        Guides
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources">
                      <a className="text-base text-gray-300 hover:text-white">
                        Webinars
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources">
                      <a className="text-base text-gray-300 hover:text-white">
                        Case Studies
                      </a>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-white tracking-wider uppercase">
                  Company
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/about">
                      <a className="text-base text-gray-300 hover:text-white">
                        About
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/about">
                      <a className="text-base text-gray-300 hover:text-white">
                        Team
                      </a>
                    </Link>
                  </li>
                  <li>
                    <a href="#" className="text-base text-gray-300 hover:text-white">
                      Careers
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-base text-gray-300 hover:text-white">
                      Contact
                    </a>
                  </li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <h3 className="text-sm font-semibold text-white tracking-wider uppercase">
                  Connect
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <a href="#" className="text-base text-gray-300 hover:text-white flex items-center">
                      <Linkedin className="w-4 h-4 mr-2" /> LinkedIn
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-base text-gray-300 hover:text-white flex items-center">
                      <Twitter className="w-4 h-4 mr-2" /> Twitter
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-base text-gray-300 hover:text-white flex items-center">
                      <Youtube className="w-4 h-4 mr-2" /> YouTube
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-base text-gray-300 hover:text-white flex items-center">
                      <Mail className="w-4 h-4 mr-2" /> Email
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-gray-700 pt-8">
          <p className="text-base text-gray-400 xl:text-center">
            &copy; {new Date().getFullYear()} CSHacker. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
