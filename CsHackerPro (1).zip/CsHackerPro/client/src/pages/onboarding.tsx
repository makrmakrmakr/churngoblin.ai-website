import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, ArrowRight } from "lucide-react";
import Newsletter from "@/components/sections/newsletter";
import CTASection from "@/components/sections/cta-section";
import ContactForm from "@/components/contact-form";
import { Helmet } from "react-helmet";

const Onboarding = () => {
  return (
    <>
      <Helmet>
        <title>AI Onboarding Agent for Customer Success | Reduce Time-to-Value by 40% | CSHacker</title>
        <meta name="description" content="Deploy our AI Onboarding Agent to create personalized customer journeys, accelerate time-to-value by 40%, and handle 3x more customers per CSM." />
        <meta name="keywords" content="customer success onboarding, AI onboarding agent, onboarding automation, CS onboarding tool, customer onboarding AI" />
        <link rel="canonical" href="https://cshacker.ai/onboarding" />
        <meta property="og:title" content="AI Onboarding Agent for Customer Success | Reduce Time-to-Value by 40% | CSHacker" />
        <meta property="og:description" content="Deploy our AI Onboarding Agent to create personalized customer journeys, accelerate time-to-value by 40%, and handle 3x more customers per CSM." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://cshacker.ai/onboarding" />
      </Helmet>
      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-r from-primary to-secondary overflow-hidden">
          <div className="absolute inset-0 bg-dark/30 mix-blend-multiply"></div>
          <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
            <div className="md:w-2/3">
              <div className="text-accent font-semibold text-white mb-3">ONBOARDING SOLUTION</div>
              <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
                AI-Powered Customer Onboarding
              </h1>
              <p className="mt-6 max-w-3xl text-xl text-white">
                Create seamless, personalized onboarding experiences that accelerate time-to-value and build strong foundations for lasting customer relationships.
              </p>
              <div className="mt-10 flex flex-wrap gap-4">
                <Button
                  size="lg"
                  className="bg-accent hover:bg-accent/90 text-white"
                >
                  Request a Demo
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10"
                >
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Key Features Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">Key Features</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                Intelligent tools to make your onboarding process more efficient and effective.
              </p>
            </div>

            <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Automated Customer Profiling</h3>
                  <p className="mt-2 text-gray-600">Our AI analyzes customer data to create tailored onboarding journeys based on business size, industry, and needs.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Personalized Resource Recommendations</h3>
                  <p className="mt-2 text-gray-600">AI recommends the most relevant training resources, documentation, and tutorials based on user roles and behavior.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Automated Workflow Setup</h3>
                  <p className="mt-2 text-gray-600">Automatically configure workflows, templates, and settings based on customer preferences and industry best practices.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Progress Tracking</h3>
                  <p className="mt-2 text-gray-600">Track customer onboarding progress with intuitive dashboards and receive alerts when interventions are needed.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Milestone Automation</h3>
                  <p className="mt-2 text-gray-600">Automatically trigger celebrations, follow-ups, and next steps when customers hit key onboarding milestones.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Human Handoff</h3>
                  <p className="mt-2 text-gray-600">Intelligent triggers alert CSMs when personal intervention is needed, with context about the customer's journey.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">How It Works</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                Our AI-powered onboarding solution seamlessly integrates with your existing processes.
              </p>
            </div>

            <div className="mt-16">
              <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                    alt="Customer Onboarding Process"
                    className="rounded-xl shadow-xl w-full h-auto"
                  />
                </div>
                <div className="mt-10 lg:mt-0 lg:pl-8">
                  <ol className="space-y-8">
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          1
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Customer Data Integration</h3>
                        <p className="mt-2 text-gray-600">
                          Our platform integrates with your CRM and other systems to gather relevant customer data.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          2
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">AI Profile Creation</h3>
                        <p className="mt-2 text-gray-600">
                          Our AI analyzes the data to create a comprehensive profile and recommended onboarding path.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          3
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Automated Journey Deployment</h3>
                        <p className="mt-2 text-gray-600">
                          Personalized onboarding workflows are automatically initiated with the right resources.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          4
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Progress Monitoring & Intervention</h3>
                        <p className="mt-2 text-gray-600">
                          AI continuously monitors progress, identifying when human intervention is needed.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          5
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Success Measurement</h3>
                        <p className="mt-2 text-gray-600">
                          Track time-to-value and other key metrics to continuously optimize your onboarding process.
                        </p>
                      </div>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Success Metrics Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">The Impact</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                Our customers see significant improvements in their onboarding metrics.
              </p>
            </div>

            <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
              <div className="text-center">
                <div className="text-primary text-5xl font-extrabold">40%</div>
                <p className="mt-2 text-gray-600">Faster time-to-value</p>
              </div>
              <div className="text-center">
                <div className="text-primary text-5xl font-extrabold">90%</div>
                <p className="mt-2 text-gray-600">Customer satisfaction</p>
              </div>
              <div className="text-center">
                <div className="text-primary text-5xl font-extrabold">65%</div>
                <p className="mt-2 text-gray-600">Reduction in support tickets</p>
              </div>
              <div className="text-center">
                <div className="text-primary text-5xl font-extrabold">3x</div>
                <p className="mt-2 text-gray-600">More customers onboarded per CSM</p>
              </div>
            </div>
          </div>
        </section>

        {/* Customer Testimonial */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center">
              <svg className="h-12 w-12 text-gray-400 mx-auto mb-4" fill="currentColor" viewBox="0 0 32 32" aria-hidden="true">
                <path d="M9.352 4C4.456 7.456 1 13.12 1 19.36c0 5.088 3.072 8.064 6.624 8.064 3.36 0 5.856-2.688 5.856-5.856 0-3.168-2.208-5.472-5.088-5.472-.576 0-1.344.096-1.536.192.48-3.264 3.552-7.104 6.624-9.024L9.352 4zm16.512 0c-4.8 3.456-8.256 9.12-8.256 15.36 0 5.088 3.072 8.064 6.624 8.064 3.264 0 5.856-2.688 5.856-5.856 0-3.168-2.304-5.472-5.184-5.472-.576 0-1.248.096-1.44.192.48-3.264 3.456-7.104 6.528-9.024L25.864 4z" />
              </svg>
              <p className="mt-4 text-2xl text-gray-600 italic">
                "CSHacker's AI onboarding solution reduced our time-to-value by 40% while improving customer satisfaction scores. The combination of automation and human touch is exactly what we needed."
              </p>
              <div className="mt-6">
                <div className="flex items-center justify-center">
                  <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center text-gray-600">JD</div>
                  <div className="ml-3 text-left">
                    <p className="text-sm font-medium text-dark">Jane Doe</p>
                    <p className="text-sm text-gray-500">VP of Customer Success, TechCorp</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-dark">Ready to transform your onboarding process?</h2>
                <p className="mt-4 text-lg text-gray-600">
                  Get in touch with our team to learn how our AI-powered onboarding solution can help you create exceptional customer experiences from day one.
                </p>
                <ul className="mt-8 space-y-4">
                  <li className="flex items-center">
                    <Check className="text-success h-5 w-5 mr-3" />
                    <span>Personalized demo with your data</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="text-success h-5 w-5 mr-3" />
                    <span>30-day free trial available</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="text-success h-5 w-5 mr-3" />
                    <span>Dedicated implementation support</span>
                  </li>
                </ul>
              </div>
              <div className="bg-gray-50 p-8 rounded-xl shadow-sm">
                <h3 className="text-xl font-bold text-dark mb-6">Contact Us</h3>
                <ContactForm />
              </div>
            </div>
          </div>
        </section>

        <CTASection />
        <Newsletter />
      </main>
    </>
  );
};

export default Onboarding;
