import { Helmet } from "react-helmet";
import { useEffect } from "react";
import { Badge } from "@/components/ui/badge";

// Define the HTML/JS as a string to embed directly
const htmlToEmbed = `
<div id="agent-form-container" style="font-family: sans-serif; max-width: 600px; border: 1px solid #101735; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.2); background-color: #fafafa;">
  <div style="display: flex; align-items: center; margin-bottom: 16px;">
    <div style="font-weight: bold; font-size: 18px; background-color: #101735; padding: 4px 8px; border-radius: 6px; display: inline-flex;">
      <span style="color: #e2ff00; font-weight: 900;">CHURN</span>
      <span style="color: #9400ff; font-weight: 700;">GOBLIN</span>
      <span style="color: #00FF84; font-weight: 700;">.ai</span>
    </div>
    <span style="margin-left: 8px; padding: 2px 8px; font-size: 12px; background: #A731E8; color: white; border-radius: 12px;">Free</span>
  </div>
  <form id="agentForm" style="display: flex; flex-direction: column; gap: 10px;">
    <label for="basicPromptInput" style="font-weight: 500; margin-bottom: -5px;">Paste your customer call notes/transcript:</label>
    <textarea
      id="basicPromptInput"
      name="basic_prompt"
      rows="4"
      placeholder="Example: 30-min call with Jane from Acme Corp. Discussed their onboarding challenges. Need to follow up about training resources and schedule next check-in."
      required
      style="padding: 10px; border: 1px solid #ccc; border-radius: 4px; resize: vertical;"
    ></textarea>
    <button
      type="submit"
      style="padding: 10px; background: #00FF84; color: #101735; border: none; cursor: pointer; border-radius: 4px; font-weight: bold; box-shadow: 0 2px 4px rgba(0,255,132,0.3);"
    >
      Generate Follow-Up Email (5 sec)
    </button>
    <div id="agentStatus" style="min-height: 1.5em; font-size: 0.9em;"></div>
  </form>
  <div id="agentResponseOutput" style="margin-top: 16px; padding: 16px; background: #F9F9F9; border: 1px solid #eee; border-radius: 4px; display: none;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
      <strong>Your Ready-to-Use Email:</strong>
      <button 
        id="copyEmailBtn" 
        style="padding: 4px 8px; background: #A731E8; color: white; border: none; border-radius: 4px; font-size: 12px; cursor: pointer; font-weight: bold;"
        onclick="navigator.clipboard.writeText(document.getElementById('agentResponseText').innerText).then(() => { this.textContent = 'Copied!'; setTimeout(() => { this.textContent = 'Copy Email'; }, 2000); })"
      >
        Copy Email
      </button>
    </div>
    <div id="agentResponseText" style="margin-top: 8px; white-space: pre-wrap; line-height: 1.5;"></div>
  </div>
</div>
`;

// Array of AI tools
const aiTools = [
  {
    id: "follow-up-email",
    name: "Follow-Up Email Generator",
    description: "Turn messy call notes into professional follow-up emails in 5 seconds. CSMs save 30+ minutes per day with this tool.",
    tags: ["Free", "Gmail", "Outlook"],
    isEmbed: true
  },
  {
    id: "churn-detector",
    name: "Email Sentiment Analyzer",
    description: "Detect customer frustration or churn risk from email threads. 93% accurate at flagging at-risk accounts 60+ days before traditional warning signs.",
    tags: ["Freemium", "Gmail", "Outlook", "Slack"],
    isEmbed: false,
    link: "/custom-gpts"
  },
  {
    id: "qbr-generator",
    name: "QBR Deck Builder",
    description: "Transform usage data into client-ready QBR presentations. Cut prep time from 3 hours to 20 minutes with data-backed slides.",
    tags: ["Paid", "PowerPoint", "Google Slides"],
    isEmbed: false,
    link: "/custom-gpts"
  }
];

const AIAgents = () => {
  // Inject the JavaScript after component mount
  useEffect(() => {
    // Add the event listener
    const script = document.createElement("script");
    script.innerHTML = `
      document.getElementById("agentForm").addEventListener("submit", async function (e) {
        e.preventDefault();
        const input = document.getElementById("basicPromptInput").value;
        const statusEl = document.getElementById("agentStatus");
        const outputBox = document.getElementById("agentResponseOutput");
        const outputText = document.getElementById("agentResponseText");

        statusEl.style.color = "#333";
        statusEl.textContent = "Working on your professional email...";
        outputBox.style.display = "none";

        try {
          const res = await fetch("https://api-lr.agent.ai/v1/action/invoke_agent", {
            method: "POST",
            headers: {
              "Authorization": "Bearer d06f0ecf55a87fceac4fdcb58a8b69c773d4716e96e78a62b9f60c36d3218498",
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ basic_prompt: "Write a professional, concise follow-up email based on these call notes: " + input })
          });

          const data = await res.json();
          console.log(":mag: Full agent response:", data);
          let raw = data?.output || data?.message || data?.response;
          if (!raw) raw = "No usable content returned.";
          
          outputText.innerHTML = raw;
          statusEl.style.color = "green";
          statusEl.textContent = "Email ready! You just saved 15 minutes.";
          outputBox.style.display = "block";
        } catch (err) {
          console.error(":x: Fetch error:", err);
          statusEl.style.color = "red";
          statusEl.textContent = "An error occurred while processing your request.";
        }
      });
    `;
    
    document.body.appendChild(script);
    
    return () => {
      // Clean up
      document.body.removeChild(script);
    };
  }, []);

  const embedCode = `<div id="agent-form-container" style="font-family: sans-serif; max-width: 600px; border: 1px solid #e2e8f0; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
  <div style="display: flex; align-items: center; margin-bottom: 16px;">
    <span style="font-weight: bold; font-size: 18px; color: #16a34a;">ChurnGoblin.ai</span>
    <span style="margin-left: 8px; padding: 2px 8px; font-size: 12px; background: #65a30d; color: white; border-radius: 12px;">Free</span>
  </div>
  <form id="agentForm" style="display: flex; flex-direction: column; gap: 10px;">
    <label for="basicPromptInput" style="font-weight: 500; margin-bottom: -5px;">Paste your customer call notes/transcript:</label>
    <textarea
      id="basicPromptInput"
      name="basic_prompt"
      rows="4"
      placeholder="Example: 30-min call with Jane from Acme Corp. Discussed their onboarding challenges. Need to follow up about training resources and schedule next check-in."
      required
      style="padding: 10px; border: 1px solid #ccc; border-radius: 4px; resize: vertical;"
    ></textarea>
    <button
      type="submit"
      style="padding: 10px; background: linear-gradient(135deg, #65a30d, #16a34a); color: white; border: none; cursor: pointer; border-radius: 4px; font-weight: 500;"
    >
      Generate Follow-Up Email (5 sec)
    </button>
    <div id="agentStatus" style="min-height: 1.5em; font-size: 0.9em;"></div>
  </form>
  <div id="agentResponseOutput" style="margin-top: 16px; padding: 16px; background: #F9F9F9; border: 1px solid #eee; border-radius: 4px; display: none;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
      <strong>Your Ready-to-Use Email:</strong>
      <button 
        id="copyEmailBtn" 
        style="padding: 4px 8px; background: #65a30d; color: white; border: none; border-radius: 4px; font-size: 12px; cursor: pointer;"
        onclick="navigator.clipboard.writeText(document.getElementById('agentResponseText').innerText).then(() => { this.textContent = 'Copied!'; setTimeout(() => { this.textContent = 'Copy Email'; }, 2000); })"
      >
        Copy Email
      </button>
    </div>
    <div id="agentResponseText" style="margin-top: 8px; white-space: pre-wrap; line-height: 1.5;"></div>
  </div>
</div>

<script>
  document.getElementById("agentForm").addEventListener("submit", async function (e) {
    e.preventDefault();
    const input = document.getElementById("basicPromptInput").value;
    const statusEl = document.getElementById("agentStatus");
    const outputBox = document.getElementById("agentResponseOutput");
    const outputText = document.getElementById("agentResponseText");

    statusEl.style.color = "#333";
    statusEl.textContent = "Working on your professional email...";
    outputBox.style.display = "none";

    try {
      const res = await fetch("https://api-lr.agent.ai/v1/action/invoke_agent", {
        method: "POST",
        headers: {
          "Authorization": "Bearer d06f0ecf55a87fceac4fdcb58a8b69c773d4716e96e78a62b9f60c36d3218498",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ basic_prompt: "Write a professional, concise follow-up email based on these call notes: " + input })
      });

      const data = await res.json();
      console.log(":mag: Full agent response:", data);
      let raw = data?.output || data?.message || data?.response;
      if (!raw) raw = "No usable content returned.";
      
      outputText.innerHTML = raw;
      statusEl.style.color = "#16a34a";
      statusEl.textContent = "Email ready! You just saved 15 minutes.";
      outputBox.style.display = "block";
    } catch (err) {
      console.error(":x: Fetch error:", err);
      statusEl.style.color = "red";
      statusEl.textContent = "An error occurred while processing your request.";
    }
  });
</script>`;

  return (
    <>
      <Helmet>
        <title>AI Tools for CS Teams | ChurnGoblin.ai</title>
        <meta name="description" content="Free and paid AI tools that actually help CS teams save time and spot churn risks early" />
      </Helmet>
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-10">
          <h1 className="text-4xl font-bold mb-3">CS AI Tools That Actually Work</h1>
          <p className="text-gray-600 mb-6 text-xl">
            Stop wasting time on theory. These are ready-to-use AI tools that real CS teams are using right now to save time and get better results.
          </p>
        </div>
        
        {/* AI Tools List */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {aiTools.map((tool) => (
            <div key={tool.id} className="border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="p-6">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-xl font-bold text-dark">{tool.name}</h3>
                  <Badge className="bg-lime-600">{tool.tags[0]}</Badge>
                </div>
                <p className="text-gray-600 mb-4">{tool.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {tool.tags.slice(1).map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">{tag}</Badge>
                  ))}
                </div>
                {tool.isEmbed ? (
                  <button className="w-full py-2 px-4 bg-gradient-to-r from-lime-500 to-green-600 text-white rounded-md hover:from-lime-600 hover:to-green-700 transition-colors">
                    Try It Now
                  </button>
                ) : (
                  <a href={tool.link} className="block w-full text-center py-2 px-4 bg-gradient-to-r from-lime-500 to-green-600 text-white rounded-md hover:from-lime-600 hover:to-green-700 transition-colors">
                    See Details
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <h2 className="text-3xl font-bold mb-5 border-b pb-2">Follow-Up Email Generator</h2>
        <div className="grid md:grid-cols-5 gap-8 mb-10">
          <div className="md:col-span-2">
            <h3 className="text-xl font-bold mb-3">Stop Wasting Time on Follow-up Emails</h3>
            <p className="text-gray-700 mb-4">
              The average CSM spends <span className="font-semibold">7+ hours a week</span> writing follow-up emails. This tool cuts that down to minutes.
            </p>
            <ul className="space-y-2 mb-6">
              <li className="flex items-start">
                <span className="text-teal-700 mr-2">✓</span>
                <span>Turn rough call notes into professional, action-oriented emails</span>
              </li>
              <li className="flex items-start">
                <span className="text-teal-700 mr-2">✓</span>
                <span>Includes clear next steps and action items automatically</span>
              </li>
              <li className="flex items-start">
                <span className="text-teal-700 mr-2">✓</span>
                <span>Maintains your tone and communication style</span>
              </li>
              <li className="flex items-start">
                <span className="text-teal-700 mr-2">✓</span>
                <span>Average time savings: 15 minutes per customer call</span>
              </li>
            </ul>
            <div className="flex items-center">
              <span className="text-sm font-semibold text-gray-600 mr-3">Works with:</span>
              <div className="flex space-x-2">
                <Badge variant="outline">Gmail</Badge>
                <Badge variant="outline">Outlook</Badge>
                <Badge variant="outline">Any Email Client</Badge>
              </div>
            </div>
          </div>
          <div className="md:col-span-3">
            {/* Agent form - directly injected HTML */}
            <div dangerouslySetInnerHTML={{ __html: htmlToEmbed }} className="rounded-lg overflow-hidden" />
          </div>
        </div>
        
        <hr className="my-12" />
        
        <h2 className="text-3xl font-bold mb-6">Add This Tool to Your Workflow</h2>
        <div className="grid md:grid-cols-2 gap-10 mb-12">
          <div>
            <h3 className="text-xl font-bold mb-3">Option 1: Embed on Your Internal Portal</h3>
            <p className="text-gray-600 mb-4">
              Add this tool directly to your team's internal wiki, SharePoint, or any other internal website by copying and pasting this HTML:
            </p>
            <div className="bg-gray-50 p-4 rounded-md border border-gray-200 overflow-x-auto mb-4 text-xs h-56 overflow-y-auto">
              <pre className="whitespace-pre-wrap"><code>{embedCode}</code></pre>
            </div>
            <button 
              onClick={() => {
                navigator.clipboard.writeText(embedCode);
                alert("Embed code copied to clipboard!");
              }}
              className="px-4 py-2 bg-gradient-to-r from-lime-500 to-green-600 text-white rounded hover:from-lime-600 hover:to-green-700"
            >
              Copy Embed Code
            </button>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-3">Option 2: Create a Custom ChurnGoblin.ai for Your Team</h3>
            <p className="text-gray-600 mb-4">
              Get a branded version of this tool with your company's look and feel, plus advanced features like:
            </p>
            <ul className="space-y-2 mb-6">
              <li className="flex items-start">
                <span className="text-teal-700 mr-2">✓</span>
                <span>Integration with your CRM/CS platform</span>
              </li>
              <li className="flex items-start">
                <span className="text-teal-700 mr-2">✓</span>
                <span>Your company's tone of voice and email templates</span>
              </li>
              <li className="flex items-start">
                <span className="text-teal-700 mr-2">✓</span>
                <span>Custom logic for different customer segments</span>
              </li>
              <li className="flex items-start">
                <span className="text-teal-700 mr-2">✓</span>
                <span>Advanced sentiment analysis and churn prediction</span>
              </li>
            </ul>
            <a href="/contact" className="px-6 py-3 bg-gradient-to-r from-lime-500 to-green-600 text-white rounded-md inline-block hover:from-lime-600 hover:to-green-700">
              Contact Us for Custom Setup
            </a>
          </div>
        </div>
      </main>
    </>
  );
};

export default AIAgents;