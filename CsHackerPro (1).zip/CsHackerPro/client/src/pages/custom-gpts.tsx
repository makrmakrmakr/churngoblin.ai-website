import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, ExternalLink } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Helmet } from "react-helmet";

// Types for our GPT directory
interface CustomGPT {
  id: string;
  name: string;
  description: string;
  category: string;
  useCase: string;
  author: string;
  url: string;
  stars: number;
  dateAdded: string;
  isOpenSource: boolean;
  promptExamples?: string[];
}

const categories = [
  "All Categories",
  "Customer Research",
  "Onboarding",
  "Account Management",
  "Renewal",
  "Expansion",
  "Support",
  "Analytics",
  "Productivity",
];

const CustomGPTsPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [filteredGPTs, setFilteredGPTs] = useState<CustomGPT[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 9;

  // Mock data for the GPT directory
  const gpts: CustomGPT[] = [
    {
      id: "1",
      name: "CS Usage Analyzer",
      description: "Analyze customer usage data to identify patterns and optimization opportunities. Perfect for identifying power users and potential champions.",
      category: "Analytics",
      useCase: "Identify patterns in customer product usage to spot optimization opportunities.",
      author: "Data Science Guild",
      url: "https://github.com/datascienceguild/cs-usage-analyzer",
      stars: 187,
      dateAdded: "2025-03-15",
      isOpenSource: true,
      promptExamples: [
        "Analyze this usage data and identify power users",
        "What features are underutilized by this customer cohort?",
        "Generate a customer health score based on these usage metrics"
      ]
    },
    {
      id: "2",
      name: "Onboarding Plan Builder",
      description: "Create personalized customer onboarding plans based on company size, industry, and goals. Includes timeline suggestions and milestone tracking.",
      category: "Onboarding",
      useCase: "Generate tailored onboarding plans for new customers.",
      author: "CS Collective",
      url: "https://github.com/cscollective/onboarding-plan-builder",
      stars: 215,
      dateAdded: "2025-02-28",
      isOpenSource: true,
      promptExamples: [
        "Create an enterprise healthcare onboarding plan with compliance focus",
        "Generate a 30-day quick start plan for a small business",
        "What are appropriate milestones for this financial services customer?"
      ]
    },
    {
      id: "3",
      name: "Renewal Risk Detector",
      description: "Analyze customer communications and identify potential churn signals. Uses sentiment analysis and key phrase detection.",
      category: "Renewal",
      useCase: "Identify renewal risks from customer communications.",
      author: "AI Success Labs",
      url: "https://github.com/aisuccesslabs/renewal-risk-detector",
      stars: 163,
      dateAdded: "2025-01-10",
      isOpenSource: true,
      promptExamples: [
        "Analyze these email exchanges for churn risk",
        "What sentiment patterns indicate potential non-renewal?",
        "Generate intervention recommendations based on these signals"
      ]
    },
    {
      id: "4",
      name: "Expansion Opportunity Finder",
      description: "Identifies potential upsell and cross-sell opportunities based on customer data, usage patterns, and industry benchmarks.",
      category: "Expansion",
      useCase: "Discover expansion opportunities within existing accounts.",
      author: "Growth Hackers",
      url: "https://github.com/growthhackers/expansion-opportunity-finder",
      stars: 196,
      dateAdded: "2025-04-05",
      isOpenSource: true,
      promptExamples: [
        "What add-on modules would benefit this customer based on their usage?",
        "Generate an expansion proposal for this account",
        "When is the optimal timing to discuss upsells with this customer?"
      ]
    },
    {
      id: "5",
      name: "Customer Health Scorecard",
      description: "Generates comprehensive customer health scorecards by analyzing usage, support tickets, NPS scores, and engagement metrics.",
      category: "Account Management",
      useCase: "Create detailed customer health assessments.",
      author: "CS Tools Collective",
      url: "https://github.com/cstoolscollective/health-scorecard",
      stars: 137,
      dateAdded: "2025-01-22",
      isOpenSource: true,
      promptExamples: [
        "Generate a health scorecard based on these customer metrics",
        "What are the leading indicators of adoption issues?",
        "Create a risk mitigation plan for this at-risk account"
      ]
    },
    {
      id: "6",
      name: "QBR Generator",
      description: "Creates professional quarterly business reviews by synthesizing usage data, support history, and business outcomes.",
      category: "Account Management",
      useCase: "Generate quarterly business review presentations.",
      author: "Enterprise CS Tools",
      url: "https://github.com/enterprisecs/qbr-generator",
      stars: 224,
      dateAdded: "2025-03-17",
      isOpenSource: true,
      promptExamples: [
        "Generate a QBR for this enterprise customer with ROI focus",
        "Create an executive summary of this quarter's achievements",
        "What strategic recommendations should we include in this QBR?"
      ]
    },
    {
      id: "7",
      name: "Voice of Customer Analyzer",
      description: "Extracts insights from customer feedback, support tickets, and survey responses to identify common themes and sentiment trends.",
      category: "Customer Research",
      useCase: "Analyze customer feedback for actionable insights.",
      author: "CX Insights",
      url: "https://github.com/cxinsights/voc-analyzer",
      stars: 178,
      dateAdded: "2025-02-15",
      isOpenSource: true,
      promptExamples: [
        "What are the top pain points mentioned in these survey responses?",
        "Generate a sentiment trend analysis from these support tickets",
        "Identify feature requests from this customer feedback"
      ]
    },
    {
      id: "8",
      name: "Success Plan Creator",
      description: "Generates customer success plans with clear objectives, KPIs, and action items based on customer goals and product capabilities.",
      category: "Onboarding",
      useCase: "Create tailored customer success plans.",
      author: "CS Strategy Guild",
      url: "https://github.com/csstrategyguild/success-plan-creator",
      stars: 156,
      dateAdded: "2025-04-12",
      isOpenSource: true,
      promptExamples: [
        "Create a 6-month success plan for this manufacturing customer",
        "What KPIs should we track for this customer's use case?",
        "Generate milestone suggestions based on these business goals"
      ]
    },
    {
      id: "9",
      name: "Playbook Recommender",
      description: "Recommends appropriate CS playbooks based on customer situation, industry, and current stage in the customer journey.",
      category: "Support",
      useCase: "Find the right playbook for specific customer scenarios.",
      author: "CS Playbook Collective",
      url: "https://github.com/csplaybookcollective/recommender",
      stars: 142,
      dateAdded: "2025-02-08",
      isOpenSource: true,
      promptExamples: [
        "What playbook should I use for a slow adoption enterprise account?",
        "Recommend a playbook for handling a champion who's leaving",
        "Generate a custom playbook for this unique situation"
      ]
    },
    {
      id: "10",
      name: "Email Campaign Builder",
      description: "Creates personalized email sequences for different stages of the customer journey, from onboarding to renewal.",
      category: "Productivity",
      useCase: "Generate customer communication sequences.",
      author: "CS Communications",
      url: "https://github.com/cscommunications/email-builder",
      stars: 189,
      dateAdded: "2025-03-28",
      isOpenSource: true,
      promptExamples: [
        "Create an onboarding email sequence for new users",
        "Generate a renewal campaign for enterprise customers",
        "What follow-up email should I send after a QBR?"
      ]
    },
    {
      id: "11",
      name: "Meeting Note Summarizer",
      description: "Extracts key points, action items, and follow-ups from customer meeting transcripts and creates concise summaries.",
      category: "Productivity",
      useCase: "Create actionable summaries from customer meetings.",
      author: "CS Productivity Tools",
      url: "https://github.com/csproductivity/meeting-summarizer",
      stars: 207,
      dateAdded: "2025-01-15",
      isOpenSource: true,
      promptExamples: [
        "Summarize this customer call with action items",
        "Extract the key concerns from this meeting transcript",
        "What promises did we make to the customer in this call?"
      ]
    },
    {
      id: "12",
      name: "ROI Calculator",
      description: "Helps calculate and communicate customer ROI based on usage data, cost savings, and business impact metrics.",
      category: "Account Management",
      useCase: "Quantify the value customers are receiving.",
      author: "Value Engineering Collective",
      url: "https://github.com/valueengineering/roi-calculator",
      stars: 165,
      dateAdded: "2025-02-20",
      isOpenSource: true,
      promptExamples: [
        "Calculate ROI based on these efficiency metrics",
        "Generate an ROI report for this enterprise customer",
        "What additional data would improve this ROI calculation?"
      ]
    },
  ];

  // Filter GPTs based on search query and category
  useEffect(() => {
    let filtered = [...gpts];
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (gpt) =>
          gpt.name.toLowerCase().includes(query) ||
          gpt.description.toLowerCase().includes(query) ||
          gpt.useCase.toLowerCase().includes(query)
      );
    }
    
    if (selectedCategory !== "All Categories") {
      filtered = filtered.filter((gpt) => gpt.category === selectedCategory);
    }
    
    setFilteredGPTs(filtered);
    setCurrentPage(1); // Reset to first page on new search/filter
  }, [searchQuery, selectedCategory]);

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredGPTs.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredGPTs.length / itemsPerPage);

  return (
    <>
      <Helmet>
        <title>Open Source GPTs for Customer Success | CSHacker</title>
        <meta
          name="description"
          content="Browse our directory of open source custom GPTs for customer success professionals. Find AI tools for onboarding, renewal, expansion, and more."
        />
      </Helmet>
      <main>
        <section className="bg-gray-50 py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto text-center mb-12">
              <h1 className="text-4xl font-bold text-dark">
                Open Source GPTs for Customer Success
              </h1>
              <p className="mt-4 text-xl text-gray-600">
                Community-contributed custom GPTs to streamline your CS workflows.
                Browse, use, and contribute to these open source tools.
              </p>
            </div>

            <div className="max-w-5xl mx-auto mb-12">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Input
                    type="text"
                    placeholder="Search GPTs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10"
                  />
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                </div>
                <div className="w-full md:w-auto flex items-center gap-2">
                  <Filter className="h-4 w-4 text-gray-400" />
                  <Select
                    value={selectedCategory}
                    onValueChange={(value) => setSelectedCategory(value)}
                  >
                    <SelectTrigger className="w-full md:w-[180px]">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {currentItems.map((gpt) => (
                <Card key={gpt.id} className="h-full flex flex-col">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-xl">{gpt.name}</CardTitle>
                        <div className="text-sm text-gray-500 mt-1">
                          By {gpt.author} • {gpt.category}
                        </div>
                      </div>
                      <div className="flex items-center text-amber-500">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="currentColor"
                          className="w-4 h-4 mr-1"
                        >
                          <path
                            fillRule="evenodd"
                            d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z"
                            clipRule="evenodd"
                          />
                        </svg>
                        <span>{gpt.stars}</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <CardDescription className="text-gray-600 mb-4">
                      {gpt.description}
                    </CardDescription>
                    <div className="mt-4">
                      <h4 className="text-sm font-medium text-gray-900 mb-2">Example prompts:</h4>
                      <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                        {gpt.promptExamples?.slice(0, 2).map((prompt, idx) => (
                          <li key={idx}>{prompt}</li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                  <CardFooter className="pt-2 border-t">
                    <a 
                      href={gpt.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-primary hover:underline text-sm"
                    >
                      View on GitHub
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                  </CardFooter>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious 
                      href="#" 
                      onClick={(e) => {
                        e.preventDefault();
                        if (currentPage > 1) setCurrentPage(currentPage - 1);
                      }}
                      className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                    />
                  </PaginationItem>
                  
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <PaginationItem key={page}>
                      <PaginationLink 
                        href="#" 
                        onClick={(e) => {
                          e.preventDefault();
                          setCurrentPage(page);
                        }}
                        isActive={page === currentPage}
                      >
                        {page}
                      </PaginationLink>
                    </PaginationItem>
                  ))}
                  
                  <PaginationItem>
                    <PaginationNext 
                      href="#" 
                      onClick={(e) => {
                        e.preventDefault();
                        if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                      }}
                      className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            )}

            <div className="mt-16 text-center">
              <h3 className="text-2xl font-bold text-dark mb-4">
                Contribute Your GPT
              </h3>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-6">
                Have you built a useful GPT for customer success work? Share it with the community
                and help fellow CS professionals work more efficiently.
              </p>
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90"
              >
                Submit Your GPT
              </Button>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default CustomGPTsPage;