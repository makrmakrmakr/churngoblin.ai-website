import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, MessageSquare, Plus, Filter } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Helmet } from "react-helmet";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";

// Types for our forum
interface ForumTopic {
  id: string;
  title: string;
  content: string;
  category: string;
  author: string;
  authorAvatar: string;
  replies: number;
  views: number;
  lastActivity: string;
  isPinned: boolean;
  isLocked: boolean;
  tags: string[];
}

const categories = [
  "All Categories",
  "General Discussion",
  "AI Strategies",
  "GPT Tools",
  "Onboarding",
  "Renewals",
  "Customer Experience",
  "Success Stories",
  "Help & Support",
];

const ForumPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [filteredTopics, setFilteredTopics] = useState<ForumTopic[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Example forum topics for the UI
  const topics: ForumTopic[] = [
    {
      id: "1",
      title: "GPTs that actually help with NPS score analysis - no BS",
      content: "I built something that scans NPS comments for churn risks and product requests. It's 80% accurate. Here's how I did it...",
      category: "GPT Tools",
      author: "Alex Rivera",
      authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80",
      replies: 24,
      views: 342,
      lastActivity: "1 hour ago",
      isPinned: false,
      isLocked: false,
      tags: ["NPS", "Sentiment Analysis", "Claude"]
    },
    {
      id: "2",
      title: "Got 62% faster time-to-value with this onboarding hack",
      content: "Merged our knowledge base with customer's onboarding data using GPT-4 to create tailored quickstart guides. No fancy tools needed.",
      category: "Onboarding",
      author: "Marcus Johnson",
      authorAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80",
      replies: 18,
      views: 287,
      lastActivity: "3 hours ago",
      isPinned: true,
      isLocked: false,
      tags: ["Onboarding", "Automation", "GPT-4"]
    },
    {
      id: "3",
      title: "Added $780K ARR using AI-driven expansion finding",
      content: "Created a system that identifies expansion opportunities by analyzing support tickets and usage patterns. Happy to share the approach.",
      category: "Success Stories",
      author: "Leila Patel",
      authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80",
      replies: 32,
      views: 458,
      lastActivity: "1 day ago",
      isPinned: true,
      isLocked: false,
      tags: ["Expansion", "Revenue", "Use Case"]
    },
    {
      id: "4",
      title: "Anyone using Claude's latest model for QBR prep?",
      content: "Looking to automate some of the data analysis for QBRs. Has anyone tried Claude's latest model for this? Is it worth it?",
      category: "General Discussion",
      author: "Taylor Wu",
      authorAvatar: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80",
      replies: 14,
      views: 203,
      lastActivity: "2 days ago",
      isPinned: false,
      isLocked: false,
      tags: ["QBR", "Claude", "Data Analysis"]
    },
    {
      id: "5",
      title: "HELP: My renewal prediction model is giving weird results",
      content: "I tried building a renewal prediction model using the approach Sophia shared, but it's giving me 40% false positives. What did I miss?",
      category: "Help & Support",
      author: "Jamie Rodriguez",
      authorAvatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80",
      replies: 21,
      views: 189,
      lastActivity: "4 hours ago",
      isPinned: false,
      isLocked: false,
      tags: ["Renewals", "Prediction", "Help"]
    },
  ];

  // Filter topics based on search query and category
  const getFilteredTopics = () => {
    let filtered = [...topics];
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (topic) =>
          topic.title.toLowerCase().includes(query) ||
          topic.content.toLowerCase().includes(query) ||
          topic.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }
    
    if (selectedCategory !== "All Categories") {
      filtered = filtered.filter((topic) => topic.category === selectedCategory);
    }
    
    return filtered;
  };

  // Pagination logic
  const paginatedTopics = () => {
    const filtered = getFilteredTopics();
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    return filtered.slice(indexOfFirstItem, indexOfLastItem);
  };

  const totalPages = Math.ceil(getFilteredTopics().length / itemsPerPage);

  const TopicCard = ({ topic }: { topic: ForumTopic }) => (
    <Card className="hover:shadow-md transition-shadow relative">
      {topic.isPinned && (
        <div className="absolute top-0 right-0 bg-primary text-white text-xs px-2 py-1 rounded-bl-lg rounded-tr-lg">
          Pinned
        </div>
      )}
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl">
              <Link href={`/forum/topic/${topic.id}`} className="hover:text-primary transition-colors">
                {topic.title}
              </Link>
            </CardTitle>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm font-medium text-gray-500">
                in {topic.category}
              </span>
              <span className="text-xs text-gray-400">•</span>
              <span className="text-sm text-gray-500">
                Started by {topic.author}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center text-gray-500">
              <MessageSquare className="h-4 w-4 mr-1" />
              <span className="text-sm">{topic.replies}</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-gray-600 line-clamp-2">
          {topic.content}
        </CardDescription>
        <div className="flex flex-wrap gap-2 mt-3">
          {topic.tags.map((tag, idx) => (
            <Badge key={idx} variant="outline" className="bg-gray-100 text-gray-700 font-normal">
              {tag}
            </Badge>
          ))}
        </div>
      </CardContent>
      <CardFooter className="pt-2 border-t flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 rounded-full overflow-hidden">
            <img 
              src={topic.authorAvatar} 
              alt={topic.author}
              className="w-full h-full object-cover" 
            />
          </div>
          <span className="text-sm text-gray-500">
            Last reply {topic.lastActivity}
          </span>
        </div>
        <span className="text-sm text-gray-500">{topic.views} views</span>
      </CardFooter>
    </Card>
  );

  return (
    <>
      <Helmet>
        <title>CS AI Community Forum | CSHacker</title>
        <meta
          name="description"
          content="Join the conversation with fellow CS professionals using AI to transform operations. Share strategies, ask questions, and learn from real-world implementations."
        />
      </Helmet>
      <main>
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto">
              <div className="flex justify-between items-center mb-8">
                <h1 className="text-3xl font-bold text-dark">
                  Community Forum
                </h1>
                <Button className="bg-primary hover:bg-primary/90">
                  <Plus className="h-4 w-4 mr-2" />
                  New Topic
                </Button>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-4 mb-8">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Input
                      type="text"
                      placeholder="Search topics..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10"
                    />
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  </div>
                  <div className="w-full md:w-auto flex items-center gap-2">
                    <Filter className="h-4 w-4 text-gray-400" />
                    <Select
                      value={selectedCategory}
                      onValueChange={(value) => setSelectedCategory(value)}
                    >
                      <SelectTrigger className="w-full md:w-[180px]">
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Tabs defaultValue="latest" className="mb-6">
                <TabsList>
                  <TabsTrigger value="latest">Latest</TabsTrigger>
                  <TabsTrigger value="popular">Popular</TabsTrigger>
                  <TabsTrigger value="unanswered">Unanswered</TabsTrigger>
                </TabsList>
              </Tabs>

              <div className="space-y-4 mb-8">
                {paginatedTopics().map((topic) => (
                  <TopicCard key={topic.id} topic={topic} />
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious 
                        href="#" 
                        onClick={(e) => {
                          e.preventDefault();
                          if (currentPage > 1) setCurrentPage(currentPage - 1);
                        }}
                        className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                      />
                    </PaginationItem>
                    
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                      <PaginationItem key={page}>
                        <PaginationLink 
                          href="#" 
                          onClick={(e) => {
                            e.preventDefault();
                            setCurrentPage(page);
                          }}
                          isActive={page === currentPage}
                        >
                          {page}
                        </PaginationLink>
                      </PaginationItem>
                    ))}
                    
                    <PaginationItem>
                      <PaginationNext 
                        href="#" 
                        onClick={(e) => {
                          e.preventDefault();
                          if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                        }}
                        className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              )}
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default ForumPage;