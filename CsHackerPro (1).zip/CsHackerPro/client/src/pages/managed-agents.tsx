import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, ArrowRight } from "lucide-react";
import Newsletter from "@/components/sections/newsletter";
import CTASection from "@/components/sections/cta-section";
import ContactForm from "@/components/contact-form";
import { Helmet } from "react-helmet";

const ManagedAgents = () => {
  return (
    <>
      <Helmet>
        <title>Managed Customer Agents | CSHacker</title>
        <meta name="description" content="Custom-built AI agents for your unique customer success needs. Leverage our expertise to develop, deploy, and manage personalized AI solutions for your team." />
        <meta property="og:title" content="Managed Customer Agents | CSHacker" />
        <meta property="og:description" content="Custom-built AI agents for your unique customer success needs. Leverage our expertise to develop, deploy, and manage personalized AI solutions for your team." />
        <meta property="og:type" content="website" />
      </Helmet>
      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-r from-primary to-secondary overflow-hidden">
          <div className="absolute inset-0 bg-dark/30 mix-blend-multiply"></div>
          <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
            <div className="md:w-2/3">
              <div className="text-accent font-semibold text-white mb-3">CUSTOM SOLUTIONS</div>
              <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
                Managed Customer Agents
              </h1>
              <p className="mt-6 max-w-3xl text-xl text-white">
                Custom-built AI agents for your unique customer success needs. Leverage our expertise to develop, deploy, and manage personalized AI solutions for your team.
              </p>
              <div className="mt-10 flex flex-wrap gap-4">
                <Button
                  size="lg"
                  className="bg-accent hover:bg-accent/90 text-white"
                >
                  Request a Consultation
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10"
                >
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Service Overview Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">How Managed Agents Work</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                We build and manage custom AI agents tailored to your specific customer success processes.
              </p>
            </div>

            <div className="mt-16">
              <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1573164713988-8665fc963095?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                    alt="Custom AI Solution Development"
                    className="rounded-xl shadow-xl w-full h-auto"
                  />
                </div>
                <div className="mt-10 lg:mt-0 lg:pl-8">
                  <ol className="space-y-8">
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          1
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Discovery & Planning</h3>
                        <p className="mt-2 text-gray-600">
                          We conduct a thorough assessment of your customer success processes, challenges, and goals to identify the best AI agent opportunities.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          2
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Custom Agent Development</h3>
                        <p className="mt-2 text-gray-600">
                          Our team of AI specialists and CS experts builds custom agents designed specifically for your workflows and customer touchpoints.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          3
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Integration & Deployment</h3>
                        <p className="mt-2 text-gray-600">
                          We seamlessly integrate your custom agents with your existing tech stack and provide team training to ensure successful adoption.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          4
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Ongoing Management & Optimization</h3>
                        <p className="mt-2 text-gray-600">
                          We continuously monitor, maintain, and optimize your agents based on performance data and your evolving business needs.
                        </p>
                      </div>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Use Cases Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">Custom Agent Use Cases</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                Examples of specialized AI agents we can build for your customer success team.
              </p>
            </div>

            <div className="mt-12 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">QBR Preparation Agent</h3>
                  <p className="mt-2 text-gray-600">Automates the collection and analysis of key data points for quarterly business reviews, generating insights and presentation materials.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Voice of Customer Analysis Agent</h3>
                  <p className="mt-2 text-gray-600">Continuously analyzes customer feedback from multiple channels to identify trends, sentiment shifts, and emerging issues.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Product Usage Optimization Agent</h3>
                  <p className="mt-2 text-gray-600">Identifies feature adoption gaps and provides personalized in-app guidance to improve product utilization and value realization.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Success Metrics Dashboard Agent</h3>
                  <p className="mt-2 text-gray-600">Automatically tracks and visualizes key customer health metrics, providing real-time insights and alerts to your team.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Customer Communication Agent</h3>
                  <p className="mt-2 text-gray-600">Handles routine customer communications while escalating complex issues to the appropriate team members with full context.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Customer Segmentation Agent</h3>
                  <p className="mt-2 text-gray-600">Dynamically segments your customer base using multiple data points to enable more targeted and personalized success strategies.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">Why Choose Managed Agents?</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                The benefits of working with CSHacker for your custom AI agent needs.
              </p>
            </div>

            <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2">
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-bold text-dark">True Customization</h3>
                  <p className="mt-2 text-gray-600">
                    Unlike off-the-shelf solutions, our managed agents are built specifically for your unique processes, challenges, and customer base.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-bold text-dark">Predictable Costs</h3>
                  <p className="mt-2 text-gray-600">
                    Fixed monthly pricing with no surprise fees, making it easy to budget and scale your AI implementations without unexpected costs.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-bold text-dark">Fast Implementation</h3>
                  <p className="mt-2 text-gray-600">
                    Our experienced team can deploy custom agents in weeks rather than months, allowing you to realize value more quickly.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-bold text-dark">No Internal Resources Required</h3>
                  <p className="mt-2 text-gray-600">
                    We handle all development, maintenance, and optimization, freeing your team to focus on building relationships with customers.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-bold text-dark">Continuous Improvement</h3>
                  <p className="mt-2 text-gray-600">
                    We constantly monitor performance and incorporate feedback to ensure your agents get smarter and more effective over time.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-bold text-dark">Specialized Expertise</h3>
                  <p className="mt-2 text-gray-600">
                    Our team combines deep CS knowledge with AI expertise, ensuring your agents truly understand customer success principles.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">Flexible Pricing Options</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                Transparent pricing tailored to your specific needs and scale.
              </p>
            </div>

            <div className="mt-12 grid gap-8 lg:grid-cols-3">
              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-8">
                  <div className="text-center">
                    <h3 className="text-xl font-bold text-dark">Basic Agent</h3>
                    <div className="mt-4">
                      <span className="text-4xl font-extrabold text-dark">$1,499</span>
                      <span className="text-gray-500">/month</span>
                    </div>
                    <p className="mt-4 text-gray-600">
                      Perfect for small teams looking to automate a specific customer success process.
                    </p>
                  </div>
                  <ul className="mt-8 space-y-4">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>1 custom AI agent</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Setup and integration</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Maintenance and updates</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Monthly performance reports</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Email support</span>
                    </li>
                  </ul>
                  <div className="mt-8">
                    <Button className="w-full bg-primary hover:bg-primary/90">
                      Get Started
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-primary shadow-xl hover:shadow-2xl transition scale-105">
                <CardContent className="p-8">
                  <div className="text-center">
                    <div className="bg-accent text-white text-sm font-bold uppercase py-1 px-3 rounded-full inline-block mb-2">
                      Most Popular
                    </div>
                    <h3 className="text-xl font-bold text-dark">Growth Suite</h3>
                    <div className="mt-4">
                      <span className="text-4xl font-extrabold text-dark">$3,499</span>
                      <span className="text-gray-500">/month</span>
                    </div>
                    <p className="mt-4 text-gray-600">
                      Ideal for growing CS teams looking to automate multiple touchpoints.
                    </p>
                  </div>
                  <ul className="mt-8 space-y-4">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>3 custom AI agents</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Setup and integration</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Quarterly agent optimization</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Weekly performance reports</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Priority email & phone support</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Dedicated account manager</span>
                    </li>
                  </ul>
                  <div className="mt-8">
                    <Button className="w-full bg-accent hover:bg-accent/90 text-white">
                      Get Started
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-8">
                  <div className="text-center">
                    <h3 className="text-xl font-bold text-dark">Enterprise</h3>
                    <div className="mt-4">
                      <span className="text-4xl font-extrabold text-dark">Custom</span>
                    </div>
                    <p className="mt-4 text-gray-600">
                      For large teams with complex requirements and custom integrations.
                    </p>
                  </div>
                  <ul className="mt-8 space-y-4">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Unlimited custom AI agents</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Enterprise integrations</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Monthly optimization</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Custom reporting</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>24/7 premium support</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-success mt-1 mr-2" />
                      <span>Strategic advisory services</span>
                    </li>
                  </ul>
                  <div className="mt-8">
                    <Button className="w-full bg-primary hover:bg-primary/90">
                      Contact Sales
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:grid lg:grid-cols-2 lg:gap-8">
              <div>
                <h2 className="text-3xl font-bold text-dark">Ready to build your custom AI agents?</h2>
                <p className="mt-4 text-lg text-gray-600">
                  Get in touch with our team to discuss your specific requirements and how we can help automate and enhance your customer success operations.
                </p>
                <div className="mt-8 space-y-4">
                  <p className="flex items-center text-gray-700">
                    <svg className="h-5 w-5 text-primary mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    info@cshacker.com
                  </p>
                  <p className="flex items-center text-gray-700">
                    <svg className="h-5 w-5 text-primary mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                    (555) 123-4567
                  </p>
                </div>
              </div>
              <div className="mt-8 lg:mt-0">
                <ContactForm />
              </div>
            </div>
          </div>
        </section>

        <Newsletter />
        <CTASection />
      </main>
    </>
  );
};

export default ManagedAgents;