import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Download, Github } from "lucide-react";
import Newsletter from "@/components/sections/newsletter";
import { Helmet } from "react-helmet";
import { Link } from "wouter";

const AITools = () => {
  return (
    <>
      <Helmet>
        <title>Free AI Tools for Customer Success | CSHacker</title>
        <meta name="description" content="Ready-to-use, open-source AI tools for CS teams at any stage. Download, deploy, and start improving your customer success workflows today." />
        <meta property="og:title" content="Free AI Tools for Customer Success | CSHacker" />
        <meta property="og:description" content="Ready-to-use, open-source AI tools for CS teams at any stage. Download, deploy, and start improving your customer success workflows today." />
        <meta property="og:type" content="website" />
      </Helmet>
      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-r from-primary to-secondary overflow-hidden">
          <div className="absolute inset-0 bg-dark/30 mix-blend-multiply"></div>
          <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
            <div className="md:w-2/3">
              <div className="text-accent font-semibold text-white mb-3">PRACTICAL SOLUTIONS</div>
              <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
                Free AI Tools for CS Teams
              </h1>
              <p className="mt-6 max-w-3xl text-xl text-white">
                Open-source, ready-to-use AI tools to enhance your customer success workflows. No coding needed, just download and get results.
              </p>
              <div className="mt-10 flex flex-wrap gap-4">
                <Button
                  size="lg"
                  className="bg-accent hover:bg-accent/90 text-white"
                >
                  Browse Tools
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10"
                >
                  <Github className="mr-2 h-4 w-4" />
                  GitHub Repo
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Tools Categories */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-dark">
                Tools That Actually Work
              </h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                No fluff, just practical AI tools created by CS pros who've faced the same challenges you have.
              </p>
            </div>

            <Tabs defaultValue="all" className="w-full">
              <div className="flex justify-center mb-8">
                <TabsList className="grid grid-cols-2 md:grid-cols-5 gap-2 bg-transparent">
                  <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                    All Tools
                  </TabsTrigger>
                  <TabsTrigger value="onboarding" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                    Onboarding
                  </TabsTrigger>
                  <TabsTrigger value="retention" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                    Retention
                  </TabsTrigger>
                  <TabsTrigger value="expansion" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                    Expansion
                  </TabsTrigger>
                  <TabsTrigger value="analytics" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                    Analytics
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="all" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {/* Tool Cards */}
                  <Card className="border border-gray-100 overflow-hidden flex flex-col h-full hover:shadow-lg transition-shadow">
                    <div className="h-3 bg-green-500"></div>
                    <CardHeader className="flex justify-between items-start pb-2">
                      <div>
                        <CardTitle className="text-xl">NPS Analyzer</CardTitle>
                        <div className="flex gap-2 mt-1">
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Retention
                          </Badge>
                          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                            Beginner
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      <CardDescription className="text-gray-600 mb-4">
                        Summarizes NPS responses into actionable themes and categorizes comments by urgency. Cuts survey analysis time from hours to minutes.
                      </CardDescription>
                      <div className="mt-4">
                        <h4 className="text-sm font-medium text-gray-900 mb-2">What users are saying:</h4>
                        <blockquote className="border-l-2 border-gray-200 pl-4 italic text-gray-600 text-sm">
                          "Saved me 3 hours of manual work on our quarterly NPS review. The sentiment accuracy is scary good." — Maria, CS Manager
                        </blockquote>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t">
                      <div className="flex justify-between w-full items-center">
                        <div className="text-sm text-gray-500">
                          <span className="font-semibold">Model:</span> GPT-4
                        </div>
                        <Button variant="ghost" className="text-primary">
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>

                  <Card className="border border-gray-100 overflow-hidden flex flex-col h-full hover:shadow-lg transition-shadow">
                    <div className="h-3 bg-blue-500"></div>
                    <CardHeader className="flex justify-between items-start pb-2">
                      <div>
                        <CardTitle className="text-xl">Onboarding Email Generator</CardTitle>
                        <div className="flex gap-2 mt-1">
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            Onboarding
                          </Badge>
                          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                            Beginner
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      <CardDescription className="text-gray-600 mb-4">
                        Creates personalized customer onboarding email sequences based on product, industry, and customer size. Includes 12 templates proven to boost engagement.
                      </CardDescription>
                      <div className="mt-4">
                        <h4 className="text-sm font-medium text-gray-900 mb-2">What users are saying:</h4>
                        <blockquote className="border-l-2 border-gray-200 pl-4 italic text-gray-600 text-sm">
                          "Increased our onboarding email open rates by 31%. The templates adapt perfectly to each customer's specific needs." — David, Onboarding Specialist
                        </blockquote>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t">
                      <div className="flex justify-between w-full items-center">
                        <div className="text-sm text-gray-500">
                          <span className="font-semibold">Model:</span> Claude Instant
                        </div>
                        <Button variant="ghost" className="text-primary">
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>

                  <Card className="border border-gray-100 overflow-hidden flex flex-col h-full hover:shadow-lg transition-shadow">
                    <div className="h-3 bg-purple-500"></div>
                    <CardHeader className="flex justify-between items-start pb-2">
                      <div>
                        <CardTitle className="text-xl">Usage Pattern Analyzer</CardTitle>
                        <div className="flex gap-2 mt-1">
                          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                            Analytics
                          </Badge>
                          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                            Intermediate
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      <CardDescription className="text-gray-600 mb-4">
                        Identifies product usage patterns that correlate with retention or churn. Creates visual reports of user behavior with suggested intervention points.
                      </CardDescription>
                      <div className="mt-4">
                        <h4 className="text-sm font-medium text-gray-900 mb-2">What users are saying:</h4>
                        <blockquote className="border-l-2 border-gray-200 pl-4 italic text-gray-600 text-sm">
                          "Found 3 usage patterns that strongly predicted churn 60 days before it happened. Now we have time to intervene." — Samantha, CS Ops
                        </blockquote>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t">
                      <div className="flex justify-between w-full items-center">
                        <div className="text-sm text-gray-500">
                          <span className="font-semibold">Model:</span> GPT-4 + Python
                        </div>
                        <Button variant="ghost" className="text-primary">
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>

                  <Card className="border border-gray-100 overflow-hidden flex flex-col h-full hover:shadow-lg transition-shadow">
                    <div className="h-3 bg-amber-500"></div>
                    <CardHeader className="flex justify-between items-start pb-2">
                      <div>
                        <CardTitle className="text-xl">Expansion Opportunity Finder</CardTitle>
                        <div className="flex gap-2 mt-1">
                          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                            Expansion
                          </Badge>
                          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                            Intermediate
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      <CardDescription className="text-gray-600 mb-4">
                        Analyzes support tickets, feature requests, and usage data to identify upsell opportunities with timing recommendations for maximum conversion.
                      </CardDescription>
                      <div className="mt-4">
                        <h4 className="text-sm font-medium text-gray-900 mb-2">What users are saying:</h4>
                        <blockquote className="border-l-2 border-gray-200 pl-4 italic text-gray-600 text-sm">
                          "Generated $120K in expansion revenue last quarter by catching opportunities we would have missed. The timing suggestions are spot on." — Alex, CS Manager
                        </blockquote>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t">
                      <div className="flex justify-between w-full items-center">
                        <div className="text-sm text-gray-500">
                          <span className="font-semibold">Model:</span> GPT-4 + Sheets
                        </div>
                        <Button variant="ghost" className="text-primary">
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>

                  <Card className="border border-gray-100 overflow-hidden flex flex-col h-full hover:shadow-lg transition-shadow">
                    <div className="h-3 bg-blue-500"></div>
                    <CardHeader className="flex justify-between items-start pb-2">
                      <div>
                        <CardTitle className="text-xl">Success Plan Builder</CardTitle>
                        <div className="flex gap-2 mt-1">
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            Onboarding
                          </Badge>
                          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                            Advanced
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      <CardDescription className="text-gray-600 mb-4">
                        Creates tailored success plans with specific goals, KPIs, and milestones based on customer interviews. Includes implementation timeline and ready-to-use tracking templates.
                      </CardDescription>
                      <div className="mt-4">
                        <h4 className="text-sm font-medium text-gray-900 mb-2">What users are saying:</h4>
                        <blockquote className="border-l-2 border-gray-200 pl-4 italic text-gray-600 text-sm">
                          "Cut our success plan creation time by 70% while making them more valuable to customers. Win-win." — Jordan, Strategic CS Lead
                        </blockquote>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t">
                      <div className="flex justify-between w-full items-center">
                        <div className="text-sm text-gray-500">
                          <span className="font-semibold">Model:</span> Claude + Docs
                        </div>
                        <Button variant="ghost" className="text-primary">
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>

                  <Card className="border border-gray-100 overflow-hidden flex flex-col h-full hover:shadow-lg transition-shadow">
                    <div className="h-3 bg-green-500"></div>
                    <CardHeader className="flex justify-between items-start pb-2">
                      <div>
                        <CardTitle className="text-xl">QBR Generator</CardTitle>
                        <div className="flex gap-2 mt-1">
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Retention
                          </Badge>
                          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                            Intermediate
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      <CardDescription className="text-gray-600 mb-4">
                        Transforms usage data and business objectives into compelling quarterly business review presentations with impact metrics and clear next steps.
                      </CardDescription>
                      <div className="mt-4">
                        <h4 className="text-sm font-medium text-gray-900 mb-2">What users are saying:</h4>
                        <blockquote className="border-l-2 border-gray-200 pl-4 italic text-gray-600 text-sm">
                          "Our QBRs went from dreaded data dumps to strategic conversations that customers actually look forward to." — Michelle, Enterprise CSM
                        </blockquote>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t">
                      <div className="flex justify-between w-full items-center">
                        <div className="text-sm text-gray-500">
                          <span className="font-semibold">Model:</span> GPT-4 + Slides
                        </div>
                        <Button variant="ghost" className="text-primary">
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="onboarding" className="mt-0">
                {/* Onboarding tools tab content */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Will contain filtered tools */}
                </div>
              </TabsContent>

              <TabsContent value="retention" className="mt-0">
                {/* Retention tools tab content */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Will contain filtered tools */}
                </div>
              </TabsContent>

              <TabsContent value="expansion" className="mt-0">
                {/* Expansion tools tab content */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Will contain filtered tools */}
                </div>
              </TabsContent>

              <TabsContent value="analytics" className="mt-0">
                {/* Analytics tools tab content */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Will contain filtered tools */}
                </div>
              </TabsContent>
            </Tabs>

            <div className="mt-16 text-center">
              <h3 className="text-2xl font-bold text-dark mb-4">
                Have a tool to share?
              </h3>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-6">
                Built something useful? Share it with the community and help fellow CS teams ditch the busywork.
              </p>
              <Link href="/forum">
                <Button className="bg-primary hover:bg-primary/90">
                  Share Your Tool
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* How to Use Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">
                From Download to Results in Minutes
              </h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                No complicated setup or coding required. Just download and start using.
              </p>
            </div>

            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="h-12 w-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <span className="text-primary font-bold text-xl">1</span>
                </div>
                <h3 className="text-lg font-bold text-dark mb-3">Download the Tool</h3>
                <p className="text-gray-600">
                  Choose a tool that matches your needs and download it from our GitHub repository. Each tool includes documentation.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="h-12 w-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <span className="text-primary font-bold text-xl">2</span>
                </div>
                <h3 className="text-lg font-bold text-dark mb-3">Input Your Data</h3>
                <p className="text-gray-600">
                  Follow the simple instructions to input your customer data. Most tools work with spreadsheets or simple text files.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="h-12 w-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <span className="text-primary font-bold text-xl">3</span>
                </div>
                <h3 className="text-lg font-bold text-dark mb-3">Get Results</h3>
                <p className="text-gray-600">
                  Let the AI do its work and get actionable insights, reports, or content that you can use immediately.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-primary/5 rounded-2xl p-8 md:p-12 shadow-sm">
              <div className="md:flex md:items-center md:justify-between">
                <div className="md:w-2/3 mb-6 md:mb-0">
                  <h2 className="text-2xl font-bold text-dark">
                    Want to build your own CS AI tools?
                  </h2>
                  <p className="mt-2 text-lg text-gray-600">
                    Check out our forum where CS practitioners share how they built these tools - no AI expertise required.
                  </p>
                </div>
                <div>
                  <Link href="/forum">
                    <Button size="lg" className="bg-primary hover:bg-primary/90">
                      Join the Community
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Newsletter />
      </main>
    </>
  );
};

export default AITools;