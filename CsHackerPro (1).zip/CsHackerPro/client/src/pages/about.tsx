import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import Newsletter from "@/components/sections/newsletter";
import CTASection from "@/components/sections/cta-section";
import ContactForm from "@/components/contact-form";
import { Helmet } from "react-helmet";

const About = () => {
  return (
    <>
      <Helmet>
        <title>About CSHacker | Customer Success AI + Human Intelligence</title>
        <meta name="description" content="Learn about CSHacker's mission to revolutionize customer success through the perfect balance of AI technology and human relationships." />
        <meta property="og:title" content="About CSHacker | Customer Success AI + Human Intelligence" />
        <meta property="og:description" content="Learn about CSHacker's mission to revolutionize customer success through the perfect balance of AI technology and human relationships." />
        <meta property="og:type" content="website" />
      </Helmet>
      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-r from-primary to-secondary overflow-hidden">
          <div className="absolute inset-0 bg-dark/30 mix-blend-multiply"></div>
          <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
            <div className="md:w-2/3">
              <div className="text-accent font-semibold text-white mb-3">OUR STORY</div>
              <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
                Revolutionizing Customer Success
              </h1>
              <p className="mt-6 max-w-3xl text-xl text-white">
                We're on a mission to help companies create exceptional customer experiences through the perfect balance of AI technology and human relationships.
              </p>
            </div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
              <div className="mb-12 lg:mb-0">
                <img
                  src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                  alt="CSHacker Team Meeting"
                  className="rounded-xl shadow-xl w-full h-auto"
                />
              </div>
              <div>
                <span className="text-accent font-semibold">OUR MISSION</span>
                <h2 className="mt-2 text-3xl font-bold text-dark">Why We Exist</h2>
                <p className="mt-4 text-lg text-gray-600">
                  At CSHacker, we believe that exceptional customer success comes from the perfect blend of cutting-edge AI technology and authentic human relationships. 
                </p>
                <p className="mt-4 text-lg text-gray-600">
                  We founded this company after witnessing firsthand the challenges customer success teams face in scaling their operations while maintaining the personal touch that customers value. Our platform is designed to let AI handle the repetitive tasks and data analysis, freeing up CS professionals to focus on building meaningful relationships with their customers.
                </p>
                <div className="mt-8 space-y-4">
                  <div className="flex items-center">
                    <Check className="text-success mr-3 h-5 w-5" />
                    <span className="text-gray-700">We help CS teams scale efficiently without sacrificing quality</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="text-success mr-3 h-5 w-5" />
                    <span className="text-gray-700">We believe in the power of AI to enhance, not replace, human connections</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="text-success mr-3 h-5 w-5" />
                    <span className="text-gray-700">We're committed to driving measurable business outcomes for our customers</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <span className="text-accent font-semibold">OUR TEAM</span>
              <h2 className="mt-2 text-3xl font-bold text-dark">Meet the Leadership</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                We're a team of customer success experts and AI specialists dedicated to transforming the CS profession.
              </p>
            </div>

            <div className="mt-16 grid gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
              {/* Founder & CEO */}
              <div className="text-center">
                <img
                  src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=900"
                  alt="Founder & CEO"
                  className="mx-auto h-48 w-48 rounded-full object-cover"
                />
                <div className="mt-6">
                  <h3 className="text-lg font-bold text-dark">Sarah Johnson</h3>
                  <p className="text-sm text-primary">Founder & CEO</p>
                  <p className="mt-3 text-gray-600">
                    Former VP of Customer Success with 15+ years of experience at leading SaaS companies. Passionate about the intersection of AI and human-centered customer success.
                  </p>
                </div>
              </div>

              {/* CTO */}
              <div className="text-center">
                <img
                  src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=900"
                  alt="Chief Technology Officer"
                  className="mx-auto h-48 w-48 rounded-full object-cover"
                />
                <div className="mt-6">
                  <h3 className="text-lg font-bold text-dark">Michael Chen</h3>
                  <p className="text-sm text-primary">Chief Technology Officer</p>
                  <p className="mt-3 text-gray-600">
                    AI specialist with background at leading tech companies. Expert in machine learning and predictive analytics with a focus on practical business applications.
                  </p>
                </div>
              </div>

              {/* Head of CS Strategy */}
              <div className="text-center">
                <img
                  src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=900"
                  alt="Head of CS Strategy"
                  className="mx-auto h-48 w-48 rounded-full object-cover"
                />
                <div className="mt-6">
                  <h3 className="text-lg font-bold text-dark">Olivia Martinez</h3>
                  <p className="text-sm text-primary">Head of CS Strategy</p>
                  <p className="mt-3 text-gray-600">
                    Customer Success strategist who has built and scaled CS organizations at high-growth startups. Specializes in creating scalable, repeatable CS processes.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Company Values */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <span className="text-accent font-semibold">OUR VALUES</span>
              <h2 className="mt-2 text-3xl font-bold text-dark">What We Stand For</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                These core principles guide everything we do at CSHacker.
              </p>
            </div>

            <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <div className="relative p-6 bg-white rounded-lg shadow-md border border-gray-100 transition hover:shadow-lg">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-dark">Human-Centered Technology</h3>
                <p className="mt-2 text-gray-600">We build technology that enhances human capabilities rather than replacing them, creating solutions that enable more meaningful connections.</p>
              </div>

              <div className="relative p-6 bg-white rounded-lg shadow-md border border-gray-100 transition hover:shadow-lg">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-dark">Customer Outcomes First</h3>
                <p className="mt-2 text-gray-600">We measure our success by the concrete business outcomes we deliver for our customers, not by superficial metrics or vanity KPIs.</p>
              </div>

              <div className="relative p-6 bg-white rounded-lg shadow-md border border-gray-100 transition hover:shadow-lg">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-dark">Continuous Innovation</h3>
                <p className="mt-2 text-gray-600">We constantly push the boundaries of what's possible in customer success, embracing new technologies and methodologies to deliver better results.</p>
              </div>

              <div className="relative p-6 bg-white rounded-lg shadow-md border border-gray-100 transition hover:shadow-lg">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-dark">Data-Driven Decisions</h3>
                <p className="mt-2 text-gray-600">We rely on data and evidence to drive our product decisions, ensuring we build solutions that solve real problems effectively.</p>
              </div>

              <div className="relative p-6 bg-white rounded-lg shadow-md border border-gray-100 transition hover:shadow-lg">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-dark">Proactive Excellence</h3>
                <p className="mt-2 text-gray-600">We believe in anticipating customer needs and challenges before they arise, enabling truly proactive customer success.</p>
              </div>

              <div className="relative p-6 bg-white rounded-lg shadow-md border border-gray-100 transition hover:shadow-lg">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-dark">Respect for Time</h3>
                <p className="mt-2 text-gray-600">We value our customers' time and design our solutions to eliminate busywork, allowing CS teams to focus on high-impact activities.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <span className="text-accent font-semibold">GET IN TOUCH</span>
                <h2 className="mt-2 text-3xl font-bold text-dark">Let's Connect</h2>
                <p className="mt-4 text-lg text-gray-600">
                  Have questions about CSHacker or want to learn more about how we can help your customer success team? We'd love to hear from you.
                </p>
                <div className="mt-8 space-y-4">
                  <div className="flex items-center">
                    <svg className="w-5 h-5 text-primary mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    <span className="text-gray-700">info@cshacker.com</span>
                  </div>
                  <div className="flex items-center">
                    <svg className="w-5 h-5 text-primary mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                    <span className="text-gray-700">(123) 456-7890</span>
                  </div>
                  <div className="flex items-center">
                    <svg className="w-5 h-5 text-primary mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <span className="text-gray-700">123 Main St, San Francisco, CA 94105</span>
                  </div>
                </div>
              </div>
              <div className="bg-white p-8 rounded-xl shadow-sm">
                <h3 className="text-xl font-bold text-dark mb-6">Send Us a Message</h3>
                <ContactForm />
              </div>
            </div>
          </div>
        </section>

        <CTASection />
        <Newsletter />
      </main>
    </>
  );
};

export default About;
