import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, ArrowRight } from "lucide-react";
import Newsletter from "@/components/sections/newsletter";
import CTASection from "@/components/sections/cta-section";
import ContactForm from "@/components/contact-form";
import { Helmet } from "react-helmet";

const Expansion = () => {
  return (
    <>
      <Helmet>
        <title>AI for Customer Expansion | CSHacker</title>
        <meta name="description" content="Identify and capitalize on expansion opportunities with intelligent analysis of customer usage patterns, needs, and industry trends." />
        <meta property="og:title" content="AI for Customer Expansion | CSHacker" />
        <meta property="og:description" content="Identify and capitalize on expansion opportunities with intelligent analysis of customer usage patterns, needs, and industry trends." />
        <meta property="og:type" content="website" />
      </Helmet>
      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-r from-primary to-secondary overflow-hidden">
          <div className="absolute inset-0 bg-dark/30 mix-blend-multiply"></div>
          <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
            <div className="md:w-2/3">
              <div className="text-accent font-semibold text-white mb-3">GROWTH SOLUTION</div>
              <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
                AI for Customer Expansion
              </h1>
              <p className="mt-6 max-w-3xl text-xl text-white">
                Identify and capitalize on expansion opportunities with intelligent analysis of customer usage patterns, needs, and industry trends.
              </p>
              <div className="mt-10 flex flex-wrap gap-4">
                <Button
                  size="lg"
                  className="bg-accent hover:bg-accent/90 text-white"
                >
                  Request a Demo
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10"
                >
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Key Features Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">Key Features</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                Intelligent tools to identify and capture expansion opportunities.
              </p>
            </div>

            <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Opportunity Detection</h3>
                  <p className="mt-2 text-gray-600">AI algorithms analyze product usage patterns to identify accounts ready for additional features, services, or seats.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Expansion Scoring</h3>
                  <p className="mt-2 text-gray-600">Prioritize expansion opportunities based on propensity to buy, deal size, and likelihood of success.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Optimal Timing Prediction</h3>
                  <p className="mt-2 text-gray-600">Identify the perfect timing for expansion conversations based on customer lifecycle and engagement signals.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Personalized Expansion Paths</h3>
                  <p className="mt-2 text-gray-600">AI-generated expansion recommendations tailored to each customer's unique business needs and challenges.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16l2.879-2.879m0 0a3 3 0 104.243-4.242 3 3 0 00-4.243 4.242zM21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Value Proposition Generator</h3>
                  <p className="mt-2 text-gray-600">Automatically generate customized business cases and value propositions for each expansion opportunity.</p>
                </CardContent>
              </Card>

              <Card className="border border-gray-100 shadow-md hover:shadow-lg transition">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-dark">Guided Expansion Conversations</h3>
                  <p className="mt-2 text-gray-600">Conversation intelligence with real-time prompts to guide CSMs through expansion discussions.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">How It Works</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                Our AI-powered expansion solution helps you identify and capitalize on growth opportunities within your customer base.
              </p>
            </div>

            <div className="mt-16">
              <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                    alt="AI Expansion Process"
                    className="rounded-xl shadow-xl w-full h-auto"
                  />
                </div>
                <div className="mt-10 lg:mt-0 lg:pl-8">
                  <ol className="space-y-8">
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          1
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Multi-source Data Collection</h3>
                        <p className="mt-2 text-gray-600">
                          Our platform aggregates data from your product, CRM, and other sources to create a 360° view of each customer.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          2
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Opportunity Identification</h3>
                        <p className="mt-2 text-gray-600">
                          AI analyzes usage patterns, feature adoption, and business needs to identify expansion opportunities.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          3
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Prioritization & Timing</h3>
                        <p className="mt-2 text-gray-600">
                          Opportunities are scored and prioritized based on value, timing, and likelihood of success.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          4
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Tailored Approach Creation</h3>
                        <p className="mt-2 text-gray-600">
                          For each opportunity, the AI generates a customized approach strategy with talking points and value propositions.
                        </p>
                      </div>
                    </li>
                    <li className="flex">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary text-white font-bold">
                          5
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-lg font-bold text-dark">Execution Support & Learning</h3>
                        <p className="mt-2 text-gray-600">
                          AI assists with execution and learns from outcomes to continuously improve future recommendations.
                        </p>
                      </div>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Success Metrics Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-dark">The Impact</h2>
              <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                Our customers see significant improvements in their expansion metrics.
              </p>
            </div>

            <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
              <div className="text-center">
                <div className="text-primary text-5xl font-extrabold">30%</div>
                <p className="mt-2 text-gray-600">Increase in expansion revenue</p>
              </div>
              <div className="text-center">
                <div className="text-primary text-5xl font-extrabold">2.5x</div>
                <p className="mt-2 text-gray-600">More expansion opportunities identified</p>
              </div>
              <div className="text-center">
                <div className="text-primary text-5xl font-extrabold">40%</div>
                <p className="mt-2 text-gray-600">Higher conversion rate on upsells</p>
              </div>
              <div className="text-center">
                <div className="text-primary text-5xl font-extrabold">28%</div>
                <p className="mt-2 text-gray-600">Increase in average deal size</p>
              </div>
            </div>
          </div>
        </section>

        {/* Customer Testimonial */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center">
              <svg className="h-12 w-12 text-gray-400 mx-auto mb-4" fill="currentColor" viewBox="0 0 32 32" aria-hidden="true">
                <path d="M9.352 4C4.456 7.456 1 13.12 1 19.36c0 5.088 3.072 8.064 6.624 8.064 3.36 0 5.856-2.688 5.856-5.856 0-3.168-2.208-5.472-5.088-5.472-.576 0-1.344.096-1.536.192.48-3.264 3.552-7.104 6.624-9.024L9.352 4zm16.512 0c-4.8 3.456-8.256 9.12-8.256 15.36 0 5.088 3.072 8.064 6.624 8.064 3.264 0 5.856-2.688 5.856-5.856 0-3.168-2.304-5.472-5.184-5.472-.576 0-1.248.096-1.44.192.48-3.264 3.456-7.104 6.528-9.024L25.864 4z" />
              </svg>
              <p className="mt-4 text-2xl text-gray-600 italic">
                "We've increased our expansion revenue by 30% using CSHacker's AI to identify growth opportunities. The platform has paid for itself many times over in just the first quarter."
              </p>
              <div className="mt-6">
                <div className="flex items-center justify-center">
                  <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center text-gray-600">AJ</div>
                  <div className="ml-3 text-left">
                    <p className="text-sm font-medium text-dark">Alex Johnson</p>
                    <p className="text-sm text-gray-500">CS Operations Manager, Enterprise Solutions</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-dark">Ready to grow your customer accounts?</h2>
                <p className="mt-4 text-lg text-gray-600">
                  Get in touch with our team to learn how our AI-powered expansion solution can help you identify and capture more growth opportunities.
                </p>
                <ul className="mt-8 space-y-4">
                  <li className="flex items-center">
                    <Check className="text-success h-5 w-5 mr-3" />
                    <span>Free expansion opportunity analysis</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="text-success h-5 w-5 mr-3" />
                    <span>Customized demo with your customer data</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="text-success h-5 w-5 mr-3" />
                    <span>Revenue impact calculation for your business</span>
                  </li>
                </ul>
              </div>
              <div className="bg-gray-50 p-8 rounded-xl shadow-sm">
                <h3 className="text-xl font-bold text-dark mb-6">Contact Us</h3>
                <ContactForm />
              </div>
            </div>
          </div>
        </section>

        <CTASection />
        <Newsletter />
      </main>
    </>
  );
};

export default Expansion;
