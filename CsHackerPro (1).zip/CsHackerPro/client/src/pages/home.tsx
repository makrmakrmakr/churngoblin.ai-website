import Hero from "@/components/sections/hero";
import ValueProps from "@/components/sections/value-props";
import AIStrategies from "@/components/sections/ai-strategies";
import CTASection from "@/components/sections/cta-section";
import Testimonials from "@/components/sections/testimonials";
import CSTransformation from "@/components/sections/cs-transformation";
import ResourcesSection from "@/components/sections/resources-section";
import Newsletter from "@/components/sections/newsletter";
import CaseStudies from "@/components/sections/case-studies";
import MeetTheHackers from "@/components/sections/meet-the-hackers";
import { Helmet } from "react-helmet";

const Home = () => {
  return (
    <>
      <Helmet>
        <title>CSHacker - Community-Driven AI for Customer Success | Transform Your CS Operations</title>
        <meta name="description" content="Join a community of CS practitioners using AI to transform operations. Free resources, implementation playbooks, and proven strategies from top industry experts." />
        <meta name="keywords" content="customer success community, AI transformation, CS operations, AI in customer success, customer success automation" />
        <link rel="canonical" href="https://cshacker.ai/" />
        <meta property="og:title" content="CSHacker - Community-Driven AI for Customer Success | Transform Your CS Operations" />
        <meta property="og:description" content="Join a community of CS practitioners using AI to transform operations. Free resources, implementation playbooks, and proven strategies from top industry experts." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://cshacker.ai/" />
      </Helmet>
      <main>
        <Hero />
        <ValueProps />
        <AIStrategies />
        <CTASection />
        <Testimonials />
        <CaseStudies />
        <CSTransformation />
        <MeetTheHackers />
        <ResourcesSection />
        <Newsletter />
      </main>
    </>
  );
};

export default Home;
