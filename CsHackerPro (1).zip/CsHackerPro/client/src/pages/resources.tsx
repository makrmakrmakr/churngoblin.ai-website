import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Newsletter from "@/components/sections/newsletter";
import { Helmet } from "react-helmet";
import { Link } from "wouter";

const Resources = () => {
  const resourceCategories = [
    { label: "All", value: "all" },
    { label: "Guides", value: "guides" },
    { label: "Webinars", value: "webinars" },
    { label: "Reports", value: "reports" },
    { label: "Case Studies", value: "case-studies" },
  ];

  const resources = [
    {
      type: "Benchmark Report",
      category: "reports",
      title: "The State of AI in Customer Success: 2025 Mid-Year Benchmark Report",
      description: "Discover the latest trends, data, and actionable insights on AI adoption in Customer Success with key stats and implementation best practices.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "/reports/ai-in-cs-midyear-benchmark-2025",
      linkText: "Read Report",
      date: "May 12, 2025"
    },
    {
      type: "Blog Post",
      category: "guides",
      title: "AI in Customer Success: Transforming Onboarding, Renewal and Expansion",
      description: "Discover how leading companies are using AI to speed up onboarding by 40%, increase renewals by 25%, and identify 3x more expansion opportunities.",
      image: "https://images.unsplash.com/photo-1531746790731-6c087fecd65a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "/blog/ai-agents-in-customer-success",
      linkText: "Read Article",
      date: "May 12, 2025"
    },
    {
      type: "Case Study",
      category: "case-studies",
      title: "How Beable Transformed Onboarding with AI Analytics",
      description: "Learn how Beable, a K-12 literacy platform, used AI analytics to reduce time-to-value by 30% and increase user engagement across their platform.",
      image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "/case-studies/beable-onboarding",
      linkText: "Read Case Study",
      date: "May 12, 2025"
    },
    {
      type: "Case Study",
      category: "case-studies",
      title: "How Lumen Technologies Revolutionized Renewals with AI",
      description: "Discover how Lumen used AI to predict renewal risks 120+ days in advance, increasing CSM capacity by 25% and substantially improving renewal rates.",
      image: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "/case-studies/lumen-renewals",
      linkText: "Read Case Study",
      date: "May 12, 2025"
    },
    {
      type: "Case Study",
      category: "case-studies",
      title: "How Sync Labs Achieved 30x Revenue Growth Through AI",
      description: "Learn how Sync Labs leveraged AI to identify expansion opportunities, driving 30x revenue growth and expanding their customer base 100x with data-driven strategies.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "/case-studies/sync-labs-expansion",
      linkText: "Read Case Study",
      date: "May 12, 2025"
    },
    {
      type: "Case Study",
      category: "case-studies",
      title: "How TaskRabbit Revolutionized Customer Onboarding with AI Agents",
      description: "Explore how TaskRabbit implemented AI agents to handle 100% of initial chat interactions and resolve 28% of tickets without human intervention.",
      image: "https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "/case-studies/taskrabbit-onboarding",
      linkText: "Read Case Study",
      date: "May 12, 2025"
    },
    {
      type: "Guide",
      category: "guides",
      title: "The Ultimate Guide to AI in Customer Success",
      description: "Learn how artificial intelligence is transforming customer success operations and how to implement it effectively.",
      image: "https://images.unsplash.com/photo-1550432163-9cb326104944?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "#",
      linkText: "Read More",
      date: "June 15, 2023"
    },
    {
      type: "Webinar",
      category: "webinars",
      title: "5 Proven Strategies to Reduce Churn Using AI",
      description: "Join us for this on-demand webinar to discover how leading CS teams are leveraging AI to identify and address churn risks.",
      image: "https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "#",
      linkText: "Watch Now",
      date: "May 22, 2023"
    },
    {
      type: "Report",
      category: "reports",
      title: "2023 Customer Success Benchmarks Report",
      description: "Access the latest data and insights on CS metrics, team structures, and technology adoption across industries.",
      image: "https://images.unsplash.com/photo-1532622785990-d2c36a76f5a6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "#",
      linkText: "Download Report",
      date: "April 10, 2023"
    },
    {
      type: "Guide",
      category: "guides",
      title: "Building a Scalable Customer Onboarding Process",
      description: "A comprehensive guide to creating an onboarding process that scales with your business while maintaining a personal touch.",
      image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "#",
      linkText: "Read More",
      date: "February 5, 2023"
    },
    {
      type: "Webinar",
      category: "webinars",
      title: "Balancing AI and Human Touch in Customer Success",
      description: "Join our panel of CS leaders as they discuss strategies for finding the right balance between automation and personal relationships.",
      image: "https://images.unsplash.com/photo-1543269865-cbf427effbad?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      link: "#",
      linkText: "Watch Now",
      date: "January 28, 2023"
    }
  ];

  return (
    <>
      <Helmet>
        <title>Resources | CSHacker</title>
        <meta name="description" content="Explore our library of guides, webinars, reports, and case studies to level up your customer success strategy with AI-powered solutions." />
        <meta property="og:title" content="Resources | CSHacker" />
        <meta property="og:description" content="Explore our library of guides, webinars, reports, and case studies to level up your customer success strategy with AI-powered solutions." />
        <meta property="og:type" content="website" />
      </Helmet>
      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-r from-primary to-secondary overflow-hidden">
          <div className="absolute inset-0 bg-dark/30 mix-blend-multiply"></div>
          <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
            <div className="md:w-2/3">
              <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
                Resources & Insights
              </h1>
              <p className="mt-6 max-w-3xl text-xl text-white">
                Explore our library of guides, webinars, reports, and case studies to level up your customer success strategy with AI-powered solutions.
              </p>
            </div>
          </div>
        </section>

        {/* Resources Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Tabs defaultValue="all" className="w-full">
              <div className="flex justify-center mb-8">
                <TabsList>
                  {resourceCategories.map((category) => (
                    <TabsTrigger key={category.value} value={category.value}>
                      {category.label}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </div>

              <TabsContent value="all">
                <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                  {resources.map((resource, index) => (
                    <ResourceCard key={index} resource={resource} />
                  ))}
                </div>
              </TabsContent>

              {resourceCategories.slice(1).map((category) => (
                <TabsContent key={category.value} value={category.value}>
                  <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                    {resources
                      .filter((resource) => resource.category === category.value)
                      .map((resource, index) => (
                        <ResourceCard key={index} resource={resource} />
                      ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>

            <div className="mt-12 text-center">
              <Button
                variant="outline"
                className="border-gray-300 text-dark bg-white hover:bg-gray-50"
              >
                Load More Resources
              </Button>
            </div>
          </div>
        </section>

        {/* Featured Resource */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="mb-8 lg:mb-0">
                <img
                  src="https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                  alt="Featured Resource"
                  className="rounded-xl shadow-xl w-full h-auto"
                />
              </div>
              <div className="lg:pl-8">
                <span className="text-accent font-semibold">FEATURED RESOURCE</span>
                <h2 className="mt-2 text-3xl font-bold text-dark">The AI-Powered Customer Success Playbook</h2>
                <p className="mt-4 text-lg text-gray-600">
                  This comprehensive guide will show you exactly how to implement AI in your customer success organization for maximum impact. You'll learn:
                </p>
                <ul className="mt-6 space-y-3">
                  <li className="flex items-center">
                    <svg className="h-5 w-5 text-success mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>How to identify the right AI use cases for your team</span>
                  </li>
                  <li className="flex items-center">
                    <svg className="h-5 w-5 text-success mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Step-by-step implementation framework with real examples</span>
                  </li>
                  <li className="flex items-center">
                    <svg className="h-5 w-5 text-success mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>How to measure results and demonstrate ROI</span>
                  </li>
                  <li className="flex items-center">
                    <svg className="h-5 w-5 text-success mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Change management strategies for CS teams</span>
                  </li>
                </ul>
                <div className="mt-8">
                  <Button className="bg-primary hover:bg-primary/90">
                    Download the Playbook
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Newsletter />
      </main>
    </>
  );
};

interface ResourceCardProps {
  resource: {
    type: string;
    title: string;
    description: string;
    image: string;
    link: string;
    linkText: string;
    date: string;
  };
}

const ResourceCard = ({ resource }: ResourceCardProps) => {
  // Check if the link is internal (starts with '/') or external
  const isInternalLink = resource.link.startsWith('/');
  
  return (
    <Card className="bg-white rounded-xl overflow-hidden shadow-md border border-gray-100 hover:shadow-lg transition-shadow duration-300">
      <div className="h-48 w-full overflow-hidden">
        <img
          src={resource.image}
          alt={resource.title}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
      </div>
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-2">
          <div className="text-xs text-gray-500 uppercase tracking-widest">
            {resource.type}
          </div>
          <div className="text-xs text-gray-500">
            {resource.date}
          </div>
        </div>
        <h3 className="text-lg font-bold text-dark mb-2">{resource.title}</h3>
        <p className="text-gray-600 mb-4">{resource.description}</p>
        
        {isInternalLink ? (
          <Link
            href={resource.link}
            className="text-primary font-medium hover:text-primary/80"
          >
            {resource.linkText} →
          </Link>
        ) : (
          <a
            href={resource.link}
            className="text-primary font-medium hover:text-primary/80"
          >
            {resource.linkText} →
          </a>
        )}
      </CardContent>
    </Card>
  );
};

export default Resources;
