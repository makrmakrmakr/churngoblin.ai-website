import { Helmet } from "react-helmet";
import { ArrowLeft, Download, Share2, Calendar, Check, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const BeableCaseStudy = () => {
  return (
    <>
      <Helmet>
        <title>AI in Customer Success: How Beable Transformed Onboarding | CSHacker</title>
        <meta
          name="description"
          content="Learn how Beable, a K-12 literacy platform, used AI analytics to revolutionize their customer onboarding process, reducing time-to-value by 30% and increasing user engagement."
        />
        <meta
          name="keywords"
          content="customer success AI, onboarding optimization, edtech onboarding, AI analytics, customer success case study"
        />
        <link rel="canonical" href="https://cshacker.ai/case-studies/beable-onboarding" />
        
        {/* Open Graph / Social Media Tags */}
        <meta property="og:title" content="AI in Customer Success: How Beable Transformed Onboarding | CSHacker" />
        <meta property="og:description" content="Learn how Beable, a K-12 literacy platform, used AI analytics to revolutionize their customer onboarding process, reducing time-to-value by 30% and increasing user engagement." />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="https://cshacker.ai/case-studies/beable-onboarding" />
        <meta property="article:published_time" content="2025-05-12" />
        <meta property="article:section" content="Customer Success" />
        <meta property="article:tag" content="AI Onboarding" />
      </Helmet>

      <div className="max-w-3xl mx-auto px-4 py-12">
        <div className="mb-8">
          <Link href="/resources" className="text-primary inline-flex items-center hover:underline mb-4">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to resources
          </Link>

          <div className="flex justify-between items-start">
            <div>
              <div className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary mb-4">
                Case Study
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                AI in Customer Success: How Beable Transformed Onboarding
              </h1>
              <p className="text-gray-500 flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                May 12, 2025
              </p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Share2 className="h-4 w-4" />
                Share
              </Button>
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Download className="h-4 w-4" />
                Download PDF
              </Button>
            </div>
          </div>
        </div>

        <div className="prose prose-blue lg:prose-lg max-w-none">
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-100 mb-8 text-sm italic">
            <p className="text-gray-600">
              <strong>Disclaimer:</strong> The results and implementation details described in this case study are based on internal reports from Beable and UserPilot and have not been independently verified.
            </p>
          </div>

          <p className="lead text-lg">
            In today's competitive SaaS world, customer success isn't just about support—it's about smart, scalable onboarding that creates real momentum. Beable, a K–12 literacy platform, knew that effective onboarding was key to unlocking engagement and retention. That's why they turned to UserPilot's AI analytics to level up their customer success game.
          </p>

          <h2>The Challenge</h2>
          <p>
            Beable faced several challenges with their onboarding process:
          </p>
          <ul>
            <li>Complex product with different user types (administrators, teachers, students)</li>
            <li>Lack of visibility into where users were getting stuck</li>
            <li>One-size-fits-all onboarding that wasn't meeting the needs of diverse users</li>
            <li>High early-stage churn as users failed to reach value quickly enough</li>
          </ul>

          <h2>The Solution: AI-Powered Onboarding Analytics</h2>
          <p>
            Beable implemented UserPilot's AI-powered analytics to analyze user behavior and surface friction points during onboarding. According to UserPilot's published case study, Beable used the platform to "generate detailed funnel reports that automatically highlight how users interact with key pages"—providing the customer success team with clear visibility into where users dropped off or got stuck.
          </p>

          <p>
            Using this insight, Beable segmented users based on their roles and behaviors (e.g., tech-savvy admins vs. first-time educators), then designed personalized onboarding flows with contextual walkthroughs tailored to each segment.
          </p>

          <div className="bg-primary/5 p-6 rounded-xl border border-primary/10 my-8">
            <h3 className="text-xl font-bold text-primary mb-4">Key AI Implementation Details</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Behavioral analytics to identify friction points in the onboarding journey</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>User segmentation based on role, technical proficiency, and behavior patterns</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Personalized, contextual walkthroughs designed for each segment</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>AI-triggered interventions for at-risk users</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Automated alerts to CSMs for targeted follow-up</span>
              </li>
            </ul>
          </div>

          <h2>The Results</h2>
          <p>
            The AI-powered onboarding process led to impressive results:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">30%</div>
                <div className="text-gray-700">Reduction in time-to-value</div>
                <div className="text-gray-500 text-sm mt-1">Users reached their "aha moment" faster</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">↑</div>
                <div className="text-gray-700">Higher activation rates</div>
                <div className="text-gray-500 text-sm mt-1">More users completing key onboarding tasks</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">↑</div>
                <div className="text-gray-700">Increased content engagement</div>
                <div className="text-gray-500 text-sm mt-1">Across K-12 educators (reported internally)</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">↓</div>
                <div className="text-gray-700">Measurable drop in early-stage churn</div>
                <div className="text-gray-500 text-sm mt-1">Fewer users abandoning during onboarding</div>
              </CardContent>
            </Card>
          </div>

          <p>
            Additionally, AI-triggered interventions helped flag at-risk users and send in-product help tips or alerts to CSMs, enabling targeted follow-up without burdening the support team.
          </p>

          <h2>Key Takeaways</h2>
          <p>
            Beable's story demonstrates how investing in AI for onboarding can pay off—especially for EdTech platforms with complex user journeys. Their approach shows how thoughtful segmentation and data-backed optimization can elevate onboarding from a static checklist to a dynamic, responsive experience.
          </p>
          
          <p>
            Key lessons from this implementation include:
          </p>
          <ul>
            <li>Use AI to identify friction points in your onboarding process</li>
            <li>Segment users based on behavior, not just role or company size</li>
            <li>Design personalized experiences for each segment</li>
            <li>Set up proactive interventions for at-risk users</li>
            <li>Measure the impact on time-to-value and early-stage retention</li>
          </ul>

          <h2>Sources</h2>
          <div className="bg-gray-50 p-6 rounded-lg border border-gray-100 my-8">
            <h3 className="text-lg font-semibold mb-4">References</h3>
            <ol className="list-decimal pl-5 space-y-2">
              <li>
                <a 
                  href="https://userpilot.com/case-studies" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">UserPilot Case Studies</span>
                  <ExternalLink className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0" />
                </a>
              </li>
              <li>
                <span>Beable's Internal Onboarding Success Report (2024)</span>
              </li>
              <li>
                <a 
                  href="https://www.beable.com/resources" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">Beable Resources</span>
                  <ExternalLink className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0" />
                </a>
              </li>
            </ol>
            
            <div className="mt-6">
              <p className="text-sm text-gray-500 italic">
                <strong>Disclaimer:</strong> The results and implementation details described in this case study are based on internal reports from Beable and UserPilot and have not been independently verified. The 30% reduction in time-to-value was reported in UserPilot's published case study.
              </p>
            </div>
          </div>

          <Separator className="my-8" />

          <div className="flex flex-col md:flex-row items-center bg-primary/5 p-6 rounded-xl border border-primary/10">
            <div className="md:w-2/3 mb-4 md:mb-0 md:mr-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Ready to transform your customer onboarding?
              </h3>
              <p className="text-gray-700">
                Learn how AI agents can help your team create personalized, efficient onboarding experiences that drive activation and reduce churn.
              </p>
            </div>
            <div className="md:w-1/3 flex justify-center md:justify-end">
              <Button size="lg" className="bg-primary">
                Book a Consultation
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default BeableCaseStudy;