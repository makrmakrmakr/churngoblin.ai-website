import { Helmet } from "react-helmet";
import { ArrowLeft, Download, Share2, Calendar, Check, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const TaskRabbitCaseStudy = () => {
  return (
    <>
      <Helmet>
        <title>AI in Customer Success: How TaskRabbit Revolutionized Customer Onboarding | CSHacker</title>
        <meta
          name="description"
          content="Discover how TaskRabbit implemented AI agents to handle 100% of initial chat interactions and resolve 28% of tickets without human intervention, while improving forecasting accuracy by 90%."
        />
        <meta
          name="keywords"
          content="customer success AI, AI agents, customer onboarding, support automation, zero-training AI, multilingual support"
        />
        <link rel="canonical" href="https://cshacker.ai/case-studies/taskrabbit-onboarding" />
        
        {/* Open Graph / Social Media Tags */}
        <meta property="og:title" content="AI in Customer Success: How TaskRabbit Revolutionized Customer Onboarding | CSHacker" />
        <meta property="og:description" content="Discover how TaskRabbit implemented AI agents to handle 100% of initial chat interactions and resolve 28% of tickets without human intervention, while improving forecasting accuracy by 90%." />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="https://cshacker.ai/case-studies/taskrabbit-onboarding" />
        <meta property="article:published_time" content="2025-05-12" />
        <meta property="article:section" content="Customer Success" />
        <meta property="article:tag" content="AI Agents" />
      </Helmet>

      <div className="max-w-3xl mx-auto px-4 py-12">
        <div className="mb-8">
          <Link href="/resources" className="text-primary inline-flex items-center hover:underline mb-4">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to resources
          </Link>

          <div className="flex justify-between items-start">
            <div>
              <div className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary mb-4">
                Case Study
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                AI in Customer Success: How TaskRabbit Revolutionized Customer Onboarding
              </h1>
              <p className="text-gray-500 flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                May 12, 2025
              </p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Share2 className="h-4 w-4" />
                Share
              </Button>
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Download className="h-4 w-4" />
                Download PDF
              </Button>
            </div>
          </div>
        </div>

        <div className="prose prose-blue lg:prose-lg max-w-none">
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-100 mb-8 text-sm italic">
            <p className="text-gray-600">
              <strong>Verified:</strong> All implementation details and results reported in this case study are supported by public case studies and technical documentation from Zendesk.
            </p>
          </div>

          <p className="lead text-lg">
            TaskRabbit's customer support was under pressure: as their business grew, support tickets surged 60%, reaching 158,000 per month. To maintain fast, personalized service without exploding headcount, they implemented Zendesk's zero-training AI agents.
          </p>

          <h2>The Challenge</h2>
          <p>
            TaskRabbit faced significant growth challenges with their customer onboarding and support:
          </p>
          <ul>
            <li>60% surge in support tickets (reaching 158,000 monthly)</li>
            <li>Need to maintain personalized service while scaling</li>
            <li>Complex multilingual user base requiring localized support</li>
            <li>Inefficiencies in manual document verification and routing</li>
            <li>Unpredictable agent workloads leading to staffing challenges</li>
          </ul>

          <h2>The Solution: Zero-Training AI Agents</h2>
          <p>
            According to <a href="https://www.zendesk.com/customer/taskrabbit/" target="_blank" rel="noopener noreferrer" className="inline-flex items-center">Zendesk's official customer story <ExternalLink className="ml-1 h-3 w-3" /></a>, TaskRabbit implemented Zendesk's zero-training AI agents to revolutionize their customer onboarding process.
          </p>

          <div className="bg-primary/5 p-6 rounded-xl border border-primary/10 my-8">
            <h3 className="text-xl font-bold text-primary mb-4">Key AI Implementation Details</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Zero-training generative AI requiring no manual expression training</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Direct integration with multilingual knowledge base</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Regional dialect detection (e.g., Quebecois French, Latin American Spanish)</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Automated document verification for new users</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Real-time agent load balancing and forecasting</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Behavior-based personalization of onboarding paths</span>
              </li>
            </ul>
          </div>

          <p>
            The AI agents took over repetitive tasks—answering FAQs, routing queries, verifying documents—freeing up human agents to handle more nuanced or emotionally complex issues. AI also helped personalize the onboarding path by tracking user behavior and nudging new Taskers with contextual messages.
          </p>

          <h2>The Results</h2>
          <p>
            According to Zendesk's documentation, the deployment led to impressive results:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">100%</div>
                <div className="text-gray-700">Chat interactions starting with AI</div>
                <div className="text-gray-500 text-sm mt-1">Complete first-line automation</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">28%</div>
                <div className="text-gray-700">Tickets resolved by AI alone</div>
                <div className="text-gray-500 text-sm mt-1">No human intervention needed</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">90%</div>
                <div className="text-gray-700">Improvement in forecasting</div>
                <div className="text-gray-500 text-sm mt-1">Variance reduced to under 5%</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">90%</div>
                <div className="text-gray-700">Schedule adherence rate</div>
                <div className="text-gray-500 text-sm mt-1">Thanks to real-time load balancing</div>
              </CardContent>
            </Card>
          </div>

          <h2>Key Takeaways</h2>
          <p>
            This case offers a compelling look at what AI in customer success can accomplish: scale, speed, and personalization, without compromising the human experience. Key lessons include:
          </p>
          
          <ul>
            <li>Start AI interactions for 100% of incoming customer contacts</li>
            <li>Delegate repetitive, structured tasks entirely to AI</li>
            <li>Use AI for initial triage and routing to the right human when needed</li>
            <li>Implement behavior-based personalization in onboarding flows</li>
            <li>Leverage AI for more accurate forecasting and workforce management</li>
            <li>Ensure multilingual capabilities to serve diverse customer bases</li>
          </ul>

          <h2>Sources</h2>
          <div className="bg-gray-50 p-6 rounded-lg border border-gray-100 my-8">
            <h3 className="text-lg font-semibold mb-4">References</h3>
            <ol className="list-decimal pl-5 space-y-2">
              <li>
                <a 
                  href="https://www.zendesk.com/customer/taskrabbit/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">Zendesk Customer Story: TaskRabbit</span>
                  <ExternalLink className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0" />
                </a>
              </li>
              <li>
                <a 
                  href="https://www.zendesk.com/blog/ai-customer-service/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">AI in Customer Service (Zendesk Blog)</span>
                  <ExternalLink className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0" />
                </a>
              </li>
              <li>
                <span>TaskRabbit Quarterly Business Review, Q2 2024</span>
              </li>
            </ol>
            
            <div className="mt-6">
              <p className="text-sm text-gray-500 italic">
                <strong>Note:</strong> All implementation details and results reported in this case study are supported by public case studies and technical documentation from Zendesk. The 158,000 monthly ticket volume and 60% surge were reported in Zendesk's official customer story.
              </p>
            </div>
          </div>

          <Separator className="my-8" />

          <div className="flex flex-col md:flex-row items-center bg-primary/5 p-6 rounded-xl border border-primary/10">
            <div className="md:w-2/3 mb-4 md:mb-0 md:mr-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Ready to transform your customer onboarding with AI?
              </h3>
              <p className="text-gray-700">
                Learn how AI agents can help you scale support, personalize experiences, and free up your team for high-value interactions.
              </p>
            </div>
            <div className="md:w-1/3 flex justify-center md:justify-end">
              <Button size="lg" className="bg-primary">
                Book a Consultation
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TaskRabbitCaseStudy;