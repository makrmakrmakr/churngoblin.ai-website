import { Helmet } from "react-helmet";
import { ArrowLeft, Download, Share2, Calendar, Check, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const LumenCaseStudy = () => {
  return (
    <>
      <Helmet>
        <title>AI in Customer Success: How Lumen Technologies Revolutionized Renewals | CSHacker</title>
        <meta
          name="description"
          content="Discover how Lumen Technologies used AI to predict renewal risks 120+ days in advance, increase CSM capacity by 25%, and substantially improve renewal rates without adding headcount."
        />
        <meta
          name="keywords"
          content="customer success AI, renewal prediction, churn prevention, customer retention, AI scorecards, predictive analytics"
        />
        <link rel="canonical" href="https://cshacker.ai/case-studies/lumen-renewals" />
        
        {/* Open Graph / Social Media Tags */}
        <meta property="og:title" content="AI in Customer Success: How Lumen Technologies Revolutionized Renewals | CSHacker" />
        <meta property="og:description" content="Discover how Lumen Technologies used AI to predict renewal risks 120+ days in advance, increase CSM capacity by 25%, and substantially improve renewal rates without adding headcount." />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="https://cshacker.ai/case-studies/lumen-renewals" />
        <meta property="article:published_time" content="2025-05-12" />
        <meta property="article:section" content="Customer Success" />
        <meta property="article:tag" content="AI Renewals" />
      </Helmet>

      <div className="max-w-3xl mx-auto px-4 py-12">
        <div className="mb-8">
          <Link href="/resources" className="text-primary inline-flex items-center hover:underline mb-4">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to resources
          </Link>

          <div className="flex justify-between items-start">
            <div>
              <div className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary mb-4">
                Case Study
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                AI in Customer Success: How Lumen Technologies Revolutionized Renewals
              </h1>
              <p className="text-gray-500 flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                May 12, 2025
              </p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Share2 className="h-4 w-4" />
                Share
              </Button>
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Download className="h-4 w-4" />
                Download PDF
              </Button>
            </div>
          </div>
        </div>

        <div className="prose prose-blue lg:prose-lg max-w-none">
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-100 mb-8 text-sm italic">
            <p className="text-gray-600">
              <strong>Note:</strong> This case study reflects reported outcomes and practices that align with Gainsight's documented AI capabilities. Specific quantitative results such as renewal rate increases are consistent with customer reports but are not publicly audited.
            </p>
          </div>

          <p className="lead text-lg">
            Lumen Technologies wasn't content with reactive customer success. They wanted to get ahead of churn—and that meant predicting risk well before renewal time. Enter Gainsight's AI platform.
          </p>

          <h2>The Challenge</h2>
          <p>
            Lumen Technologies faced several challenges with their renewal process:
          </p>
          <ul>
            <li>Reactive approach to renewals, often identifying at-risk accounts too late</li>
            <li>Inconsistent health scoring based primarily on subjective CSM assessments</li>
            <li>Limited CSM capacity with growing account loads</li>
            <li>Difficulty prioritizing which accounts needed attention</li>
          </ul>

          <h2>The Solution: AI-Driven Renewal Prediction</h2>
          <p>
            Lumen implemented Gainsight's AI Scorecards, which analyze historical renewal data, product usage, support tickets, and survey responses to predict renewal outcomes. Gainsight reports that their AI Scorecards "deliver instant configuration recommendations" and offer more objective, data-driven health scoring.
          </p>

          <div className="bg-primary/5 p-6 rounded-xl border border-primary/10 my-8">
            <h3 className="text-xl font-bold text-primary mb-4">Key AI Implementation Details</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>AI Scorecards analyzing multiple data sources to predict renewal likelihood</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>External signal monitoring through real-time data scraping</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>AI-generated next-best-actions for CSMs</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Cross-functional alignment through centralized data</span>
              </li>
              <li className="flex items-start">
                <Check className="text-primary h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Leading indicator strategy instead of lagging indicators</span>
              </li>
            </ul>
          </div>

          <p>
            Gainsight's AI also monitored external signals, such as mergers and funding events, through real-time data scraping. These triggers allowed Lumen to act earlier and personalize their outreach. The AI platform also aligned cross-functional teams around shared metrics and goals by centralizing customer health data.
          </p>

          <h2>The Results</h2>
          <p>
            Lumen's results, as reported in Gainsight's internal materials, include:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">120+</div>
                <div className="text-gray-700">Days lead time for identifying risk</div>
                <div className="text-gray-500 text-sm mt-1">Up from just 30 days previously</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">↑</div>
                <div className="text-gray-700">Substantial renewal rate increase</div>
                <div className="text-gray-500 text-sm mt-1">Especially in mid-market segment</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">25%</div>
                <div className="text-gray-700">Increase in CSM account capacity</div>
                <div className="text-gray-500 text-sm mt-1">Without hiring additional staff</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-primary text-3xl font-bold mb-2">↑</div>
                <div className="text-gray-700">More strategic conversations</div>
                <div className="text-gray-500 text-sm mt-1">Based on AI-generated insights</div>
              </CardContent>
            </Card>
          </div>

          <h2>Key Takeaways</h2>
          <p>
            By moving from a lagging indicator model to a leading-indicator strategy, Lumen turned renewals into a proactive, scalable, and data-rich process. Their experience demonstrates several key lessons:
          </p>
          
          <ul>
            <li>Start predicting renewal risk at least 120 days before renewal dates</li>
            <li>Incorporate both product usage data and external signals into risk assessments</li>
            <li>Use AI to generate specific next actions for CSMs rather than just risk scores</li>
            <li>Leverage AI to increase CSM capacity without sacrificing personalization</li>
            <li>Align cross-functional teams around shared, data-driven customer health metrics</li>
          </ul>

          <h2>Sources</h2>
          <div className="bg-gray-50 p-6 rounded-lg border border-gray-100 my-8">
            <h3 className="text-lg font-semibold mb-4">References</h3>
            <ol className="list-decimal pl-5 space-y-2">
              <li>
                <a 
                  href="https://www.gainsight.com/customer-success-examples/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">Gainsight Customer Success Examples</span>
                  <ExternalLink className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0" />
                </a>
              </li>
              <li>
                <span>Gainsight's AI Scorecard Technical Documentation (2024)</span>
              </li>
              <li>
                <a 
                  href="https://www.lumen.com/en-us/about/our-story.html" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">Lumen Technologies Company Information</span>
                  <ExternalLink className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0" />
                </a>
              </li>
              <li>
                <span>Lumen's Customer Success Transformation Report (Internal, 2024)</span>
              </li>
            </ol>
            
            <div className="mt-6">
              <p className="text-sm text-gray-500 italic">
                <strong>Note:</strong> This case study reflects reported outcomes and practices that align with Gainsight's documented AI capabilities. Specific quantitative results such as renewal rate increases are consistent with customer reports but are not publicly audited. The 120+ days lead time and 25% increase in CSM account capacity metrics are from Gainsight's internal materials.
              </p>
            </div>
          </div>

          <Separator className="my-8" />

          <div className="flex flex-col md:flex-row items-center bg-primary/5 p-6 rounded-xl border border-primary/10">
            <div className="md:w-2/3 mb-4 md:mb-0 md:mr-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Ready to transform your renewal process?
              </h3>
              <p className="text-gray-700">
                Learn how AI agents can help your team predict renewal risks earlier and take proactive steps to improve retention.
              </p>
            </div>
            <div className="md:w-1/3 flex justify-center md:justify-end">
              <Button size="lg" className="bg-primary">
                Book a Consultation
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default LumenCaseStudy;