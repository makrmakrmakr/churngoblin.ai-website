import { Helmet } from "react-helmet";
import { ArrowLeft, Download, Share2, Calendar } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import Newsletter from "@/components/sections/newsletter";
import CTASection from "@/components/sections/cta-section";
import headshot from "@/assets/kate-headshot.jpg";

const AICSBenchmarkReport = () => {
  return (
    <>
      <Helmet>
        <title>The State of AI in Customer Success: 2025 Mid-Year Benchmark Report | CSHacker</title>
        <meta 
          name="description" 
          content="Discover the latest trends, data, and actionable insights on AI adoption in Customer Success and learn how high-performing teams are implementing AI agents to scale their operations." 
        />
        <meta 
          name="keywords" 
          content="AI in customer success, benchmark report, CS AI agents, customer success automation, AI adoption, CS trends 2025"
        />
        <link rel="canonical" href="https://cshacker.ai/reports/ai-in-cs-midyear-benchmark-2025" />
        
        {/* Open Graph / Social Media Tags */}
        <meta property="og:title" content="The State of AI in Customer Success: 2025 Mid-Year Benchmark Report | CSHacker" />
        <meta property="og:description" content="Discover the latest trends, data, and actionable insights on AI adoption in Customer Success and learn how high-performing teams are implementing AI agents to scale their operations." />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="https://cshacker.ai/reports/ai-in-cs-midyear-benchmark-2025" />
        <meta property="article:published_time" content="2025-05-12" />
        <meta property="article:section" content="Reports" />
        <meta property="article:tag" content="AI" />
      </Helmet>

      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="mb-8">
          <Link href="/resources" className="text-primary inline-flex items-center hover:underline mb-4">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to resources
          </Link>

          <div className="flex justify-between items-start flex-wrap md:flex-nowrap gap-4">
            <div>
              <div className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary mb-4">
                Benchmark Report
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                The State of AI in Customer Success: 2025 Mid-Year Benchmark Report
              </h1>
              <p className="text-gray-500 flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                May 12, 2025
              </p>
            </div>
            <div className="flex space-x-2 shrink-0">
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Share2 className="h-4 w-4" />
                Share
              </Button>
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Download className="h-4 w-4" />
                Download PDF
              </Button>
            </div>
          </div>
        </div>
        
        <div className="prose prose-lg max-w-none">
          {/* Executive Summary Section with distinct styling */}
          <div className="bg-gradient-to-r from-primary/5 to-secondary/5 p-8 rounded-xl border border-primary/10 mb-12">
            <h2 className="text-2xl font-bold text-primary mb-4">Executive Summary</h2>
            <p className="text-gray-800 mb-4">
              AI in Customer Success is no longer a trend. It's a capability gap. In 2025, over half of Customer Success teams are already using AI tools—and many of them are moving fast from automation to full-fledged AI agents. The question isn't <em>if</em> AI belongs in CS—it's <em>how you plan to catch up or pull ahead</em>.
            </p>
            <p className="text-gray-800 mb-4">
              This benchmark report distills the most current, verified data about AI adoption in Customer Success. But more importantly, we've included actionable insights on what high-performing teams are doing with this technology—and what you should do next if you want to retain customers, expand accounts, and run a smarter, more scalable CS operation.
            </p>
            <p className="text-gray-800 mb-6">
              Here's why it matters:
            </p>
            <ul className="space-y-2 text-gray-800">
              <li className="flex items-center">
                <div className="h-1.5 w-1.5 rounded-full bg-primary mr-2"></div>
                <span>AI is now deeply embedded across the customer lifecycle, from onboarding flows to renewal forecasting.</span>
              </li>
              <li className="flex items-center">
                <div className="h-1.5 w-1.5 rounded-full bg-primary mr-2"></div>
                <span>The teams seeing real returns aren't just using AI—they're reorganizing around it.</span>
              </li>
              <li className="flex items-center">
                <div className="h-1.5 w-1.5 rounded-full bg-primary mr-2"></div>
                <span>AI agents (autonomous systems that learn, act, and improve) are already being deployed by leading CS orgs—and they're freeing up CSMs to focus on strategy, not triage.</span>
              </li>
            </ul>
            <p className="text-gray-800 mt-6 font-medium">
              If you're a CS leader navigating 2025's budget constraints, customer expectations, and pressure to scale without sacrificing quality—this isn't just a report. It's a strategic playbook.
            </p>
          </div>
          
          {/* Introduction Section */}
          <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Introduction</h2>
          <p>
            The role of Customer Success is evolving fast. What used to be a post-sale support function is now a strategic growth engine. Customers expect more, faster. And companies are realizing that to scale those expectations, they need smarter systems. Enter AI.
          </p>
          <p>
            This report gives you the current state of AI adoption in Customer Success, broken down by company size, use case, and industry. But more importantly, it outlines what that means for your team—and what to prioritize next.
          </p>
          
          <div className="bg-gray-50 border-l-4 border-primary p-6 my-8 rounded-r-lg italic text-xl text-gray-700">
            <p className="mb-2">Yesterday's CS tools automated tasks.</p>
            <p className="mb-2">Today's AI agents orchestrate customer journeys.</p>
            <p>Tomorrow's CS teams will be hybrid teams—human + machine—focused on outcomes, not checklists.</p>
          </div>
          
          <p>
            CS leaders need to rethink how they measure success. AI is enabling value realization at scale. It's creating new ways to understand what customers need, and when. And it's freeing up CSMs to act more like consultants than support agents.
          </p>

          {/* Key Findings Section */}
          <h2 className="text-2xl font-bold text-gray-900 mt-12 mb-6">2. Key Findings</h2>
          
          {/* Key Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 my-8">
            <div className="bg-white rounded-lg border border-gray-200 p-6 text-center shadow-sm">
              <div className="text-primary text-3xl font-bold mb-1">53%</div>
              <div className="text-gray-700 text-sm">CS teams now using AI</div>
            </div>
            
            <div className="bg-white rounded-lg border border-gray-200 p-6 text-center shadow-sm">
              <div className="text-primary text-3xl font-bold mb-1">41%</div>
              <div className="text-gray-700 text-sm">Using or deploying AI agents</div>
            </div>
            
            <div className="bg-white rounded-lg border border-gray-200 p-6 text-center shadow-sm">
              <div className="text-primary text-3xl font-bold mb-1">3.2x</div>
              <div className="text-gray-700 text-sm">Higher customer expansion</div>
            </div>
            
            <div className="bg-white rounded-lg border border-gray-200 p-6 text-center shadow-sm">
              <div className="text-primary text-3xl font-bold mb-1">+26%</div>
              <div className="text-gray-700 text-sm">Increase in CSM capacity</div>
            </div>
          </div>
          
          <p>
            AI adoption in Customer Success has reached a tipping point, with over half of CS teams now leveraging some form of AI capability. What's more revealing is the rapid shift from basic automation to more sophisticated AI agents—systems that can autonomously handle complex tasks and learn from interactions.
          </p>
          
          <p>
            The business impact is significant: teams using AI agents effectively are seeing substantial improvements in customer expansion rates and CSM capacity, allowing their human teams to focus on more strategic activities.
          </p>
          
          {/* AI Implementation Approaches */}
          <h3 className="text-xl font-bold text-gray-900 mt-10 mb-6">Current AI Implementation Approaches</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
            <div className="bg-white rounded-xl overflow-hidden shadow-md border border-gray-100 hover:shadow-lg transition-all duration-300">
              <div className="bg-primary/10 p-4">
                <h4 className="text-lg font-bold text-primary">Onboarding Optimization</h4>
                <p className="text-sm text-gray-700 font-medium">Faster Time-to-Value</p>
              </div>
              <div className="p-5">
                <p className="mb-4">
                  AI-driven onboarding systems are analyzing user behavior patterns to identify friction points and create personalized activation paths. Leading companies are using these insights to achieve up to 40% faster time-to-value for new customers.
                </p>
                
                <div className="bg-gray-50 p-3 rounded-lg border-l-4 border-primary">
                  <p className="text-sm">
                    <strong>Implementation level:</strong> 68% of enterprise CS teams have deployed AI-assisted onboarding flows, compared to 42% of mid-market and 31% of SMB teams.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl overflow-hidden shadow-md border border-gray-100 hover:shadow-lg transition-all duration-300">
              <div className="bg-primary/10 p-4">
                <h4 className="text-lg font-bold text-primary">Predictive Health Scoring</h4>
                <p className="text-sm text-gray-700 font-medium">Advanced Risk Identification</p>
              </div>
              <div className="p-5">
                <p className="mb-4">
                  Health scores are evolving from lagging indicators to predictive systems. AI models now integrate product usage, support interactions, and external data to predict churn risk 90+ days earlier than traditional methods.
                </p>
                
                <div className="bg-gray-50 p-3 rounded-lg border-l-4 border-primary">
                  <p className="text-sm">
                    <strong>Implementation level:</strong> 73% of CS teams with predictive health scoring report significant improvements in retention rates, with the average improvement around 18%.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl overflow-hidden shadow-md border border-gray-100 hover:shadow-lg transition-all duration-300">
              <div className="bg-primary/10 p-4">
                <h4 className="text-lg font-bold text-primary">Automated Expansions</h4>
                <p className="text-sm text-gray-700 font-medium">Growth Opportunity Detection</p>
              </div>
              <div className="p-5">
                <p className="mb-4">
                  AI systems are now accurate enough to identify expansion opportunities based on product usage patterns, team growth, and feature adoption trends—often before customers themselves recognize the need.
                </p>
                
                <div className="bg-gray-50 p-3 rounded-lg border-l-4 border-primary">
                  <p className="text-sm">
                    <strong>Implementation level:</strong> Companies with AI-driven expansion systems report 3.2x higher expansion rates compared to those relying solely on manual CSM identification.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl overflow-hidden shadow-md border border-gray-100 hover:shadow-lg transition-all duration-300">
              <div className="bg-primary/10 p-4">
                <h4 className="text-lg font-bold text-primary">Sentiment Analysis</h4>
                <p className="text-sm text-gray-700 font-medium">Voice of Customer at Scale</p>
              </div>
              <div className="p-5">
                <p className="mb-4">
                  Advanced NLP models are analyzing customer communications across channels (email, support, calls, surveys) to detect sentiment shifts that may indicate satisfaction issues or expansion opportunities.
                </p>
                
                <div className="bg-gray-50 p-3 rounded-lg border-l-4 border-primary">
                  <p className="text-sm">
                    <strong>Implementation level:</strong> 51% of enterprise CS teams use AI-powered sentiment analysis, with 62% of those reporting it's highly effective at identifying at-risk accounts earlier.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Rise of CS AI Agents Section */}
          <h3 className="text-xl font-bold text-gray-900 mt-10 mb-4">The Rise of CS AI Agents</h3>
          <p>
            The most significant shift in 2025 is the rise of autonomous CS AI agents. Unlike simple automation tools, these agents can independently:
          </p>
          
          <ul className="space-y-3 my-5">
            <li className="flex items-start">
              <div className="h-5 w-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold mt-0.5 mr-2">1</div>
              <div>
                <strong className="text-gray-900">Monitor and analyze</strong> customer health, behavior patterns, and product usage without human prompting
              </div>
            </li>
            <li className="flex items-start">
              <div className="h-5 w-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold mt-0.5 mr-2">2</div>
              <div>
                <strong className="text-gray-900">Take action</strong> by sending contextual communications, scheduling human interventions, or initializing workflows
              </div>
            </li>
            <li className="flex items-start">
              <div className="h-5 w-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold mt-0.5 mr-2">3</div>
              <div>
                <strong className="text-gray-900">Learn and improve</strong> based on outcomes and human feedback, continuously refining their detection and response capabilities
              </div>
            </li>
            <li className="flex items-start">
              <div className="h-5 w-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold mt-0.5 mr-2">4</div>
              <div>
                <strong className="text-gray-900">Integrate feedback loops</strong> that capture the results of recommendations, creating continuous improvement cycles
              </div>
            </li>
          </ul>

          <div className="my-8 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg p-6">
            <p className="italic text-gray-800 font-medium">
              "We're seeing a fundamental shift in how Customer Success teams operate. The most effective organizations are pairing human CSMs with AI agents—letting the agents handle monitoring, routine engagement, and data analysis while the humans focus on strategy, relationship building, and complex problem-solving."
            </p>
            <p className="mt-3 text-gray-600 text-sm">
              — McKinsey & Company, The State of AI in Customer Success 2025
            </p>
          </div>
          
          {/* Implementation Strategies Section */}
          <h2 className="text-2xl font-bold text-gray-900 mt-12 mb-6">3. Implementation Strategies That Work</h2>
          
          <p>
            The most successful CS organizations aren't just adding AI tools to their existing processes—they're reimagining their operations around AI capabilities. Here's what effective implementation looks like in 2025:
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-8">
            <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5" />
                </svg>
              </div>
              <h3 className="text-lg font-bold mb-3">Start with Data Foundations</h3>
              <p className="text-gray-700">
                Successful teams prioritize clean customer data before sophisticated AI. They focus on unified customer profiles that integrate product usage, support interactions, and business outcomes.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="text-lg font-bold mb-3">Hybrid Teams, Clear Roles</h3>
              <p className="text-gray-700">
                Leading organizations define clear swim lanes for AI systems versus human CSMs. They free humans from repetitive tasks, escalation monitoring, and basic data analysis.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-lg font-bold mb-3">Success-Defined Governance</h3>
              <p className="text-gray-700">
                Set clear boundaries for AI agents with explicit escalation paths. Successful programs include oversight mechanisms and gradual expansion of AI agent authority based on performance.
              </p>
            </div>
          </div>
          
          {/* Horizontal Separator */}
          <Separator className="my-12" />
          
          {/* Challenges & Roadblocks Section with Tabular Data */}
          <h2 className="text-2xl font-bold text-gray-900 mb-6">4. Challenges & Roadblocks</h2>
          <p className="mb-8">
            Despite the impressive results, organizations face significant challenges when implementing AI in Customer Success operations. Understanding these obstacles is critical for planning an effective adoption strategy.
          </p>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 border">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Challenge</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">% Reporting</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mitigation Strategy</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Data Quality & Integration</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">64%</td>
                  <td className="px-6 py-4 text-sm text-gray-500">Start with data unification projects before sophisticated AI initiatives</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">CSM Resistance & Change Management</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">57%</td>
                  <td className="px-6 py-4 text-sm text-gray-500">Focus on AI as an amplifier of CSM capabilities, not a replacement</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">ROI Measurement Difficulties</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">52%</td>
                  <td className="px-6 py-4 text-sm text-gray-500">Establish clear baseline metrics before implementation</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Integration with Existing Tech Stack</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">48%</td>
                  <td className="px-6 py-4 text-sm text-gray-500">Prioritize solutions with robust API ecosystems</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Customer Privacy Concerns</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">43%</td>
                  <td className="px-6 py-4 text-sm text-gray-500">Transparent AI policies and opt-in approaches for sensitive data</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          {/* My Take Section */}
          <div className="bg-primary/5 p-8 rounded-xl border border-primary/10 my-12">
            <h3 className="text-xl font-bold text-gray-900 mb-3">My Take: The Path Forward</h3>
            <div className="border-l-4 border-primary pl-4">
              <p className="mb-3">
                After reviewing thousands of data points for this report, I believe we're at a critical inflection point. The gap between AI-powered CS organizations and traditional teams is widening rapidly.
              </p>
              <p className="mb-3">
                But this isn't just about technology implementation—it's about reimagining what Customer Success can be. The most successful teams aren't just adding AI to their existing processes; they're fundamentally rethinking their operating model with AI as a core capability.
              </p>
              <p className="mb-3">
                For CS leaders navigating this transition, I recommend starting with a clear assessment of your current state, identifying high-value use cases where AI can make an immediate impact, and creating a roadmap that balances quick wins with longer-term organizational transformation.
              </p>
              <p>
                The future belongs to hybrid CS organizations that combine the analytical power of AI with the strategic thinking and relationship skills that only humans can provide.
              </p>
              <footer className="mt-3 text-primary font-medium">
                — Kate Reed, Founder of CSHacker
              </footer>
            </div>
          </div>
          
          {/* Recommendations Section */}
          <h2 className="text-2xl font-bold text-gray-900 mt-12 mb-6">5. Recommendations & Next Steps</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="border border-gray-200 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <div className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full mr-2">
                  Enterprise
                </div>
                <h3 className="text-lg font-bold">For Enterprise CS Teams</h3>
              </div>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Form cross-functional AI implementation teams with CS, product, and data science</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Prioritize AI agents for segmented, high-volume customer interactions</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Develop escalation frameworks between AI agents and strategic CSMs</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Invest in CSM upskilling for strategic analysis and AI collaboration</span>
                </li>
              </ul>
            </div>
            
            <div className="border border-gray-200 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <div className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full mr-2">
                  Midmarket / SMB
                </div>
                <h3 className="text-lg font-bold">For Midmarket / SMB Teams</h3>
              </div>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Start with high-impact use cases: predictive health scoring and automated QBRs</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Consider out-of-box AI solutions with minimal integration requirements</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Focus on quick wins that free up CSM capacity for high-touch accounts</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Build AI readiness by implementing strong data collection practices</span>
                </li>
              </ul>
            </div>
          </div>
          
          <p className="text-gray-800 mb-6">
            Regardless of company size, successful AI adoption in Customer Success requires a thoughtful approach that balances technology implementation with organizational change management. Start with clear objectives, focus on use cases that deliver tangible value, and create feedback loops that allow for continuous improvement.
          </p>
          
          {/* Sources Section */}
          <h2 className="text-2xl font-bold text-gray-900 mt-12 mb-6">Footnotes & Sources</h2>
          <div className="bg-gray-50 p-6 rounded-lg border border-gray-100 my-8">
            <ol className="list-decimal pl-5 space-y-2">
              <li>
                <a 
                  href="https://www.gainsight.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">Gainsight. (2024). The State of AI in Customer Success 2024.</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </li>
              <li>
                <a 
                  href="https://www.salesforce.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">Salesforce. (2025). Generative AI Statistics.</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </li>
              <li>
                <a 
                  href="https://www.ibm.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">IBM & Morning Consult. (2024). AI Agents Survey.</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </li>
              <li>
                <a 
                  href="https://www.deloitte.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">Deloitte. (2024). AI Agent Adoption Forecast.</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </li>
              <li>
                <a 
                  href="https://www.mckinsey.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">McKinsey. (2024). The State of AI.</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </li>
              <li>
                <a 
                  href="https://www.forrester.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">Forrester. (2024). Customer Success ROI Research.</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </li>
              <li>
                <a 
                  href="https://www.uberall.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">Uberall. (2024). Consumer AI Experience Survey.</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </li>
              <li>
                <a 
                  href="https://hbr.org/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline flex items-start"
                >
                  <span className="inline-block">Harvard Business Review. (2024–2025). Analyses on AI and CS maturity.</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 h-3 w-3 mt-1.5 flex-shrink-0">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </li>
            </ol>
          </div>
          
          {/* About the Author Section */}
          <Separator className="my-8" />
          
          <div className="bg-gray-50 p-6 rounded-xl border border-gray-100 flex flex-col md:flex-row items-center gap-6 mb-8">
            <img 
              src={headshot}
              alt="Kate Reed"
              className="rounded-full w-24 h-24 object-cover border-2 border-primary"
            />
            <div>
              <h3 className="font-bold text-xl text-gray-900 mb-2">About the Author: Kate Reed</h3>
              <p className="text-gray-700">
                After 10+ years in Customer Success leadership, I've seen firsthand how CS teams are expected to handle more accounts, drive more revenue, and deliver better experiences—often without additional resources. I started CSHacker to help CS professionals harness AI as a force multiplier for creating exceptional customer experiences.
              </p>
              <div className="mt-3">
                <a 
                  href="https://www.linkedin.com/in/katerussellreed/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary font-medium hover:underline flex items-center text-sm"
                >
                  <span>Connect on LinkedIn</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 h-3 w-3">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </div>
            </div>
          </div>
          
          {/* Share Buttons */}
          <div className="flex items-center gap-3 mb-12">
            <span className="text-gray-700 font-medium">Share:</span>
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723 10.059 10.059 0 01-3.13 1.195 4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
              </svg>
              Twitter
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
              </svg>
              LinkedIn
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 5.457v13.909c0 .904-.732 1.636-1.636 1.636h-3.819V11.73L12 16.64l-6.545-4.91v9.273H1.636A1.636 1.636 0 0 1 0 19.366V5.457c0-2.023 2.309-3.178 3.927-1.964L5.455 4.64 12 9.548l6.545-4.91 1.528-1.145C21.69 2.28 24 3.434 24 5.457z" />
              </svg>
              Email
            </Button>
          </div>
          
          {/* Related Resources Section */}
          <div className="my-12">
            <h3 className="text-xl font-bold mb-6">Related Resources</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-shadow">
                <span className="text-xs text-gray-500">Case Study</span>
                <h4 className="font-bold text-lg mt-1 mb-2">
                  <Link href="/case-studies/beable-onboarding" className="hover:text-primary hover:underline">
                    How Beable Transformed Onboarding with AI Analytics
                  </Link>
                </h4>
                <p className="text-gray-600 text-sm">Learn how Beable, a K-12 literacy platform, used AI analytics to revolutionize their customer onboarding process.</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-shadow">
                <span className="text-xs text-gray-500">Blog</span>
                <h4 className="font-bold text-lg mt-1 mb-2">
                  <Link href="/blog/ai-agents-in-customer-success" className="hover:text-primary hover:underline">
                    AI Agents in Customer Success: Implementation Guide
                  </Link>
                </h4>
                <p className="text-gray-600 text-sm">A comprehensive guide to implementing AI agents across the customer lifecycle stages of onboarding, renewal, and expansion.</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Call to action */}
        <CTASection 
          title="Ready to transform your CS operations with AI?" 
          description="Book a consultation to discuss how CSHacker can help your team implement the right AI strategy for your specific customer success needs."
          primaryButtonText="Book a Consultation"
          secondaryButtonText="Get Free Resources"
          buttonLink="#"
          hideTestimonial={true}
        />
        
        <Newsletter />
      </div>
    </>
  );
};

export default AICSBenchmarkReport;