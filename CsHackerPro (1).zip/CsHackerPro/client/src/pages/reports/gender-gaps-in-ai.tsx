import { Helmet } from "react-helmet";
import { ArrowLeft, Calendar, User, Clock, Share2, Download, Bookmark } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import Newsletter from "@/components/sections/newsletter";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const GenderGapsReport = () => {
  return (
    <>
      <Helmet>
        <title>Gender Gaps in AI: Who's Using and Building the Future | CSHacker</title>
        <meta
          name="description"
          content="New research shows clear gender disparities in both AI adoption (who's using AI tools) and AI development (who's building them)."
        />
        <meta
          name="keywords"
          content="AI gender gap, women in AI, AI adoption, AI development, gender disparity in tech, customer success AI, diversity in AI"
        />
        <link rel="canonical" href="https://cshacker.ai/reports/gender-gaps-in-ai" />
        
        {/* Open Graph / Social Media Tags */}
        <meta property="og:title" content="Gender Gaps in AI: Who's Using and Building the Future | CSHacker" />
        <meta property="og:description" content="New research shows clear gender disparities in both AI adoption (who's using AI tools) and AI development (who's building them)." />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="https://cshacker.ai/reports/gender-gaps-in-ai" />
        <meta property="article:published_time" content="2025-05-15" />
        <meta property="article:section" content="AI Research" />
        <meta property="article:tag" content="AI Gender Gap" />
        <meta property="article:tag" content="Women in AI" />
        <meta property="article:tag" content="AI Adoption" />
      </Helmet>

      <main className="bg-white">
        {/* Report Header */}
        <div className="max-w-4xl mx-auto px-4 pt-12 pb-8">
          <Link href="/content" className="text-primary inline-flex items-center hover:underline mb-6">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to resources
          </Link>

          <div className="flex flex-col">
            <div className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary self-start mb-4">
              Research Report
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Gender Gaps in AI: Who's Using and Building the Future
            </h1>
            
            <div className="flex flex-wrap items-center text-sm text-gray-500 gap-4 mb-6">
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                May 15, 2025
              </div>
              <div className="flex items-center">
                <User className="h-4 w-4 mr-1" />
                CSHacker Research Team
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                8 min read
              </div>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg mb-8">
              <p className="text-lg text-gray-700">
                As artificial intelligence reshapes the workplace, it's not doing so equally. New research shows clear gender disparities in both <strong>AI adoption</strong> (who's using AI tools) and <strong>AI development</strong> (who's building them). If your team is investing in <strong>AI transformation</strong>, this is the context that matters.
              </p>
            </div>

            <div className="flex flex-wrap gap-3 mb-10">
              <Button variant="outline" size="sm" className="gap-1.5">
                <Share2 className="h-4 w-4" /> Share
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5">
                <Download className="h-4 w-4" /> Download PDF
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5">
                <Bookmark className="h-4 w-4" /> Save
              </Button>
            </div>
          </div>
        </div>

        {/* Report Content */}
        <article className="max-w-4xl mx-auto px-4 pb-16">
          <div className="prose prose-blue lg:prose-lg max-w-none">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <span className="inline-block px-2.5 py-1 bg-red-100 text-red-700 rounded-full text-xs">🚨</span>
              Fast Stats: AI Gender Disparities at a Glance
            </h2>
            
            <Table>
              <TableCaption>2024 Data on Gender Disparities in AI</TableCaption>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-1/2">Metric (2024 Data)</TableHead>
                  <TableHead>Men</TableHead>
                  <TableHead>Women</TableHead>
                  <TableHead>Source</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Use of generative AI tools at work</TableCell>
                  <TableCell>~50%</TableCell>
                  <TableCell>~33%</TableCell>
                  <TableCell>New York Fed (2024)</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Global share of AI-skilled professionals</TableCell>
                  <TableCell>71%</TableCell>
                  <TableCell>29%</TableCell>
                  <TableCell>Randstad (2024)</TableCell>
                </TableRow>
              </TableBody>
            </Table>

            <p>These aren't just numbers—they're signals. Let's break them down.</p>
            
            <Separator className="my-8" />
            
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <span className="inline-block px-2.5 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">🧠</span>
              AI Tool Adoption: The Usage Gap
            </h2>
            
            <p>
              Despite the surge in generative AI tools like ChatGPT, Copilot, and Claude, women are still significantly less likely than men to use AI in professional settings.
            </p>

            <ul className="space-y-2">
              <li>A 2024 global survey of 140,000+ professionals found women were <strong>20–25% less likely</strong> to use generative AI tools than men<sup>[3]</sup>.</li>
              <li>In the U.S., about <strong>50% of men</strong> said they had used a generative AI tool in the past year, compared to just <strong>33% of women</strong><sup>[1]</sup>.</li>
              <li>These gaps were seen <strong>across industries and countries</strong>, with the exception of a few tech-forward regions like San Francisco, where some reports found women slightly outpacing men<sup>[3]</sup>.</li>
            </ul>

            <div className="bg-green-50 p-5 rounded-lg my-6 border-l-4 border-green-400">
              <p className="text-green-800 font-medium flex items-center">
                <span className="mr-2">📈</span> Good news:
              </p>
              <p className="text-green-700">
                Deloitte reports that women's experimentation with gen AI doubled in 2023, and parity with men may be achieved by 2025 if trends hold<sup>[4]</sup>.
              </p>
            </div>

            <div className="my-8">
              <p className="mb-2 font-medium">AI Tool Adoption by Gender</p>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between mb-1 text-sm">
                    <span>Men</span>
                    <span>50%</span>
                  </div>
                  <Progress value={50} className="h-2.5 bg-gray-100" />
                </div>
                <div>
                  <div className="flex justify-between mb-1 text-sm">
                    <span>Women</span>
                    <span>33%</span>
                  </div>
                  <Progress value={33} className="h-2.5 bg-gray-100" />
                </div>
              </div>
            </div>
            
            <Separator className="my-8" />
            
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <span className="inline-block px-2.5 py-1 bg-amber-100 text-amber-700 rounded-full text-xs">🛠️</span>
              AI Development: The Builder Gap
            </h2>
            
            <p>
              The gender divide is even starker when it comes to <strong>who's building AI systems</strong>—the engineers, data scientists, and product managers creating the tech.
            </p>

            <ul className="space-y-2">
              <li>As of 2024, only <strong>29% of AI-skilled professionals globally are women</strong><sup>[2]</sup>.</li>
              <li>Women hold fewer than <strong>15% of leadership roles</strong> in AI and advanced tech fields<sup>[5]</sup>.</li>
              <li>However, among early-career AI professionals, women now make up around <strong>34%</strong>, compared to just 21% of those with 30+ years of experience<sup>[2]</sup>.</li>
            </ul>

            <p>
              This matters because teams that build AI shape the <strong>algorithms, guardrails, and user experiences</strong> that define how the rest of us work.
            </p>

            <div className="my-8">
              <p className="mb-2 font-medium">AI Professionals by Gender</p>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between mb-1 text-sm">
                    <span>Men</span>
                    <span>71%</span>
                  </div>
                  <Progress value={71} className="h-2.5 bg-gray-100" />
                </div>
                <div>
                  <div className="flex justify-between mb-1 text-sm">
                    <span>Women</span>
                    <span>29%</span>
                  </div>
                  <Progress value={29} className="h-2.5 bg-gray-100" />
                </div>
              </div>
            </div>
            
            <p className="mb-2 font-medium">Women in AI Career Stages (2024)</p>
            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="bg-gray-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-primary mb-1">34%</div>
                <div className="text-sm text-gray-600">Early-career</div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-primary mb-1">29%</div>
                <div className="text-sm text-gray-600">Mid-career</div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-primary mb-1">21%</div>
                <div className="text-sm text-gray-600">30+ years exp.</div>
              </div>
            </div>
            
            <Separator className="my-8" />
            
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <span className="inline-block px-2.5 py-1 bg-red-100 text-red-700 rounded-full text-xs">⚠️</span>
              Why It Matters for AI Leaders
            </h2>
            
            <p>
              This isn't just an inclusion issue—it's a <strong>business and innovation risk</strong>.
            </p>

            <ul className="space-y-2">
              <li>If women are less likely to use or shape AI, they're less likely to benefit from <strong>productivity gains</strong> or influence AI outcomes<sup>[6]</sup>.</li>
              <li>Fewer women in development roles increases the risk of <strong>algorithmic bias</strong>, model blind spots, and missed market opportunities<sup>[7]</sup>.</li>
              <li>Closing these gaps is essential to building <strong>trusted, human-centered AI systems</strong> that work for everyone.</li>
            </ul>
            
            <Separator className="my-8" />
            
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <span className="inline-block px-2.5 py-1 bg-purple-100 text-purple-700 rounded-full text-xs">👩‍💼</span>
              What This Means for Women
            </h2>
            
            <p>
              Slower AI adoption among women puts them at a structural disadvantage as AI reshapes jobs, workflows, and required skill sets. As generative AI becomes embedded across industries—from marketing to legal to customer service—those who adopt early gain productivity advantages, while others risk obsolescence.
            </p>
            
            <p>
              This means women may be <strong>disproportionately impacted by job displacement</strong> or role reshaping if they're not using AI tools at the same rate as men<sup>[1][3][6]</sup>.
            </p>
            
            <div className="bg-gradient-to-r from-teal-50 to-blue-50 p-6 rounded-lg border border-blue-100 my-8">
              <h3 className="text-xl font-bold mb-4 text-blue-800">🛠️ What to Do: Just Start Building</h3>
              <p className="mb-4 text-gray-700">
                If you're a woman in business, tech, or leadership—don't wait for permission or a perfect use case. Start now. You don't need a CS degree or a PhD in machine learning. You just need curiosity and a use case.
              </p>
              <ul className="space-y-2 text-gray-700">
                <li>Choose a task you do often</li>
                <li>Automate it with a no-code AI tool</li>
                <li>Try out a GPT prompt for your workflows</li>
                <li>Tinker with an agent builder</li>
              </ul>
              <p className="mt-4 text-gray-700">
                Encourage your teams to do the same. Build a low-stakes sandbox. Run internal AI experiments. Celebrate early wins. Normalize curiosity over perfection. The goal isn't just parity—it's progress.
              </p>
            </div>
            
            <Separator className="my-8" />
            
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <span className="inline-block px-2.5 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">🔍</span>
              Sources
            </h2>
            
            <ol className="space-y-4 text-sm">
              <li>
                <strong>New York Federal Reserve (2024)</strong>, <em>Generative AI Use by Gender and Job Function</em>.
                <br />
                <a href="https://libertystreeteconomics.newyorkfed.org/2024/02/generative-ai-and-race-gender-and-income/" className="text-primary break-words hover:underline">
                  https://libertystreeteconomics.newyorkfed.org/2024/02/generative-ai-and-race-gender-and-income/
                </a>
              </li>
              <li>
                <strong>Randstad (2024)</strong>, <em>Global AI Talent Report: Women in the AI Workforce</em>.
                <br />
                <a href="https://www.randstad.com/press/global-ai-talent-report-2024/" className="text-primary break-words hover:underline">
                  https://www.randstad.com/press/global-ai-talent-report-2024/
                </a>
              </li>
              <li>
                <strong>Harvard/AI Impacts/Gupta et al. (2024)</strong>, <em>The Gender Gap in Generative AI Adoption</em>.
                <br />
                <a href="https://arxiv.org/abs/2311.09532" className="text-primary break-words hover:underline">
                  https://arxiv.org/abs/2311.09532
                </a>
              </li>
              <li>
                <strong>Deloitte (2024)</strong>, <em>Women @ Work: AI Adoption Trends</em>.
                <br />
                <a href="https://www2.deloitte.com/global/en/pages/about-deloitte/articles/women-at-work.html" className="text-primary break-words hover:underline">
                  https://www2.deloitte.com/global/en/pages/about-deloitte/articles/women-at-work.html
                </a>
              </li>
              <li>
                <strong>World Economic Forum (2024)</strong>, <em>Global Gender Gap Report – AI & Tech Roles</em>.
                <br />
                <a href="https://www.weforum.org/reports/global-gender-gap-report-2024" className="text-primary break-words hover:underline">
                  https://www.weforum.org/reports/global-gender-gap-report-2024
                </a>
              </li>
              <li>
                <strong>OECD (2023)</strong>, <em>AI and the Gender Divide in the Future of Work</em>.
                <br />
                <a href="https://www.oecd.org/employment/ai-and-gender-divide-2023.htm" className="text-primary break-words hover:underline">
                  https://www.oecd.org/employment/ai-and-gender-divide-2023.htm
                </a>
              </li>
              <li>
                <strong>UNESCO (2023)</strong>, <em>Algorithmic Bias and Gender in AI Systems</em>.
                <br />
                <a href="https://www.unesco.org/en/artificial-intelligence/reports" className="text-primary break-words hover:underline">
                  https://www.unesco.org/en/artificial-intelligence/reports
                </a>
              </li>
            </ol>
          </div>

          <div className="mt-10 flex items-center gap-3">
            <span className="text-sm text-gray-500">Tags:</span>
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline">AI Gender Gap</Badge>
              <Badge variant="outline">Women in AI</Badge>
              <Badge variant="outline">AI Adoption</Badge>
              <Badge variant="outline">Diversity in Tech</Badge>
              <Badge variant="outline">CS Operations</Badge>
            </div>
          </div>
        </article>
        
        {/* Related Content */}
        <div className="max-w-4xl mx-auto px-4 pb-16">
          <h2 className="text-2xl font-bold mb-6">Related Content</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="border rounded-lg overflow-hidden">
              <div className="h-40 bg-blue-600" style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1531746790731-6c087fecd65a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }} />
              <div className="p-4">
                <div className="text-xs text-gray-500 mb-1">Article</div>
                <h3 className="font-bold mb-2">AI in Customer Success: Transforming Onboarding</h3>
                <Link href="/blog/ai-agents-in-customer-success">
                  <Button variant="link" className="px-0">Read Article →</Button>
                </Link>
              </div>
            </div>
            
            <div className="border rounded-lg overflow-hidden">
              <div className="h-40 bg-green-600" style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }} />
              <div className="p-4">
                <div className="text-xs text-gray-500 mb-1">Report</div>
                <h3 className="font-bold mb-2">2025 AI in Customer Success Benchmarks</h3>
                <Link href="/reports/ai-in-cs-midyear-benchmark-2025">
                  <Button variant="link" className="px-0">Read Report →</Button>
                </Link>
              </div>
            </div>
            
            <div className="border rounded-lg overflow-hidden">
              <div className="h-40 bg-purple-600" style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }} />
              <div className="p-4">
                <div className="text-xs text-gray-500 mb-1">Case Study</div>
                <h3 className="font-bold mb-2">TaskRabbit: Segmented Onboarding Success</h3>
                <Link href="/case-studies/taskrabbit-onboarding">
                  <Button variant="link" className="px-0">Read Case Study →</Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        {/* Newsletter */}
        <div className="max-w-4xl mx-auto px-4 pb-16">
          <div className="bg-gradient-to-r from-teal-800 to-blue-900 rounded-xl overflow-hidden text-white">
            <div className="container px-8 py-12 mx-auto">
              <div className="max-w-2xl mx-auto text-center">
                <h2 className="text-3xl font-bold mb-4">Stay On Top of CS AI Trends</h2>
                <p className="text-white/90 mb-8">
                  Join 3,000+ CS leaders getting weekly updates on the latest AI tools and strategies.
                </p>
                <div className="flex flex-col sm:flex-row gap-2 justify-center">
                  <input
                    type="email"
                    placeholder="Your email address"
                    className="px-4 py-3 rounded-md focus:outline-none text-gray-800 min-w-[250px]"
                  />
                  <Button className="bg-white text-teal-800 hover:bg-gray-100">Subscribe</Button>
                </div>
                <p className="text-white/70 text-sm mt-4">
                  No spam, just useful CS content. Unsubscribe anytime.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
};

export default GenderGapsReport;