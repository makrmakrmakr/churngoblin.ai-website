import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Save, Plus, Trash, RefreshCw } from "lucide-react";

// Define the response type
type AgentResponse = {
  key: string;
  name: string;
  content: string;
  keywords: string[];
};

const AdminPage = () => {
  // Initial responses that match our chat-agent.tsx
  const defaultResponses: AgentResponse[] = [
    {
      key: "greeting",
      name: "Greeting",
      content: "Hey! I'm here to help CS teams figure out if AI can make their lives easier. What brings you by today?",
      keywords: ["hi", "hello", "hey"]
    },
    {
      key: "default",
      name: "Default Response",
      content: "I hear you. Many CS leaders are dealing with similar challenges. Want to share more about your specific situation?",
      keywords: []
    },
    {
      key: "right_for_team",
      name: "Is AI Right For Team",
      content: "Certainly! CSHacker specializes in AI agents for three critical customer lifecycle phases: onboarding, renewal, and expansion. Each agent works alongside your human team to make them more effective. Which phase is most challenging for your team right now?",
      keywords: ["right for", "good fit", "should", "if my team", "need ai", "ready for ai", "using ai", "don't know"]
    },
    {
      key: "free_agents",
      name: "Free Agents",
      content: "I've got good news! We have free AI agents you can start using right away. They handle the basic stuff like sending check-in emails and collecting data. Want me to show you how to get started with one?",
      keywords: ["free", "no cost", "trial", "try out", "get started"]
    },
    {
      key: "agents",
      name: "AI Agents Overview",
      content: "We focus on three main areas where AI can help CS teams: onboarding new customers, securing renewals, and growing accounts. Each agent acts like a team member that handles repetitive tasks so your human CSMs can focus on relationships. Is one of those areas a particular pain point for you?",
      keywords: ["agent", "types", "offerings", "what agents"]
    }
  ];

  const [responses, setResponses] = useState<AgentResponse[]>([]);
  const [selectedResponse, setSelectedResponse] = useState<AgentResponse | null>(null);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  
  // Load responses from localStorage on component mount
  useEffect(() => {
    const savedResponses = localStorage.getItem("agentResponses");
    if (savedResponses) {
      try {
        setResponses(JSON.parse(savedResponses));
      } catch (e) {
        console.error("Error parsing stored responses", e);
        setResponses(defaultResponses);
      }
    } else {
      setResponses(defaultResponses);
    }
  }, []);
  
  // Select a response to edit
  const handleSelectResponse = (response: AgentResponse) => {
    setSelectedResponse({...response});
    setSaved(false);
    setError("");
  };
  
  // Update the selected response when editing
  const handleUpdateResponse = (key: keyof AgentResponse, value: string | string[]) => {
    if (!selectedResponse) return;
    
    if (key === "keywords" && typeof value === "string") {
      setSelectedResponse({
        ...selectedResponse,
        keywords: value.split(",").map(keyword => keyword.trim())
      });
    } else {
      setSelectedResponse({
        ...selectedResponse,
        [key]: value
      });
    }
    
    setSaved(false);
  };
  
  // Save the current response to the responses array
  const handleSaveResponse = () => {
    if (!selectedResponse) return;
    if (!selectedResponse.key || !selectedResponse.name || !selectedResponse.content) {
      setError("Key, name, and content are required fields");
      return;
    }
    
    // Check for duplicate keys
    if (selectedResponse.key !== "new" && responses.some(r => r.key === selectedResponse.key && r !== selectedResponse)) {
      setError("Response key must be unique");
      return;
    }
    
    let updatedResponses;
    if (selectedResponse.key === "new") {
      // Generate a unique key for new responses
      const uniqueKey = selectedResponse.name.toLowerCase().replace(/\s+/g, "_");
      const newResponse = {...selectedResponse, key: uniqueKey};
      updatedResponses = [...responses, newResponse];
      setSelectedResponse(newResponse);
    } else {
      // Update existing response
      updatedResponses = responses.map(r => 
        r.key === selectedResponse.key ? selectedResponse : r
      );
    }
    
    setResponses(updatedResponses);
    localStorage.setItem("agentResponses", JSON.stringify(updatedResponses));
    setSaved(true);
    setError("");
  };
  
  // Add a new response
  const handleAddResponse = () => {
    const newResponse: AgentResponse = {
      key: "new",
      name: "New Response",
      content: "",
      keywords: []
    };
    setSelectedResponse(newResponse);
    setSaved(false);
    setError("");
  };
  
  // Delete a response
  const handleDeleteResponse = (key: string) => {
    if (key === "default" || key === "greeting") {
      setError("Cannot delete the default or greeting responses");
      return;
    }
    
    const updatedResponses = responses.filter(r => r.key !== key);
    setResponses(updatedResponses);
    localStorage.setItem("agentResponses", JSON.stringify(updatedResponses));
    
    if (selectedResponse?.key === key) {
      setSelectedResponse(null);
    }
    
    setSaved(true);
  };
  
  // Reset to defaults
  const handleResetToDefaults = () => {
    if (window.confirm("Are you sure you want to reset all responses to defaults? This cannot be undone.")) {
      setResponses(defaultResponses);
      localStorage.setItem("agentResponses", JSON.stringify(defaultResponses));
      setSelectedResponse(null);
      setSaved(true);
      setError("");
    }
  };

  return (
    <>
      <Helmet>
        <title>Chat Agent Admin | CSHacker</title>
      </Helmet>
      <div className="container py-10 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">Chat Agent Admin</h1>
          <p className="text-gray-500">Customize how your chat agent responds to visitor queries.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Response List */}
          <div className="md:col-span-1 space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Responses</h2>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleAddResponse}
                className="flex items-center gap-1"
              >
                <Plus className="h-4 w-4" /> Add
              </Button>
            </div>
            
            <div className="space-y-2 max-h-[calc(100vh-300px)] overflow-y-auto pr-2">
              {responses.map((response) => (
                <Card 
                  key={response.key}
                  className={`cursor-pointer hover:border-primary transition-colors ${
                    selectedResponse?.key === response.key ? 'border-primary bg-primary/5' : ''
                  }`}
                  onClick={() => handleSelectResponse(response)}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">{response.name}</h3>
                        <p className="text-xs text-gray-500 mt-1">key: {response.key}</p>
                      </div>
                      {response.key !== "default" && response.key !== "greeting" && (
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-gray-500 hover:text-destructive"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteResponse(response.key);
                          }}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    <div className="mt-2">
                      <p className="text-xs text-gray-500">
                        Keywords: {response.keywords.length > 0 
                          ? response.keywords.join(", ") 
                          : (response.key === "default" ? "(Default response)" : "None")}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <Button 
              variant="outline"
              size="sm"
              className="w-full mt-4 text-gray-500"
              onClick={handleResetToDefaults}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Reset to defaults
            </Button>
          </div>
          
          {/* Response Editor */}
          <div className="md:col-span-2">
            {selectedResponse ? (
              <Card>
                <CardHeader>
                  <CardTitle>Edit Response</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {error && (
                    <Alert variant="destructive">
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                  
                  {saved && (
                    <Alert className="bg-green-50 border-green-200 text-green-800">
                      <AlertDescription>Response saved successfully!</AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="grid gap-2">
                    <Label htmlFor="name">Name</Label>
                    <Input 
                      id="name" 
                      value={selectedResponse.name}
                      onChange={(e) => handleUpdateResponse("name", e.target.value)}
                      placeholder="Response name (for admin reference only)"
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="keywords">Keywords (comma separated)</Label>
                    <Input 
                      id="keywords" 
                      value={selectedResponse.keywords.join(", ")}
                      onChange={(e) => handleUpdateResponse("keywords", e.target.value)}
                      placeholder="hello, hi, hey, etc."
                      disabled={selectedResponse.key === "default"}
                    />
                    {selectedResponse.key === "default" && (
                      <p className="text-xs text-gray-500 mt-1">Default response doesn't use keywords. It's used when no other patterns match.</p>
                    )}
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="content">Response Content</Label>
                    <Textarea 
                      id="content" 
                      value={selectedResponse.content}
                      onChange={(e) => handleUpdateResponse("content", e.target.value)}
                      placeholder="Enter the response text here..."
                      className="min-h-[250px] font-mono text-sm"
                    />
                    <p className="text-xs text-gray-500">
                      Use regular text formatting. Line breaks are preserved.
                    </p>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button 
                    onClick={handleSaveResponse}
                    className="flex items-center gap-1"
                  >
                    <Save className="h-4 w-4" /> 
                    Save Response
                  </Button>
                </CardFooter>
              </Card>
            ) : (
              <div className="h-full flex items-center justify-center border rounded-lg p-8 bg-gray-50">
                <div className="text-center">
                  <h3 className="font-medium text-gray-500 mb-2">Select a response to edit</h3>
                  <p className="text-gray-400 text-sm">
                    Or add a new response using the Add button
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default AdminPage;