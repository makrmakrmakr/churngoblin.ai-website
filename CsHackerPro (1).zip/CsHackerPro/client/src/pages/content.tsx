import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, Bookmark, BookOpen, Video, FileText, Calendar } from "lucide-react";
import { Link } from "wouter";

const ContentPage = () => {
  return (
    <>
      <Helmet>
        <title>Content Hub | CSHacker</title>
        <meta name="description" content="Articles, guides, and resources on using AI to improve customer success operations" />
      </Helmet>
      
      {/* Hero section - matching the screenshot */}
      <div className="bg-gradient-to-r from-teal-800 to-blue-900 text-white">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl">
            <h1 className="text-5xl font-bold mb-4">AI for CS Teams</h1>
            <p className="text-xl mb-8">
              Actionable content to transform your CS operations with AI. No theory, just real-world
              strategies that work.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button className="bg-white text-teal-800 hover:bg-gray-100">Latest Resources</Button>
              <Button className="bg-white text-teal-800 hover:bg-gray-100">
                Browse Case Studies
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <main className="container mx-auto px-4 py-12">
        {/* Featured content */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8">Featured Content</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Beable case study - this uses your existing case study content */}
            <Card className="col-span-full lg:col-span-2 overflow-hidden flex flex-col md:flex-row">
              <div className="md:w-1/2 h-60 md:h-auto bg-gray-100 relative">
                <div className="absolute inset-0 bg-gradient-to-r from-teal-500/20 to-blue-500/20" 
                  style={{
                    backgroundImage: "url('https://images.unsplash.com/photo-1531746790731-6c087fecd65a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                    backgroundSize: "cover",
                    backgroundPosition: "center"
                  }}
                />
              </div>
              <div className="md:w-1/2 p-6">
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs uppercase tracking-wide font-semibold rounded">
                    Case Study
                  </span>
                  <span className="text-gray-500 text-sm">May 12, 2025</span>
                </div>
                <h3 className="text-2xl font-bold mb-2">How Beable Transformed Onboarding with AI</h3>
                <p className="text-gray-600 mb-4">
                  Learn how Beable reduced onboarding time by 62% using AI agents to analyze user behavior patterns.
                </p>
                <Link href="/case-studies/beable-onboarding">
                  <Button>
                    Read Case Study <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </Card>
            
            <div className="lg:col-span-1 space-y-6">
              {/* Link to your AI in CS Benchmark Report */}
              <Card className="flex items-start p-4 gap-4">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <FileText className="h-6 w-6 text-blue-700" />
                </div>
                <div>
                  <h3 className="font-bold">2025 AI in CS Benchmarks</h3>
                  <p className="text-sm text-gray-600 mb-2">Latest benchmarks for AI adoption in CS teams.</p>
                  <Link href="/reports/ai-in-cs-midyear-benchmark-2025">
                    <Button variant="link" className="p-0 h-auto text-primary">Read Report →</Button>
                  </Link>
                </div>
              </Card>
              
              {/* Link to your blog post on AI in Customer Success */}
              <Card className="flex items-start p-4 gap-4">
                <div className="bg-green-100 p-3 rounded-lg">
                  <BookOpen className="h-6 w-6 text-green-700" />
                </div>
                <div>
                  <h3 className="font-bold">AI in Customer Success</h3>
                  <p className="text-sm text-gray-600 mb-2">Transforming onboarding, renewal, and expansion in 2025</p>
                  <Link href="/blog/ai-agents-in-customer-success">
                    <Button variant="link" className="p-0 h-auto text-primary">Read Article →</Button>
                  </Link>
                </div>
              </Card>
              
              {/* Link to the Lumen case study */}
              <Card className="flex items-start p-4 gap-4">
                <div className="bg-amber-100 p-3 rounded-lg">
                  <FileText className="h-6 w-6 text-amber-700" />
                </div>
                <div>
                  <h3 className="font-bold">Lumen's AI-Powered Renewal Strategy</h3>
                  <p className="text-sm text-gray-600 mb-2">How they increased renewal rates by 42%</p>
                  <Link href="/case-studies/lumen-renewals">
                    <Button variant="link" className="p-0 h-auto text-primary">Read Case Study →</Button>
                  </Link>
                </div>
              </Card>
            </div>
          </div>
        </section>
        
        {/* Content tabs */}
        <section className="mb-16">
          <Tabs defaultValue="all" className="mb-12">
            <div className="border-b mb-8">
              <TabsList className="mb-0">
                <TabsTrigger value="all">All Content</TabsTrigger>
                <TabsTrigger value="articles">Articles</TabsTrigger>
                <TabsTrigger value="case-studies">Case Studies</TabsTrigger>
                <TabsTrigger value="reports">Reports</TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value="all" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Gender Gaps in AI Report - New */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-blue-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Report</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">Gender Gaps in AI: Who's Using and Building the Future</h3>
                    <p className="text-gray-600 text-sm flex-grow">New research shows clear gender disparities in both AI adoption and AI development - and why it matters for CS teams.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">May 15, 2025</span>
                    <Link href="/reports/gender-gaps-in-ai">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                {/* Your existing content items */}
                
                {/* AI Agents in CS Blog */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-blue-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1531746790731-6c087fecd65a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <BookOpen className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Article</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">AI in Customer Success: Transforming Onboarding, Renewal, and Expansion</h3>
                    <p className="text-gray-600 text-sm flex-grow">Learn how AI is revolutionizing customer success with intelligent agents that reduce churn by 25% and speed up onboarding.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">May 12, 2025</span>
                    <Link href="/blog/ai-agents-in-customer-success">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                {/* Beable Case Study */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-teal-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1531539134685-27d67d18613e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Case Study</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">How Beable Transformed Onboarding with AI Analytics</h3>
                    <p className="text-gray-600 text-sm flex-grow">Learn how Beable reduced onboarding time by 62% using AI analytics to analyze user behavior patterns.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">May 12, 2025</span>
                    <Link href="/case-studies/beable-onboarding">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                {/* Lumen Case Study */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-purple-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1531973576160-7125cd663d86?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Case Study</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">Lumen's AI-Powered Renewal Strategy</h3>
                    <p className="text-gray-600 text-sm flex-grow">Discover how Lumen increased renewal rates by 42% by implementing AI-driven health scoring and proactive account management.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">April 8, 2025</span>
                    <Link href="/case-studies/lumen-renewals">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                {/* AI CS Benchmark Report */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-green-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Report</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">2025 AI in Customer Success Benchmarks</h3>
                    <p className="text-gray-600 text-sm flex-grow">Current benchmarks for AI adoption in CS teams, what tools are working, and what's still too experimental.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">May 10, 2025</span>
                    <Link href="/reports/ai-in-cs-midyear-benchmark-2025">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                {/* Sync Labs Case Study */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-amber-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1534008757030-27299c4371b6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Case Study</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">Sync Labs: Expansion Done Right</h3>
                    <p className="text-gray-600 text-sm flex-grow">How Sync Labs identifies upsell opportunities with AI and achieves 3X higher expansion revenue.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">April 1, 2025</span>
                    <Link href="/case-studies/sync-labs-expansion">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                {/* TaskRabbit Case Study */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-red-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Case Study</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">TaskRabbit: Segmented Onboarding Success</h3>
                    <p className="text-gray-600 text-sm flex-grow">How TaskRabbit increased activation from 54% to 82% with AI-driven, personalized onboarding paths.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">March 15, 2025</span>
                    <Link href="/case-studies/taskrabbit-onboarding">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="articles">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* AI Agents in CS Blog */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-blue-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1531746790731-6c087fecd65a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <BookOpen className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Article</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">AI in Customer Success: Transforming Onboarding, Renewal, and Expansion</h3>
                    <p className="text-gray-600 text-sm flex-grow">Learn how AI is revolutionizing customer success with intelligent agents that reduce churn by 25% and speed up onboarding.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">May 12, 2025</span>
                    <Link href="/blog/ai-agents-in-customer-success">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="case-studies">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Beable Case Study */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-teal-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1531539134685-27d67d18613e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Case Study</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">How Beable Transformed Onboarding with AI Analytics</h3>
                    <p className="text-gray-600 text-sm flex-grow">Learn how Beable reduced onboarding time by 62% using AI analytics to analyze user behavior patterns.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">May 12, 2025</span>
                    <Link href="/case-studies/beable-onboarding">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                {/* Lumen Case Study */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-purple-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1531973576160-7125cd663d86?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Case Study</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">Lumen's AI-Powered Renewal Strategy</h3>
                    <p className="text-gray-600 text-sm flex-grow">Discover how Lumen increased renewal rates by 42% by implementing AI-driven health scoring.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">April 8, 2025</span>
                    <Link href="/case-studies/lumen-renewals">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                {/* Sync Labs Case Study */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-amber-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1534008757030-27299c4371b6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Case Study</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">Sync Labs: Expansion Done Right</h3>
                    <p className="text-gray-600 text-sm flex-grow">How Sync Labs identifies upsell opportunities with AI and achieves 3X higher expansion revenue.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">April 1, 2025</span>
                    <Link href="/case-studies/sync-labs-expansion">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                {/* TaskRabbit Case Study */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-red-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Case Study</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">TaskRabbit: Segmented Onboarding Success</h3>
                    <p className="text-gray-600 text-sm flex-grow">How TaskRabbit increased activation from 54% to 82% with AI-driven, personalized onboarding paths.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">March 15, 2025</span>
                    <Link href="/case-studies/taskrabbit-onboarding">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="reports">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* AI CS Benchmark Report */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-green-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Report</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">2025 AI in Customer Success Benchmarks</h3>
                    <p className="text-gray-600 text-sm flex-grow">Current benchmarks for AI adoption in CS teams, what tools are working, and what's still too experimental.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">May 10, 2025</span>
                    <Link href="/reports/ai-in-cs-midyear-benchmark-2025">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
                
                {/* Gender Gaps in AI Report */}
                <Card className="overflow-hidden flex flex-col h-full">
                  <div className="h-40 relative">
                    <div className="absolute inset-0 bg-blue-600" 
                      style={{
                        backgroundImage: "url('https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=500')",
                        backgroundSize: "cover",
                        backgroundPosition: "center"
                      }}
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/90 text-xs font-medium">
                      <FileText className="h-5 w-5" />
                      <span className="uppercase tracking-wider">Report</span>
                    </div>
                  </div>
                  <CardContent className="flex-grow p-5">
                    <h3 className="font-bold text-lg mb-2">Gender Gaps in AI: Who's Using and Building the Future</h3>
                    <p className="text-gray-600 text-sm flex-grow">New research shows clear gender disparities in both AI adoption and AI development - and why it matters for CS teams.</p>
                  </CardContent>
                  <CardFooter className="pt-0 pb-5 px-5 flex justify-between items-center">
                    <span className="text-xs text-gray-500">May 15, 2025</span>
                    <Link href="/reports/gender-gaps-in-ai">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/90 p-0">
                        Read Now <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </section>
        
        {/* Topics grid */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-8">Browse by Topic</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <TopicCard title="Onboarding" count={2} bgColor="bg-blue-600" />
            <TopicCard title="Renewals" count={1} bgColor="bg-green-600" />
            <TopicCard title="Expansion" count={1} bgColor="bg-amber-600" />
            <TopicCard title="AI Implementation" count={3} bgColor="bg-teal-600" />
          </div>
        </section>
        
        {/* Newsletter signup */}
        <section className="bg-gradient-to-r from-teal-800 to-blue-900 rounded-xl overflow-hidden">
          <div className="container px-8 py-12 mx-auto">
            <div className="max-w-2xl mx-auto text-center text-white">
              <h2 className="text-3xl font-bold mb-4">Stay On Top of CS AI Trends</h2>
              <p className="text-white/90 mb-8">
                Join 3,000+ CS leaders getting weekly updates on the latest AI tools and strategies.
              </p>
              <div className="flex flex-col sm:flex-row gap-2 justify-center">
                <input
                  type="email"
                  placeholder="Your email address"
                  className="px-4 py-3 rounded-md focus:outline-none text-gray-800 min-w-[250px]"
                />
                <Button className="bg-white text-teal-800 hover:bg-gray-100">Subscribe</Button>
              </div>
              <p className="text-white/70 text-sm mt-4">
                No spam, just useful CS content. Unsubscribe anytime.
              </p>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

// Topic card
const TopicCard = ({ title, count, bgColor }: { title: string; count: number; bgColor: string }) => (
  <Link href={`/topics/${title.toLowerCase()}`}>
    <Card className={`${bgColor} text-white h-full cursor-pointer hover:shadow-lg transition-shadow`}>
      <CardContent className="p-6 flex flex-col h-full">
        <h3 className="text-xl font-bold mb-1">{title}</h3>
        <div className="mt-auto text-sm text-white/80">{count} resources</div>
      </CardContent>
    </Card>
  </Link>
);

export default ContentPage;