import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import ChatAgent from "@/components/chat-agent";
import Home from "@/pages/home";
import Onboarding from "@/pages/onboarding";
import Renewal from "@/pages/renewal";
import Expansion from "@/pages/expansion";
import ManagedAgents from "@/pages/managed-agents";
import About from "@/pages/about";
import Resources from "@/pages/resources";
import AdminPage from "@/pages/admin";
import CustomGPTs from "@/pages/custom-gpts";
import Forum from "@/pages/forum";
import AIAgents from "@/pages/ai-agents";
import AITools from "@/pages/ai-tools";
import Content from "@/pages/content";
import BeableCaseStudy from "@/pages/case-studies/beable-onboarding";
import LumenCaseStudy from "@/pages/case-studies/lumen-renewals";
import SyncLabsCaseStudy from "@/pages/case-studies/sync-labs-expansion";
import TaskRabbitCaseStudy from "@/pages/case-studies/taskrabbit-onboarding";
import AIAgentsBlogPost from "@/pages/blog/ai-agents-in-customer-success";
import AICSBenchmarkReport from "@/pages/reports/ai-in-cs-midyear-benchmark-2025";
import GenderGapsReport from "@/pages/reports/gender-gaps-in-ai";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <div className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/onboarding" component={Onboarding} />
          <Route path="/renewal" component={Renewal} />
          <Route path="/expansion" component={Expansion} />
          <Route path="/managed-agents" component={ManagedAgents} />
          <Route path="/ai-agents" component={AIAgents} />
          <Route path="/ai-tools" component={AITools} />
          <Route path="/custom-gpts" component={CustomGPTs} />
          <Route path="/content" component={Content} />
          <Route path="/forum" component={Forum} />
          <Route path="/about" component={About} />
          <Route path="/resources" component={Resources} />
          <Route path="/admin" component={AdminPage} />
          <Route path="/case-studies/beable-onboarding" component={BeableCaseStudy} />
          <Route path="/case-studies/lumen-renewals" component={LumenCaseStudy} />
          <Route path="/case-studies/sync-labs-expansion" component={SyncLabsCaseStudy} />
          <Route path="/case-studies/taskrabbit-onboarding" component={TaskRabbitCaseStudy} />
          <Route path="/blog/ai-agents-in-customer-success" component={AIAgentsBlogPost} />
          <Route path="/reports/ai-in-cs-midyear-benchmark-2025" component={AICSBenchmarkReport} />
          <Route path="/reports/gender-gaps-in-ai" component={GenderGapsReport} />
          <Route component={NotFound} />
        </Switch>
      </div>
      <Footer />
      <ChatAgent />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
